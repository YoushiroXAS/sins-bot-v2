'use strict';
const { describe, it, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSandbox, exitWhenDone, PROJECT } = require('./helpers/sandbox');
const { runChecks, findUndeclaredRequires } = require(path.join(PROJECT, 'scripts', 'check-deps.js'));

exitWhenDone(after);

const goodModules = () => ({
    '@whiskeysockets/baileys': { default() {}, useMultiFileAuthState() {}, DisconnectReason: {} },
    pino: () => {},
    axios: { get() {}, create() {} },
    canvas: { createCanvas() {} },
    cheerio: { load() {} },
    'chess.js': { Chess: class { isGameOver() {} isCheckmate() {} isDraw() {} fen() {} turn() {} move() {} } },
    'soundcloud-downloader': { default: { search() {} } },
    'yt-search': () => {},
    sharp: () => {},
});

describe('أدوات المشروع: فحص التبعيات و package.json', () => {
    it('check-deps: كل المكتبات سليمة => كل النتائج ok', () => {
        const mods = goodModules();
        const results = runChecks({ load: (name) => mods[name], nodeVersion: '22.1.0' });
        assert.ok(results.every(r => r.ok), JSON.stringify(results.filter(r => !r.ok)));
    });

    it('check-deps: chess.js القديمة (0.x) ومكتبة ناقصة وNode قديم => بيتبلّغ بوضوح، وsharp الاختيارية مش إجبارية', () => {
        const mods = goodModules();
        mods['chess.js'] = { Chess: class { game_over() {} in_checkmate() {} } };
        delete mods.cheerio; delete mods.sharp;
        const results = runChecks({ load: (name) => { if (!mods[name]) throw new Error(`Cannot find module '${name}'`); return mods[name]; }, nodeVersion: '16.20.0' });
        const byName = Object.fromEntries(results.map(r => [r.name, r]));
        assert.equal(byName['chess.js'].ok, false);
        assert.match(byName['chess.js'].detail, /1\.x/);
        assert.equal(byName.cheerio.ok, false);
        assert.match(byName.cheerio.detail, /مش متثبّتة/);
        assert.equal(byName.sharp.ok, false); assert.equal(byName.sharp.required, false);
        assert.equal(results[0].ok, false);
        assert.deepEqual(results.filter(r => !r.ok && r.required).map(r => r.name).sort(), ['Node.js 16.20.0', 'cheerio', 'chess.js'].sort());
    });

    it('كل require لمكتبة خارجية في الكود معلن في package.json', () => {
        assert.deepEqual(findUndeclaredRequires(PROJECT), []);
    });

    it('findUndeclaredRequires: بيكتشف مكتبة غير معلنة ويتجاهل الـ builtins والتعليقات', () => {
        const sb = createSandbox();
        const root = sb.resolvePath('fake-project');
        fs.mkdirSync(path.join(root, 'bot'), { recursive: true });
        fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({ dependencies: { axios: '^1' } }));
        fs.writeFileSync(path.join(root, 'index.js'), "const fs = require('fs'); const a = require('axios'); const l = require('left-pad'); // require('commented-out')\n/* require('block-commented') */\nconst s = require('@scope/pkg/sub');");
        const found = findUndeclaredRequires(root);
        assert.deepEqual(found.map(f => f.name).sort(), ['@scope/pkg', 'left-pad']);
    });

    it('package.json: سكريبتات test و check-deps موجودة، وإصدار Node المطلوب معلن', () => {
        const pkg = JSON.parse(fs.readFileSync(path.join(PROJECT, 'package.json'), 'utf8'));
        assert.equal(pkg.scripts.test, 'node test/run.js');
        assert.equal(pkg.scripts['check-deps'], 'node scripts/check-deps.js');
        assert.match(pkg.engines.node, /18/);
    });
});
