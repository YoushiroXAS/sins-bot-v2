'use strict';
// يشغّل كل ملفات test/*.test.js بـ node --test (كل ملف في process منفصل ونسخة مؤقتة منفصلة من المشروع)
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const files = fs.readdirSync(__dirname).filter(f => f.endsWith('.test.js')).sort().map(f => path.join(__dirname, f));
const result = spawnSync(process.execPath, ['--test', ...files], { stdio: 'inherit' });
process.exit(result.status === null ? 1 : result.status);
