'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');
const { sleep } = require('./helpers/harness');

exitWhenDone(after);

describe('التخزين: dataManager والمتجر والنسخ الاحتياطي', () => {
    let sb;
    before(() => { sb = createSandbox(); });
    const mkdir = (name) => { const d = sb.resolvePath('tmp-' + name); fs.mkdirSync(d, { recursive: true }); return d; };
    const quiet = { info() {}, warn() {}, error() {} };

    it('dataManager: ملف تالف بيتسترجع من أحدث نسخة سليمة وبيتكتب على الملف، والتالف بيتحفظ جنبه', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm');
        for (const [dir, v] of [['2026-01-01_00-00-00', 'old'], ['2026-01-02_00-00-00', 'newest']]) {
            fs.mkdirSync(path.join(T, 'backups', dir), { recursive: true });
            fs.writeFileSync(path.join(T, 'backups', dir, 'bank.json'), JSON.stringify({ v }));
        }
        fs.mkdirSync(path.join(T, 'data'), { recursive: true });
        fs.writeFileSync(path.join(T, 'data', 'bank.json'), '{"g":{"accounts":{"u1":12');
        const dm = new DataManager({ backupDir: path.join(T, 'backups'), debounceMs: 50 });
        assert.deepEqual(await dm.init('bank', path.join(T, 'data', 'bank.json'), {}, false), { v: 'newest' });
        assert.ok(fs.readdirSync(path.join(T, 'data')).some(f => f.includes('.corrupt-')));
        await sleep(250);
        assert.deepEqual(JSON.parse(fs.readFileSync(path.join(T, 'data', 'bank.json'), 'utf8')), { v: 'newest' });
    });

    it('dataManager: من غير نسخ احتياطية بيستخدم الافتراضي ويحفظ نسخة من التالف', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm2');
        fs.writeFileSync(path.join(T, 'titles.json'), 'not json');
        const dm = new DataManager({ backupDir: path.join(T, 'no_such_dir') });
        assert.deepEqual(await dm.init('titles', path.join(T, 'titles.json'), { def: true }, false), { def: true });
        assert.ok(fs.readdirSync(T).some(f => f.startsWith('titles.json.corrupt-')));
    });

    it('dataManager: تعديل مستمر بيتكتب أثناء النشاط (maxWait) ومش بيستنى لحد ما يوقف', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm3');
        const dm = new DataManager({ debounceMs: 400, maxWaitMs: 700, backupDir: path.join(T, 'nope') });
        await dm.init('k', path.join(T, 'k.json'), {}, false);
        let writes = 0; const orig = dm._atomicWrite.bind(dm);
        dm._atomicWrite = async (...a) => { writes++; return orig(...a); };
        for (let i = 0; i < 25; i++) { dm.set('k', { i }); await sleep(100); }
        assert.ok(writes >= 2, `writes=${writes}`);
        await dm.shutdown();
    });

    it('dataManager: الكتابة المعلّقة في الـ debounce بتتحفظ في shutdown()', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm4');
        const dm = new DataManager({ debounceMs: 2000, backupDir: path.join(T, 'nope') });
        await dm.init('k', path.join(T, 'k.json'), {}, false);
        dm.set('k', { saved: true });
        assert.deepEqual(JSON.parse(fs.readFileSync(path.join(T, 'k.json'), 'utf8')), {});
        await dm.shutdown();
        assert.deepEqual(JSON.parse(fs.readFileSync(path.join(T, 'k.json'), 'utf8')), { saved: true });
    });

    it('تخزين المتجر: حفظ ذري، فشل الكتابة مبيكسرش الملف الأصلي، والملف التالف بيتحفظ منه نسخة', () => {
        const { loadJSON, saveJSON } = sb.require('bot/libs/shop/storage');
        const T = mkdir('shop');
        const file = path.join(T, 'inventory.json');
        assert.equal(saveJSON(file, { u1: { sword: 2 } }), true);
        assert.deepEqual(loadJSON(file, {}), { u1: { sword: 2 } });
        assert.equal(fs.existsSync(file + '.tmp'), false);

        const realWrite = fs.writeFileSync; const realError = console.error;
        fs.writeFileSync = (p, d) => { realWrite(p, String(d).slice(0, 5)); throw new Error('محاكاة قطع الكهرباء'); };
        console.error = () => {};
        let result;
        try { result = saveJSON(file, { u1: { sword: 99 } }); } finally { fs.writeFileSync = realWrite; console.error = realError; }
        assert.equal(result, false);
        assert.deepEqual(loadJSON(file, {}), { u1: { sword: 2 } });
        assert.equal(fs.existsSync(file + '.tmp'), false);

        fs.writeFileSync(file, '{"u1":{"sw');
        console.error = () => {};
        try { assert.deepEqual(loadJSON(file, {}), {}); } finally { console.error = realError; }
        const aside = fs.readdirSync(T).filter(f => f.includes('.corrupt-'));
        assert.equal(aside.length, 1);
        assert.equal(fs.readFileSync(path.join(T, aside[0]), 'utf8'), '{"u1":{"sw');
        assert.deepEqual(loadJSON(path.join(T, 'nope.json'), { a: 1 }), { a: 1 });
    });

    it('BackupService: بينسخ الـ JSON السليم بس، بيحذف الأقدم، ومبينسخش تاني عند التشغيل لو آخر نسخة حديثة', async () => {
        const BackupService = sb.require('bot/services/backupService');
        const B = mkdir('bk');
        fs.mkdirSync(path.join(B, 'data'), { recursive: true });
        fs.writeFileSync(path.join(B, 'data', 'a.json'), '{"a":1}');
        fs.writeFileSync(path.join(B, 'data', 'bad.json'), '{broken');
        fs.writeFileSync(path.join(B, 'data', 'note.txt'), 'x');
        fs.writeFileSync(path.join(B, 'data', 'a.json.tmp'), '{"half":');
        for (let i = 1; i <= 4; i++) fs.mkdirSync(path.join(B, 'backups', `2026-01-0${i}_00-00-00`), { recursive: true });
        const options = { dataDir: path.join(B, 'data'), backupDir: path.join(B, 'backups'), keep: 3, logger: quiet };
        const result = await new BackupService(options).backupNow();
        assert.deepEqual(fs.readdirSync(result.target), ['a.json']);
        assert.equal(result.skipped, 1);
        const dirs = fs.readdirSync(path.join(B, 'backups')).sort();
        assert.equal(dirs.length, 3);
        assert.ok(!dirs.includes('2026-01-01_00-00-00') && !dirs.includes('2026-01-02_00-00-00'));

        const second = new BackupService(options);
        second.start(); await sleep(200); await second.shutdown();
        assert.equal(fs.readdirSync(path.join(B, 'backups')).length, 3);
    });
});
