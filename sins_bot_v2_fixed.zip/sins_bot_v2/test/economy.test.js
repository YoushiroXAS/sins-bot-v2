'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');
const { createHarness } = require('./helpers/harness');

exitWhenDone(after);

describe('الاقتصاد: إيداع وخصم وتحويل', () => {
    let sb, h;
    before(async () => { sb = createSandbox(); h = await createHarness(sb); });

    it('.ايداع بيشتغل وبيتسجّل في الـ audit (منفّذ، هدف، مبلغ، نتيجة)', async () => {
        await h.run(h.OWNER, '.ايداع 500');
        assert.equal(h.balance(h.OWNER), 500);
        const a = (await h.auditEntries()).pop();
        assert.deepEqual([a.action, a.result, a.amount, a.actor], ['deposit', 'ok', 500, h.OWNER]);
    });

    it('إيداع فوق الحد الآمن بيترفض والرصيد زي ما هو', async () => {
        assert.match(await h.run(h.OWNER, '.ايداع 999999999999b'), /كبير جدًا/);
        assert.equal(h.balance(h.OWNER), 500);
        assert.equal((await h.auditEntries()).pop().result, 'rejected');
    });

    it('مستخدم عادي بيحاول يودع: مرفوض ومتسجّل كمحاولة', async () => {
        await h.run(h.U1, '.ايداع 100');
        assert.equal((await h.auditEntries()).pop().result, 'denied');
        assert.equal(h.balance(h.U1), undefined);
    });

    it('.خصم بيشتغل ومتسجّل', async () => {
        await h.run(h.OWNER, '.خصم 100');
        assert.equal(h.balance(h.OWNER), 400);
        assert.equal((await h.auditEntries()).pop().action, 'deduct');
    });

    it('.تحويل بيشتغل ومتسجّل، والمستلم عند سقف الرصيد بيترفض والمرسل بيرجعله فلوسه', async () => {
        const bank = h.dm.get('bank');
        bank[h.G].accounts[h.U1] = 1000; bank[h.G].accounts[h.U2] = 0; h.dm.set('bank', bank);
        h.resetLimits();
        await h.run(h.U1, '.تحويل 50', { target: h.U2 });
        assert.equal(h.balance(h.U1), 950); assert.equal(h.balance(h.U2), 50);
        const a = (await h.auditEntries()).pop();
        assert.deepEqual([a.action, a.target, a.tax], ['transfer', h.U2, 0]);

        bank[h.G].accounts[h.U2] = Number.MAX_SAFE_INTEGER - 10;
        assert.match(await h.run(h.U1, '.تحويل 50', { target: h.U2 }), /الحد الأقصى/);
        assert.equal(h.balance(h.U1), 950);
    });

    it('MAX_TRANSFER: تحويل أكبر من الحد بيترفض، وبالظبط الحد بيعدّي', async () => {
        const bank = h.dm.get('bank');
        bank[h.G].accounts[h.U1] = 5_000_000; bank[h.G].accounts[h.U2] = 0; h.dm.set('bank', bank);
        h.resetLimits();
        assert.equal(h.config.economy.MAX_TRANSFER, 1_000_000);
        assert.match(await h.run(h.U1, '.تحويل 1500000', { target: h.U2 }), /أقصى مبلغ/);
        assert.equal(h.balance(h.U1), 5_000_000); assert.equal(h.balance(h.U2), 0);
        await h.run(h.U1, '.تحويل 1000000', { target: h.U2 });
        assert.equal(h.balance(h.U1), 4_000_000); assert.equal(h.balance(h.U2), 1_000_000);
    });

    it('TAX_RATE: الضريبة بتتخصم من اللي بيوصل للمستلم ومتسجّلة، وبـ 0 مفيش ضريبة', async () => {
        assert.equal(h.config.economy.TAX_RATE, 0);
        const bank = h.dm.get('bank');
        bank[h.G].accounts[h.U1] = 10_000; bank[h.G].accounts[h.U2] = 0; h.dm.set('bank', bank);
        h.resetLimits();
        h.config.economy.TAX_RATE = 0.1;
        try {
            assert.match(await h.run(h.U1, '.تحويل 1000', { target: h.U2 }), /ضريبة/);
        } finally { h.config.economy.TAX_RATE = 0; }
        assert.equal(h.balance(h.U1), 9_000); assert.equal(h.balance(h.U2), 900);
        assert.equal((await h.auditEntries()).pop().tax, 100);
    });
});

describe('الاقتصاد: تصفير البنك', () => {
    let sb, h, snapDir;
    before(async () => { sb = createSandbox(); h = await createHarness(sb); snapDir = sb.resolvePath('bot', 'backups', 'bank-resets'); });
    const reset = () => { h.dm.get('bank')[h.G] = { accounts: { a: 1000, b: 2500 } }; h.dm.set('bank', h.dm.get('bank')); };

    it('مستخدم عادي: مرفوض ومفيش حاجة اتمسحت', async () => {
        reset();
        assert.match(await h.run(h.U1, '.بنك تصفير'), /العليا/);
        assert.ok(h.dm.get('bank')[h.G]);
    });

    it('الأمر الأول بيحذّر (عدد الحسابات والمجموع) ومبيمسحش حاجة', async () => {
        const reply = await h.run(h.OWNER, '.بنك تصفير');
        assert.ok(reply.includes('2') && reply.includes('3,500') && reply.includes('تأكيد'), reply);
        assert.ok(h.dm.get('bank')[h.G]);
    });

    it('بعد التأكيد: اتمسح واتحفظت نسخة فيها الحسابات كاملة', async () => {
        assert.match(await h.run(h.OWNER, '.بنك تصفير تأكيد'), /تم تصفير 2/);
        assert.equal(h.dm.get('bank')[h.G], undefined);
        const files = fs.readdirSync(snapDir).filter(f => f.endsWith('.json'));
        assert.equal(files.length, 1);
        assert.deepEqual(JSON.parse(fs.readFileSync(path.join(snapDir, files[0]), 'utf8')).data.accounts, { a: 1000, b: 2500 });
    });

    it('تأكيد من غير طلب قبله، أو بعد أكتر من دقيقة: مرفوض', async () => {
        reset();
        assert.match(await h.run(h.OWNER, '.بنك تصفير تأكيد'), /مفيش طلب تصفير/);
        await h.run(h.OWNER, '.بنك تصفير');
        const realNow = Date.now; const t0 = realNow.call(Date);
        Date.now = () => t0 + 61_000;
        try { assert.match(await h.run(h.OWNER, '.بنك تصفير تأكيد'), /مفيش طلب تصفير/); } finally { Date.now = realNow; }
        assert.ok(h.dm.get('bank')[h.G]);
    });

    it('لو حفظ النسخة فشل: التصفير بيتلغي والبيانات سليمة، والـ audit بيسجّل', async () => {
        fs.rmSync(snapDir, { recursive: true, force: true }); fs.writeFileSync(snapDir, 'مش مجلد');
        try {
            await h.run(h.OWNER, '.بنك تصفير');
            assert.match(await h.run(h.OWNER, '.بنك تصفير تأكيد'), /التصفير اتلغى/);
        } finally { fs.unlinkSync(snapDir); }
        assert.ok(h.dm.get('bank')[h.G]);
        const results = (await h.auditEntries()).map(e => `${e.action}:${e.result}`);
        assert.ok(results.includes('bank-reset:ok') && results.includes('bank-reset:aborted-backup-failed'), results.join());
    });

    it('BackupService بيتجاهل مجلد bank-resets ومبيمسحوش', async () => {
        fs.mkdirSync(snapDir, { recursive: true });
        const BackupService = sb.require('bot/services/backupService');
        const backupDir = sb.resolvePath('bot', 'backups');
        for (let i = 1; i <= 3; i++) fs.mkdirSync(path.join(backupDir, `2026-01-0${i}_00-00-00`), { recursive: true });
        const service = new BackupService({ dataDir: sb.resolvePath('bot', 'data'), backupDir, keep: 2, logger: { info() {}, warn() {}, error() {} } });
        await service.backupNow();
        const left = fs.readdirSync(backupDir);
        assert.ok(left.includes('bank-resets'));
        assert.equal(left.filter(x => /^\d{4}-/.test(x)).length, 2);
    });
});

describe('الاقتصاد: ماكينة الأموال والمكافآت والتوقيت وتنضيف المتجر', () => {
    let sb, h;
    before(async () => { sb = createSandbox(); h = await createHarness(sb, { loadPlugins: false, middlewares: false }); });

    it('ماكينة الأموال: صفر رصيد، منع التكرار، تعويض الغياب، 168 دفعة بالظبط، ومسح بعد الانتهاء', () => {
        const { state } = sb.require('bot/libs/shop/storage');
        const { processMoneyMachines, TICK_MS, DURATION_MS } = sb.require('bot/libs/shop/moneyMachine');
        for (const k of Object.keys(state.moneyMachines)) delete state.moneyMachines[k];
        for (const k of Object.keys(state.machinePaid)) delete state.machinePaid[k];
        const now = Date.now(), H = TICK_MS, G = 'g@g.us';
        const bank = { [G]: { accounts: { u1: 0 } } };
        state.moneyMachines.u1 = now - 3 * H + DURATION_MS;
        processMoneyMachines(bank, () => {}, now);
        assert.equal(bank[G].accounts.u1, 300000);
        processMoneyMachines(bank, () => {}, now);
        assert.equal(bank[G].accounts.u1, 300000);
        processMoneyMachines(bank, () => {}, now + 48 * H);
        assert.equal(bank[G].accounts.u1, 300000 + 48 * 100000);
        processMoneyMachines(bank, () => {}, now - 3 * H + DURATION_MS + 5 * H);
        assert.equal(bank[G].accounts.u1, 168 * 100000);
        assert.ok(!state.moneyMachines.u1 && !state.machinePaid.u1);
    });

    it('ماكينة الأموال: لاعب من غير حساب بياخد المتأخر لما يبقى له حساب', () => {
        const { state } = sb.require('bot/libs/shop/storage');
        const { processMoneyMachines, TICK_MS, DURATION_MS } = sb.require('bot/libs/shop/moneyMachine');
        const now = Date.now(), G = 'g@g.us', bank = {};
        state.moneyMachines.u2 = now - 5 * TICK_MS + DURATION_MS;
        processMoneyMachines(bank, () => {}, now);
        assert.ok(state.moneyMachines.u2);
        bank[G] = { accounts: { u2: 10 } };
        processMoneyMachines(bank, () => {}, now);
        assert.equal(bank[G].accounts.u2, 10 + 500000);
    });

    it('todayKey بتوقيت القاهرة و weekKey متوافقة مع المعادلة القديمة', () => {
        const T = sb.require('bot/utils/time');
        const k = (iso) => T.todayKey(new Date(iso));
        assert.equal(k('2026-10-14T22:30:00Z'), '2026-10-15');           // الصيف UTC+3
        assert.equal(k('2026-10-14T20:59:00Z'), '2026-10-14');
        assert.equal(k('2026-10-14T21:00:00Z'), '2026-10-15');
        assert.equal(k('2026-12-01T21:30:00Z'), '2026-12-01');           // الشتا UTC+2
        assert.equal(k('2026-12-01T22:00:00Z'), '2026-12-02');
        const oldWeek = (d) => `${d.getFullYear()}-W${Math.ceil((((d - new Date(d.getFullYear(), 0, 1)) / 864e5) + new Date(d.getFullYear(), 0, 1).getDay() + 1) / 7)}`;
        for (let m = 0; m < 12; m++) for (const day of [3, 10, 17, 24]) {
            assert.equal(T.weekKey(new Date(Date.UTC(2026, m, day, 10))), oldWeek(new Date(2026, m, day, 10)));
        }
        const helpers = sb.require('bot/libs/shop/helpers');
        assert.equal(helpers.todayKey(), T.todayKey());
        assert.equal(fs.readFileSync(sb.resolvePath('bot/libs/shop/commands/boxes.js'), 'utf8').includes('function weekKey'), false);
    });

    it('مكافآت الرسايل: سقف يومي، والمتأخر بيتصرف في الأيام اللي بعده، والسقف من config', async () => {
        const StatsHandler = sb.require('bot/handlers/statsHandler');
        const stats = new StatsHandler(h.container);
        const [G, U1, U2] = ['g@g.us', 'u1@s.whatsapp.net', 'u2@s.whatsapp.net'];
        const paid = []; const ctx = { addBankMoney: (g, j, a) => paid.push([j, a]) }; const sock = { sendMessage: async () => ({}) };
        h.dm.set('cumulativeMessages', { [G]: { [U1]: 5000, [U2]: 999 } });
        const realNow = Date.now; let clock = realNow.call(Date);
        Date.now = () => clock;
        try {
            await stats.checkBonuses(sock, G, U1, ctx);
            assert.deepEqual(paid.map(p => p[1]), [500000, 250000]);
            await stats.checkBonuses(sock, G, U1, ctx);
            assert.equal(paid.length, 2);
            await stats.checkBonuses(sock, G, U2, ctx);
            assert.equal(paid.length, 2);
            const perDay = [];
            for (let d = 0; d < 6; d++) { clock += 25 * 3600 * 1000; const before = paid.length; await stats.checkBonuses(sock, G, U1, ctx); perDay.push(paid.length - before); }
            assert.deepEqual(perDay, [2, 2, 2, 1, 0, 0]);
            assert.equal(paid.reduce((s, p) => s + p[1], 0), 500000 + 8 * 250000);
        } finally { Date.now = realNow; }
        h.config.economy.MESSAGE_BONUS_MAX_PER_DAY = 1; paid.length = 0;
        h.dm.set('cumulativeMessages', { [G]: { [U2]: 3000 } });
        await stats.checkBonuses(sock, G, U2, ctx);
        assert.equal(paid.length, 1);
    });

    it('تنضيف الحماية والحجوزات: المتجر هو المالك الوحيد، ويدعم الصيغة الجديدة والقديمة ويحفظ على القرص', () => {
        const storage = sb.require('bot/libs/shop/storage');
        const { cleanupExpired } = sb.require('bot/libs/shop/maintenance');
        const now = Date.now(), G = 'g@g.us';
        storage.state.protection[G] = { u2: { expiry: now + 1e7, level: 2 }, u3: { expiry: now - 1000, level: 1 }, u4: now - 5000 };
        storage.state.reservations[G] = { 'لقب': { jid: 'u1', expires: now - 1 }, 'لقب2': { jid: 'u5', expires: now + 1e7 } };
        cleanupExpired(now);
        assert.deepEqual(Object.keys(storage.state.protection[G]), ['u2']);
        assert.deepEqual(Object.keys(storage.state.reservations[G]), ['لقب2']);
        const onDisk = (f) => JSON.parse(fs.readFileSync(sb.resolvePath('bot', 'data', f), 'utf8'));
        assert.deepEqual(Object.keys(onDisk('protection.json')[G]), ['u2']);
        assert.deepEqual(Object.keys(onDisk('reservations.json')[G]), ['لقب2']);
        assert.equal(/\['(protection|reservations)'/.test(fs.readFileSync(sb.resolvePath('bot/core/bootstrap.js'), 'utf8')), false);
    });
});
