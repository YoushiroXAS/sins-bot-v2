'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');
const { sleep } = require('./helpers/harness');

exitWhenDone(after);

describe('الـ AI: حدود الاستخدام والذاكرة', () => {
    let sb, ai, axios, realPost, personalityFile, apiCalls = 0;
    before(() => {
        process.env.GROQ_API_KEY = 'test-key';                   // علشان Groq يتفعّل ونتحكم في سرعة الرد (config بيقراه وقت التحميل)
        sb = createSandbox();
        axios = sb.requirePkg('axios'); realPost = axios.post;
        axios.post = async () => { apiCalls++; await sleep(300); return { data: { choices: [{ message: { content: 'رد تجريبي' } }] } }; };
        personalityFile = sb.resolvePath('bot', 'data', 'user-personality.json');
        fs.writeFileSync(personalityFile, JSON.stringify({ u9: { messages: [{ text: 'قديمة', timestamp: Date.now() - 40 * 864e5 }, { text: 'حديثة', timestamp: Date.now() - 864e5 }], totalUses: 5, style: null, styleCounts: {} } }));
        ai = sb.require('bot/libs/ai');
    });
    after(() => { delete process.env.GROQ_API_KEY; if (axios) axios.post = realPost; });

    it('5 طلبات متوازية من نفس المستخدم: 3 بس بيتنفذوا والباقي بيترفض من غير نداء API', async () => {
        const replies = await Promise.all([1, 2, 3, 4, 5].map(i => ai.askAI(`سؤال ${i}`, 'u1')));
        assert.equal(replies.filter(r => r === 'رد تجريبي').length, 3);
        assert.equal(replies.filter(r => r.includes('لسه بتتنفذ')).length, 2);
        assert.equal(apiCalls, 3);
    });

    it('مستخدم تاني مش متأثر، والمستخدم بيرجع يشتغل، والـ queue/pending Maps بتفضى', async () => {
        assert.equal(await ai.askAI('سؤال', 'u2'), 'رد تجريبي');
        assert.equal(await ai.askAI('تاني', 'u1'), 'رد تجريبي');
        await sleep(50);
        assert.deepEqual(ai.getQueueStats(), { queues: 0, pendingUsers: 0 });
    });

    it('طول السؤال: 1001 حرف مرفوض و1000 مقبول، والسؤال الفاضي بيتردله رد من غير نداء API', async () => {
        assert.match(await ai.askAI('س'.repeat(1001), 'u3'), /طويل/);
        assert.equal(await ai.askAI('س'.repeat(1000), 'u3'), 'رد تجريبي');
        const before = apiCalls;
        assert.ok((await ai.askAI('   ', 'u3')).length > 0);
        assert.equal(apiCalls, before);
    });

    it('الاحتفاظ: رسالة عمرها 40 يوم بتتمسح من user-personality.json والحديثة والجديدة بتفضل', async () => {
        await ai.askAI('سؤال جديد', 'u9');
        await sleep(50);
        const texts = JSON.parse(fs.readFileSync(personalityFile, 'utf8')).u9.messages.map(m => m.text);
        assert.ok(!texts.includes('قديمة') && texts.includes('حديثة') && texts.includes('سؤال جديد'), texts.join());
    });
});
