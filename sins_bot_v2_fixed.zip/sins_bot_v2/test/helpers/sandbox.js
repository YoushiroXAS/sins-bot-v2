'use strict';
/**
 * sandbox - نسخة مؤقتة من المشروع لكل ملف اختبار
 *
 * الاختبارات بتنفّذ أوامر حقيقية بتكتب في bot/data و bot/logs و bot/backups، فبتشتغل كلها على
 * نسخة في مجلد مؤقت (os.tmpdir) بتتمسح في الآخر، وبيانات البوت الأصلية مبتتلمسش أبدًا.
 *
 * المكتبات: لو المكتبة متثبّتة (بعد npm install) بتتستخدم هي. لو ناقصة، بتتحط بديل بسيط جوه
 * النسخة المؤقتة بس (مش في node_modules بتاعتك) عشان الاختبارات تشتغل حتى من غير تثبيت كامل.
 * sandbox.stubbed بيقول أنهي مكتبات اتبدّلت. لو baileys الحقيقية متثبّتة، اختبار الـ shutdown
 * (اللي بيشغّل index.js) بيتخطى نفسه عشان مايحاولش يتصل بواتساب فعلًا.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');

const PROJECT = path.resolve(__dirname, '..', '..');

const STUBS = {
    '@whiskeysockets/baileys': `module.exports = {
  default: () => ({ authState: { creds: { registered: true } }, ev: { on() {} }, user: { id: '1:1@s.whatsapp.net' } }),
  useMultiFileAuthState: async () => ({ state: {}, saveCreds: async () => {} }),
  DisconnectReason: { loggedOut: 401, connectionReplaced: 440, restartRequired: 515 },
  fetchLatestBaileysVersion: async () => ({ version: [1, 0, 0] }),
  downloadContentFromMessage: async () => ({}), jidDecode: () => ({}), proto: {},
};`,
    pino: `module.exports = () => ({ info() {}, warn() {}, error() {}, debug() {}, fatal() {}, child() { return this; } });`,
    axios: `const f = { get: async () => ({ data: {} }), post: async () => ({ data: {} }), interceptors: { request: { use() {} }, response: { use() {} } } };
module.exports = { ...f, create: () => f };`,
    canvas: `module.exports = { createCanvas: () => ({ getContext: () => ({}), toBuffer: () => Buffer.alloc(1) }) };`,
    cheerio: `module.exports = { load: () => () => ({}) };`,
    'chess.js': `class Chess { isGameOver() { return false; } isCheckmate() { return false; } isDraw() { return false; } fen() { return ''; } turn() { return 'w'; } move() { return null; } }
module.exports = { Chess };`,
    'soundcloud-downloader': `module.exports = { default: { search() {}, download() {} } };`,
    'yt-search': `module.exports = function ytSearch() {};`,
};

function canResolve(name) {
    try { require.resolve(name, { paths: [PROJECT] }); return true; } catch { return false; }
}

function createSandbox() {
    const root = fs.mkdtempSync(path.join(os.tmpdir(), 'sins-test-'));
    const skip = new Set(['node_modules', '.git', path.join('bot', 'assets'), path.join('bot', 'backups'), path.join('bot', 'logs'), path.join('bot', 'session')]);
    fs.cpSync(PROJECT, root, { recursive: true, filter: (src) => !skip.has(path.relative(PROJECT, src)) });

    const missing = Object.keys(STUBS).filter(n => !canResolve(n));
    const projectNM = path.join(PROJECT, 'node_modules');
    const nm = path.join(root, 'node_modules');
    if (!missing.length) {
        if (fs.existsSync(projectNM)) fs.symlinkSync(projectNM, nm, 'dir');
    } else {
        fs.mkdirSync(nm, { recursive: true });
        if (fs.existsSync(projectNM)) {
            for (const entry of fs.readdirSync(projectNM)) {
                if (entry.startsWith('@')) {
                    fs.mkdirSync(path.join(nm, entry), { recursive: true });
                    for (const sub of fs.readdirSync(path.join(projectNM, entry))) {
                        if (!missing.includes(`${entry}/${sub}`)) fs.symlinkSync(path.join(projectNM, entry, sub), path.join(nm, entry, sub), 'dir');
                    }
                } else if (!missing.includes(entry)) {
                    fs.symlinkSync(path.join(projectNM, entry), path.join(nm, entry), 'dir');
                }
            }
        }
        for (const name of missing) {
            const dir = path.join(nm, name);
            fs.mkdirSync(dir, { recursive: true });
            fs.writeFileSync(path.join(dir, 'index.js'), STUBS[name]);
            fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name, version: '0.0.0-test-stub', main: 'index.js' }));
        }
    }

    const cleanup = () => { try { fs.rmSync(root, { recursive: true, force: true }); } catch { /* ignore */ } };
    process.on('exit', cleanup);
    return {
        root,
        stubbed: new Set(missing),
        require: (rel) => require(path.join(root, rel)),
        // مكتبة npm من نفس مكان resolve اللي الكود بتاعنا بيستخدمه (عشان نعدّل نفس النسخة)
        requirePkg: (name) => require(require.resolve(name, { paths: [root] })),
        resolvePath: (...parts) => path.join(root, ...parts),
        cleanup,
    };
}

// بعض الألعاب (مذكرة الموت مثلًا) عندها timers طويلة، فبعد ما الاختبارات تخلص بنقفل الـ process
// بعد لحظة (الـ timer ده unref فلو مفيش حاجة شغالة الـ process بيقفل طبيعي قبله).
function exitWhenDone(after) {
    after(() => { setTimeout(() => process.exit(process.exitCode || 0), 300).unref(); });
}

module.exports = { createSandbox, exitWhenDone, PROJECT };
