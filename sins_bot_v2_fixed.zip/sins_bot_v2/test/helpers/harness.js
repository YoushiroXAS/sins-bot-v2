'use strict';
/**
 * harness - بيجهّز Container + dataManager + registry + handler حقيقيين جوه sandbox،
 * وبيدّي run(sender, text) بينفّذ رسالة حقيقية عن طريق MessageHandler.handle.
 */
const path = require('path');

const STORES = [
    ['bank', 'bank.json', {}], ['titles', 'nickname.json', {}], ['developers', 'developers.json', []],
    ['elites', 'elites.json', []], ['stats', 'stats.json', { totalMessages: {}, groups: {} }],
    ['cumulativeMessages', 'cumulative_messages.json', {}], ['bonusState', 'bonus_state.json', { messages: {} }],
    ['points', 'points.json', {}],
];

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function createHarness(sb, { loadPlugins = true, middlewares = true } = {}) {
    const container = sb.require('bot/core/Container');
    const config = sb.require('bot/config');
    const dm = container.get('dataManager');
    container.get('logger').enableConsole = false; // اللوج بيتكتب في ملف النسخة المؤقتة بس، مش على شاشة الاختبار
    for (const [key, file, def] of STORES) await dm.init(key, sb.resolvePath('bot', 'data', file), def, false);

    const registry = container.get('commandRegistry');
    const warnings = [];
    let report = null;
    if (loadPlugins) {
        const realWarn = console.warn;
        console.warn = (...a) => warnings.push(a.join(' '));
        try { report = registry.loadAllWithPluginsDir(sb.resolvePath('bot', 'plugins')); } finally { console.warn = realWarn; }
    }
    if (middlewares) for (const m of ['rateLimitMiddleware', 'permissionMiddleware', 'cooldownMiddleware']) registry.use(container.get(m));

    const MessageHandler = sb.require('bot/handlers/handler');
    const handler = new MessageHandler(container);

    const replies = [];
    const sock = {
        user: { id: '9@s.whatsapp.net' },
        sendMessage: async (to, m) => { replies.push(m.text || '[media]'); return {}; },
        groupMetadata: async () => ({ participants: [] }),
    };

    const G = 'g@g.us';
    const OWNER = `${config.ownerNumber}@s.whatsapp.net`;
    const mk = (sender, text, { target, reply, fromMe = false, id } = {}) => ({
        key: { remoteJid: G, participant: sender, fromMe, id: id || 'M' + Math.random() },
        message: (target || reply)
            ? { extendedTextMessage: { text, contextInfo: { ...(target ? { mentionedJid: [target] } : {}), participant: reply || target } } }
            : { conversation: text },
        pushName: 'x',
    });
    const run = async (sender, text, opts) => {
        replies.length = 0;
        await handler.handle(sock, mk(sender, text, opts));
        await sleep(40);
        return replies.join(' | ');
    };

    return {
        container, config, dm, registry, handler, sock, replies, report, warnings, run, mk, sleep,
        G, OWNER, DEV: '201111111111@s.whatsapp.net', ELITE: '201222222222@s.whatsapp.net',
        U1: '201444444444@s.whatsapp.net', U2: '201555555555@s.whatsapp.net',
        balance: (jid, group = G) => dm.get('bank')[group]?.accounts?.[jid],
        resetLimits: () => { const rl = container.get('rateLimiter'); for (const id of ['201444444444@s.whatsapp.net', '201555555555@s.whatsapp.net']) rl.reset(id); },
        auditEntries: async () => {
            await sleep(80);
            try { return require('fs').readFileSync(path.join(sb.root, 'bot/logs/audit.log'), 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse); } catch { return []; }
        },
    };
}

module.exports = { createHarness, sleep };
