'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');
const { createHarness, sleep } = require('./helpers/harness');

exitWhenDone(after);

const quietLogger = (extra = {}) => ({ info() {}, success() {}, warn() {}, error() {}, ...extra });

function makeBotService(sb, h, overrides = {}) {
    const BotService = sb.require('bot/services/botService');
    const bs = new BotService(h.container);
    Object.defineProperty(bs, 'logger', { value: quietLogger() });
    Object.defineProperty(bs, 'eventBus', { value: { emit() {} } });
    Object.defineProperty(bs, 'monitor', { value: { trackMessage() {} } });
    for (const [k, v] of Object.entries(overrides)) Object.defineProperty(bs, k, { value: v });
    return bs;
}

describe('الاتصال والرسايل (botService)', () => {
    let sb, h;
    before(async () => { sb = createSandbox(); h = await createHarness(sb, { loadPlugins: false, middlewares: false }); });

    it('messages.upsert: بيتجاهل type=append، وبيمنع تنفيذ نفس الرسالة مرتين', async () => {
        const seen = [];
        const bs = makeBotService(sb, h, { handler: { handle: async (s, m) => seen.push(m.key.id) } });
        const M = (id) => ({ key: { remoteJid: 'g@g.us', id }, message: { conversation: 'x' } });
        await bs._handleMessages({ type: 'append', messages: [M('H1')] });
        assert.deepEqual(seen, []);
        await bs._handleMessages({ type: 'notify', messages: [M('A'), M('A'), M('B')] });
        assert.deepEqual(seen, ['A', 'B']);
        await bs._handleMessages({ type: 'notify', messages: [M('A')] });
        assert.deepEqual(seen, ['A', 'B']);
    });

    it('إعادة الاتصال: backoff + jitter، مجدولة واحدة بس، 515 سريعة ومش بتتحسب، 440 و401 بدون reconnect، وبعد الحد الأقصى إيقاف آمن', async () => {
        const bs = makeBotService(sb, h);
        let started = 0, detached = 0;
        bs.start = async () => { started++; };
        bs._detachSocket = () => { detached++; };
        const close = (code) => bs._handleConnectionUpdate({ connection: 'close', lastDisconnect: { error: { output: { statusCode: code } } } });
        const realSetTimeout = global.setTimeout; const captured = [];
        global.setTimeout = (fn, ms) => { captured.push({ fn, ms }); return { unref() {}, ref() {} }; };
        let fatal = null;
        const onFatal = (reason) => { fatal = reason; };
        process.once('app:fatal', onFatal);
        try {
            await close(428); await close(428);
            assert.equal(captured.length, 1);
            assert.ok(captured[0].ms >= 5000 && captured[0].ms < 6000, `delay=${captured[0].ms}`);
            captured[0].fn();
            assert.equal(started, 1); assert.equal(detached, 1);

            captured.length = 0; await close(515);
            assert.equal(captured[0].ms, 1000); assert.equal(bs.reconnectAttempts, 1);
            captured[0].fn();

            captured.length = 0; await close(440); assert.equal(captured.length, 0);
            await close(401); assert.equal(captured.length, 0);

            bs.reconnectAttempts = 10; await close(428);
        } finally { global.setTimeout = realSetTimeout; process.removeListener('app:fatal', onFatal); }
        assert.match(String(fatal), /reconnection/);
    });

    it('start() المتكرر مبيزوّدش timers، و shutdown() بيوقف الكل ومبيسمحش بجدولة جديدة', async () => {
        const bs = makeBotService(sb, h);
        bs._scheduleCleanup(); const cleanup = bs._cleanupTimer; bs._scheduleCleanup(); bs._scheduleCleanup();
        assert.equal(bs._cleanupTimer, cleanup);
        bs._scheduleDailyReset(); const first = bs._dailyResetTimer; bs._scheduleDailyReset(); bs._scheduleDailyReset();
        assert.ok(first._destroyed); assert.notEqual(bs._dailyResetTimer, first);
        await bs.shutdown();
        assert.ok(bs._stopping && !bs._cleanupTimer && !bs._dailyResetTimer);
        bs._scheduleDailyReset();
        assert.equal(bs._dailyResetTimer, null);
    });

    it('الإيقاف: بيبلّغ الجروبات اللي فيها لعبة أو تسجيل مفتوح مرة واحدة (والخاص لأ)، ومبيتعطّلش لو الإرسال علّق', async () => {
        const h2 = await createHarness(sb);                      // بلجنز محمّلة => مكتبات الألعاب متحمّلة
        const dn = sb.require('bot/libs/deathnote'), spy = sb.require('bot/libs/spygame'), chess = sb.require('bot/libs/chess');
        dn.activeGames.set('g1@g.us', {}); spy.registrationSessions.set('g2@g.us', {}); chess.activeGames.set('201@s.whatsapp.net', {});
        h2.handler.gameRouter; // يتأكد إن الـ router اتعمل
        const sent = [];
        const bs = makeBotService(sb, h2, { _handler: h2.handler });
        bs.sock = { sendMessage: async (chat, m) => { sent.push(chat); return {}; } };
        await bs.shutdown();
        assert.deepEqual(sent.sort(), ['g1@g.us', 'g2@g.us']);
        await bs.shutdown();
        assert.equal(sent.length, 2, 'الإعلان اتكرر');
        assert.equal(bs._stopping, true);

        const slow = makeBotService(sb, h2, { _handler: h2.handler });
        slow.sock = { sendMessage: () => new Promise(() => {}) };   // مبيرجعش أبدًا
        const t0 = Date.now(); await slow.shutdown(); const took = Date.now() - t0;
        assert.ok(took < 4500, `الإيقاف خد ${took}ms`);
        dn.activeGames.delete('g1@g.us'); spy.registrationSessions.delete('g2@g.us'); chess.activeGames.delete('201@s.whatsapp.net');
    });
});

describe('GameManager.isBotAdmin (جروبات LID)', () => {
    it('بيلاقي البوت بالرقم أو بالـ LID أو بـ jid، وبيفرّق بين أدمن وعضو عادي', async () => {
        const sb = createSandbox();
        const GameManager = sb.require('bot/utils/gameManager');
        const gm = new GameManager();
        const sockWith = (participants) => ({ user: { id: '9:12@s.whatsapp.net', lid: '555:3@lid' }, groupMetadata: async () => ({ participants }) });
        try {
            assert.equal(await gm.isBotAdmin(sockWith([{ id: '9@s.whatsapp.net', admin: 'admin' }]), 'g@g.us'), true);          // الشكل القديم
            assert.equal(await gm.isBotAdmin(sockWith([{ id: '555@lid', admin: 'superadmin' }]), 'g@g.us'), true);             // id بـ LID (كان بيفشل)
            assert.equal(await gm.isBotAdmin(sockWith([{ id: '777@lid', jid: '9@s.whatsapp.net', admin: 'admin' }]), 'g@g.us'), true);   // LID في id، ورقم البوت في jid
            assert.equal(await gm.isBotAdmin(sockWith([{ id: '777@lid', phoneNumber: '9@s.whatsapp.net', admin: 'admin' }]), 'g@g.us'), true);
            assert.equal(await gm.isBotAdmin(sockWith([{ id: '555@lid', admin: null }]), 'g@g.us'), false);                    // البوت عضو عادي
            assert.equal(await gm.isBotAdmin(sockWith([{ id: '888@lid', admin: 'admin' }]), 'g@g.us'), false);                 // أدمن تاني
            assert.equal(await gm.isBotAdmin({ user: {}, groupMetadata: async () => { throw new Error('x'); } }, 'g@g.us'), false);
        } finally { await gm.shutdown(); }
    });
});

describe('الـ rate limiter', () => {
    it('config.rateLimit بيأثر فعلًا على الـ limiter اللي الـ Container بيعمله', () => {
        const sb = createSandbox();
        sb.require('bot/config').rateLimit.MAX_REQUESTS = 3;
        const limiter = sb.require('bot/core/Container').get('rateLimiter');
        assert.equal(limiter.config.MAX_REQUESTS, 3);
        let allowed = 0; for (let i = 0; i < 6; i++) if (limiter.isAllowed('u1')) allowed++;
        assert.equal(allowed, 3);
        limiter.shutdown();
    });

    it('سبام 40 أمر: 10 بس بيتنفذوا، والبوت بيبلّغ مرة واحدة لكل فترة حظر', async () => {
        const sb = createSandbox();
        const h = await createHarness(sb, { loadPlugins: false, middlewares: false });
        const mw = h.container.get('rateLimitMiddleware');
        const sent = []; const sock = { sendMessage: async (to, m) => { sent.push(m.text); return {}; } };
        const realNow = Date.now; let clock = realNow.call(Date);
        Date.now = () => clock;
        try {
            const ctx = { sender: 'spammer', from: 'g@g.us', sock, isOwner: false };
            let allowed = 0; for (let i = 0; i < 40; i++) if (mw(ctx, {})) allowed++;
            await sleep(5);
            assert.equal(allowed, 10); assert.equal(sent.length, 1);
            clock += 61_000; sent.length = 0;
            for (let i = 0; i < 25; i++) mw(ctx, {});
            await sleep(5);
            assert.equal(sent.length, 1);
            const owner = { sender: 'owner', from: 'g@g.us', sock, isOwner: true };
            for (let i = 0; i < 40; i++) assert.equal(mw(owner, {}), true);
        } finally { Date.now = realNow; }
    });
});

describe('الترحيب التلقائي و init البلجنز', () => {
    let sb, h, axios, realGet;
    before(async () => {
        sb = createSandbox(); h = await createHarness(sb);
        axios = sb.requirePkg('axios'); realGet = axios.get;
        axios.get = async () => ({ data: {} });                 // مفيش اتصال بالإنترنت في الاختبار
        fs.writeFileSync(sb.resolvePath('bot', 'data', 'activeWelcome.json'), JSON.stringify([h.G]));   // الجروب مفعّل من قبل الـ restart
    });
    after(() => { if (axios) axios.get = realGet; });

    const mkSock = () => {
        const s = { handlers: {}, onCalls: 0, sent: [], user: { id: '1@s.whatsapp.net' }, sendMessage: async (to, m) => { s.sent.push(m.text || '[img]'); return {}; } };
        s.ev = { on: (name, fn) => { s.onCalls++; s.handlers[name] = fn; } };
        return s;
    };
    const join = async (s, jid) => {
        const handler = s.handlers['group-participants.update'];
        if (!handler) return false;
        await handler({ id: h.G, action: 'add', participants: [jid] });
        return s.sent.length > 0;
    };

    it('الترحيب شغال بعد "restart" وبعد "reconnect" بـ listener واحد لكل socket', async () => {
        const bs = makeBotService(sb, h);
        const A = mkSock(); bs.sock = A;
        await bs._handleConnectionUpdate({ connection: 'open' });
        assert.equal(await join(A, '201000000001@s.whatsapp.net'), true);
        const B = mkSock(); bs.sock = B;
        await bs._handleConnectionUpdate({ connection: 'open' });
        await bs._handleConnectionUpdate({ connection: 'open' });
        assert.equal(await join(B, '201000000002@s.whatsapp.net'), true);
        assert.equal(B.onCalls, 1);
    });

    it('registry.initPlugins بتنادي init مرة لكل بلجن وبترجّع العدد', () => {
        const calls = [];
        const registry = h.registry;
        const plugin = { command: ['اختبار_init', 'اختبار_init2'], execute: async () => {}, init: (sock) => calls.push(sock) };
        registry._commands.set('اختبار_init', { ...plugin, path: 'fake-plugin.js', name: 'اختبار_init' });
        registry._commands.set('اختبار_init2', { ...plugin, path: 'fake-plugin.js', name: 'اختبار_init2' });
        const marker = { marker: true };
        const count = registry.initPlugins(marker);
        assert.ok(count >= 2);                                  // البلجن الوهمي (مرة واحدة رغم الـ alias) + welcome
        assert.equal(calls.filter(c => c === marker).length, 1);
    });
});
