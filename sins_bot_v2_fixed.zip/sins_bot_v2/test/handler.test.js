'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');
const { createHarness } = require('./helpers/harness');

describe('handler والأوامر', () => {
    let sb, h;
    before(async () => { sb = createSandbox(); h = await createHarness(sb); });
    exitWhenDone(after);

    it('كل البلجنز بتتحمّل من غير فشل ولا تعارض أسماء أوامر', () => {
        const files = fs.readdirSync(sb.resolvePath('bot', 'plugins')).filter(f => f.endsWith('.js'));
        assert.deepEqual(h.report.failures, []);
        assert.equal(h.report.loaded, files.length);
        assert.ok(h.report.commands > 0);
        assert.deepEqual(h.warnings.filter(w => w.includes('تعارض')), []);
    });

    it('هوية المالك/المطور/النخبة: رقم، رقم+جهاز، LID، والرقم المشابه مش مالك', () => {
        const { ownerNumber, ownerLID } = h.config;
        h.dm.set('developers', [h.DEV]); h.dm.set('elites', [h.ELITE]);
        const who = (jid) => {
            const c = h.handler._buildContext({}, h.G, jid, true, 'bot@s.whatsapp.net');
            return c.isOwner ? 'owner' : c.isDeveloper ? 'dev' : c.isElite ? 'elite' : 'user';
        };
        assert.equal(who(`${ownerNumber}@s.whatsapp.net`), 'owner');
        assert.equal(who(`${ownerNumber}:12@s.whatsapp.net`), 'owner');
        assert.equal(who(`${ownerLID}@lid`), 'owner');
        assert.equal(who(`9999${ownerNumber}@s.whatsapp.net`), 'user');   // كان بيتحسب مالك بالـ endsWith
        assert.equal(who(h.DEV), 'dev');
        assert.equal(who(h.DEV.replace('@', ':3@')), 'dev');
        assert.equal(who(h.ELITE), 'elite');
        assert.equal(who('201333333333@s.whatsapp.net'), 'user');
    });

    it('.رصيد و.ايداع شغالين (توقيع البلجنز القديم + saveBank)', async () => {
        assert.match(await h.run(h.U1, '.رصيد'), /رصيدك/);
        await h.run(h.OWNER, '.ايداع 500');
        assert.equal(h.balance(h.OWNER), 500);
    });

    it('.ايقاف و.تشغيل (botstatus) بيعملوا الإيقاف والتشغيل', async () => {
        assert.match(await h.run(h.OWNER, '.ايقاف'), /تم إيقاف/);
        assert.equal(await h.run(h.U1, '.رصيد'), '');
        assert.match(await h.run(h.OWNER, '.تشغيل'), /تم تشغيل/);
        assert.match(await h.run(h.U1, '.رصيد'), /رصيدك/);
    });

    it('رسالة أطول من MAX_MESSAGE_LENGTH بتتجاهل، ورسايل البوت (fromMe) مبتتحسبش في الإحصائيات', async () => {
        assert.equal(await h.run(h.U1, '.رصيد ' + 'x'.repeat(5000)), '');
        let tracked = 0;
        const original = h.handler.statsHandler.track.bind(h.handler.statsHandler);
        h.handler.statsHandler.track = (...a) => { tracked++; return original(...a); };
        await h.run(h.U1, 'مرحبا');
        const before = tracked;
        await h.run(h.U1, 'مرحبا', { fromMe: true, id: 'FM1' });
        assert.equal(tracked, before);
    });

    it('الـ cooldown بيمنع استخدام alias للأمر نفسه', async () => {
        h.resetLimits();
        await h.run(h.U1, '.حالة');
        assert.match(await h.run(h.U1, '.status'), /انتظر/);
    });

    it("resolveItemName('constructor') بيرجّع النص، والـ aliases الحقيقية شغالة", () => {
        const { resolveItemName } = sb.require('bot/libs/shop/helpers');
        assert.equal(resolveItemName('constructor'), 'constructor');
        assert.equal(resolveItemName('toString'), 'toString');
        assert.equal(resolveItemName('قفل'), 'قفل الحساب');
    });

    it('كل أمر مشترك له مالك واحد: شارك وابدأ في global_commands، وتلميح في games', () => {
        const owner = (name) => h.registry.getCommand(name).path.split(/[\\/]/).pop();
        assert.equal(owner('شارك'), 'global_commands.js');
        assert.equal(owner('ابدأ'), 'global_commands.js');
        assert.equal(owner('تلميح'), 'games.js');
    });

    it('.شارك بيسجّل في مذكرة الموت لما تسجيلها مفتوح (مش بيفتح تسجيل تجسس)، ومن غير تسجيل بيرد برسالة', async () => {
        const dn = sb.require('bot/libs/deathnote'), spy = sb.require('bot/libs/spygame');
        h.dm.set('titles', { [h.G]: { [h.OWNER]: 'المالك', [h.U1]: 'لاعب1' } });
        assert.match(await h.run(h.U1, '.شارك'), /لا يوجد باب تسجيل/);
        assert.equal(spy.registrationSessions.has(h.G), false);
        const ctx = h.handler._buildContext(h.sock, h.G, h.OWNER, true, '9@s.whatsapp.net');
        await dn.openRegistration(h.sock, h.G, h.OWNER, ctx);
        assert.equal(dn.registrationSessions.has(h.G), true);
        assert.notEqual(await h.run(h.U1, '.شارك'), '');
        assert.equal(spy.registrationSessions.has(h.G), false);
        dn.registrationSessions.delete(h.G);
    });

    it('.تلميح بيوصل لمذكرة الموت لما تكون هي اللعبة الشغالة', async () => {
        const dn = sb.require('bot/libs/deathnote');
        dn.activeGames.set(h.G, { phase: 'playing', currentRound: { hintUsed: false, answers: [['كراسة']] } });
        h.replies.length = 0;
        const body = '.تلميح';
        await h.registry.execute('تلميح', {
            ...h.handler._buildContext(h.sock, h.G, h.U1, true, '9@s.whatsapp.net'),
            msg: h.mk(h.U1, body), body, args: [], command: 'تلميح',
        });
        dn.activeGames.delete(h.G);
        assert.match(h.replies.join(' '), /كراسة/);
    });

    it('gameRouter: الرقم في الجروب يوصل للعبة النشطة لو مفيش بحث أغاني، والخطأ بيتسجّل مرة واحدة', async () => {
        const GameRouter = sb.require('bot/handlers/gameRouter');
        const router = new GameRouter(h.container);
        const got = []; const errs = [];
        router._games = { hasActiveGame: () => true, checkGameAnswer: async (s, from, sender, body) => { got.push(body); return true; } };
        router._deathnote = { activeGames: new Map() }; router._chess = { activeGames: new Map() };
        router.logger = { error: (m) => errs.push(m), info() {}, warn() {} };
        router._handleSongNumber = async () => false;
        assert.equal(await router.route({}, {}, '42', h.G, 'u', true, {}), true);
        assert.deepEqual(got, ['42']);
        got.length = 0; router._handleSongNumber = async () => true;
        await router.route({}, {}, '3', h.G, 'u', true, {});
        assert.deepEqual(got, []);
        router._games.checkGameAnswer = async () => { throw new Error('boom'); };
        for (let i = 0; i < 3; i++) assert.equal(await router.route({}, {}, 'كلمة', h.G, 'u', true, {}), false);
        assert.equal(errs.length, 1);
    });
});
