'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const dnsPromises = require('dns').promises;
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');
const { createHarness, sleep } = require('./helpers/harness');

exitWhenDone(after);

describe('الأمان: روابط التحميل', () => {
    let sb, axios, realCreate;
    before(() => { sb = createSandbox(); axios = sb.requirePkg('axios'); realCreate = axios.create; });
    after(() => { axios.create = realCreate; });

    it('فحص العناوين: كل المدى الداخلي والمحلي مرفوض والعناوين العامة مقبولة', () => {
        const { isPrivateIp, isSafeHostnameSync } = sb.require('bot/utils/safeHttp');
        for (const ip of ['127.0.0.1', '10.1.2.3', '172.16.0.1', '172.31.255.1', '192.168.1.1', '169.254.169.254', '100.64.0.1', '0.0.0.0', '224.0.0.1', '::1', 'fc00::1', 'fe80::1', '::ffff:127.0.0.1']) assert.ok(isPrivateIp(ip), ip);
        for (const ip of ['93.184.216.34', '8.8.8.8', '172.15.0.1', '172.32.0.1', '2606:4700::1111']) assert.ok(!isPrivateIp(ip), ip);
        for (const host of ['localhost', 'a.local', 'db.internal', '127.0.0.1', '[::1]', '', 'nodots', 'bad_host.com']) assert.ok(!isSafeHostnameSync(host), host);
        for (const host of ['example.com', 'cdn.savetube.me', '93.184.216.34']) assert.ok(isSafeHostnameSync(host), host);
    });

    it('assertSafeUrl: بيرفض الأنواع والعناوين غير الآمنة (حتى لو الاسم بيتحل لعنوان داخلي)، وبيقبل العام', async () => {
        const { assertSafeUrl } = sb.require('bot/utils/safeHttp');
        const bad = ['file:///etc/passwd', 'ftp://example.com/a', 'http://user:pass@93.184.216.34/a', 'http://localhost/a', 'http://127.0.0.1:8080/a', 'http://[::1]/a', 'http://169.254.169.254/latest/meta-data/', 'http://10.0.0.5/a', 'http://192.168.1.1/a', 'https://printer.local/a', 'not a url'];
        for (const url of bad) await assert.rejects(() => assertSafeUrl(url), undefined, url);
        await assert.doesNotReject(() => assertSafeUrl('http://93.184.216.34/a.mp3'));
        const realLookup = dnsPromises.lookup;
        try {
            dnsPromises.lookup = async () => [{ address: '10.0.0.7', family: 4 }];
            await assert.rejects(() => assertSafeUrl('https://evil.example.com/a'), /داخلي/);
            dnsPromises.lookup = async () => [{ address: '93.184.216.34', family: 4 }, { address: '127.0.0.1', family: 4 }];
            await assert.rejects(() => assertSafeUrl('https://mixed.example.com/a'));
            dnsPromises.lookup = async () => [{ address: '93.184.216.34', family: 4 }];
            await assert.doesNotReject(() => assertSafeUrl('https://good.example.com/a'));
        } finally { dnsPromises.lookup = realLookup; }
    });

    it('downloadBuffer: بيبعت سقف الحجم والمهلة وعدد التحويلات، بيفحص إعادة التوجيه، ومبيبعتش طلب لعنوان غير آمن', async () => {
        const { downloadBuffer } = sb.require('bot/utils/safeHttp');
        let seen = null, calls = 0;
        const client = { get: async (url, opts) => { calls++; seen = { url, opts }; return { data: new Uint8Array([1, 2, 3]) }; } };
        const buffer = await downloadBuffer(client, 'http://93.184.216.34/a.mp3', { maxBytes: 1234, timeout: 777 });
        assert.equal(buffer.length, 3);
        assert.deepEqual([seen.opts.maxContentLength, seen.opts.maxBodyLength, seen.opts.maxRedirects, seen.opts.timeout, seen.opts.responseType], [1234, 1234, 3, 777, 'arraybuffer']);
        assert.throws(() => seen.opts.beforeRedirect({ hostname: '127.0.0.1' }));
        assert.throws(() => seen.opts.beforeRedirect({ hostname: 'localhost' }));
        assert.doesNotThrow(() => seen.opts.beforeRedirect({ hostname: 'cdn.example.com' }));
        calls = 0;
        await assert.rejects(() => downloadBuffer(client, 'http://169.254.169.254/x'));
        assert.equal(calls, 0);
    });

    it('ytDownloader: CDN داخلي جاي من الـ API بيتتجاهل ومفيش طلب بيتبعت ليه', async () => {
        const requested = [];
        const fake = async (cfg) => { requested.push(cfg.url); return { data: { cdn: 'localhost' } }; };
        fake.get = async (url) => { requested.push(url); return { data: Buffer.alloc(5000) }; };
        axios.create = () => fake;
        const { downloadFromYouTube } = sb.require('bot/libs/ytDownloader');
        assert.equal(await downloadFromYouTube('https://www.youtube.com/watch?v=dQw4w9WgXcQ'), null);
        assert.ok(!requested.some(u => /localhost/.test(u) && !/random-cdn/.test(u)), requested.join());
    });
});

describe('الأمان: اللوج والـ env والحظر', () => {
    let sb, h, axios, realPost;
    before(async () => {
        sb = createSandbox();
        axios = sb.requirePkg('axios'); realPost = axios.post;
        axios.post = async () => ({ data: 'رد تجريبي' });                // مفيش اتصال بالإنترنت في الاختبار
        h = await createHarness(sb);
    });
    after(() => { if (axios) axios.post = realPost; });

    it('logger: الأسرار (مفاتيح، ترويسات، Bearer، query tokens، كلمات سر) بتتعمّى في الملف', async () => {
        const Logger = sb.require('bot/utils/logger');
        const redacted = Logger.redact({ headers: { Authorization: 'Bearer abcdef123456789', 'Content-Type': 'application/json', Cookie: 'SID=xyz' }, config: { url: 'https://x.com/a?key=SECRET123&q=hi', data: { apiKey: 'gsk_aaaaaaaaaaaaaaaaaaaa' } }, note: 'عادي' });
        assert.equal(redacted.headers.Authorization, '[REDACTED]');
        assert.equal(redacted.headers.Cookie, '[REDACTED]');
        assert.equal(redacted.headers['Content-Type'], 'application/json');
        assert.ok(redacted.config.url.includes('key=[REDACTED]') && redacted.config.url.includes('q=hi'));
        assert.equal(redacted.config.data.apiKey, '[REDACTED]');
        assert.equal(redacted.note, 'عادي');
        const cyclic = { a: 1 }; cyclic.self = cyclic;
        assert.doesNotThrow(() => Logger.redact(cyclic));

        const dir = sb.resolvePath('tmp-logs');
        const logger = new Logger({ logDir: dir, enableConsole: false });
        logger.error('طلب فشل: Authorization: Bearer topsecrettoken1234 على https://api.x.com?token=ABC999', new Error('key gsk_bbbbbbbbbbbbbbbbbbbbbb rejected'));
        logger.info('ctx', { password: 'hunter2', user: 'u1' });
        await sleep(200);
        const text = fs.readdirSync(dir).map(f => fs.readFileSync(path.join(dir, f), 'utf8')).join('');
        for (const secret of ['topsecrettoken1234', 'ABC999', 'gsk_bbbb', 'hunter2']) assert.ok(!text.includes(secret), `تسرّب: ${secret}`);
        assert.ok(text.includes('u1'));
        logger.shutdown();
    });

    it('بلجن بيفشل جواه الإرسال: الخطأ مبيهربش من الـ catch والمستخدم بيستلم رسالة الخطأ', async () => {
        const plugin = sb.require('bot/plugins/ai.js');
        const sent = []; let n = 0;
        const sock = { sendMessage: async (to, m) => { n++; if (n === 2) throw new Error('فشل إرسال الرد'); sent.push(m.text); } };
        await assert.doesNotReject(() => plugin.execute(sock, {}, '', true, h.G, 'u1', {}, ['سؤال']));
        assert.ok(sent.some(t => t && t.includes('حدث خطأ')));
    });

    it('loadEnv: بيقرا KEY=VALUE والتنصيص والتعليقات، ومبيكتبش فوق متغير موجود، ومفيش ملف = مفيش مشكلة', () => {
        const { parseEnv, loadEnv } = sb.require('bot/utils/loadEnv');
        assert.deepEqual(parseEnv('# تعليق\nA=1\nexport B="two words"\nC=\'x\'\n\nBAD LINE\nD = spaced # not a comment\nE=a=b\n'), { A: '1', B: 'two words', C: 'x', D: 'spaced # not a comment', E: 'a=b' });
        const file = sb.resolvePath('tmp.env');
        fs.writeFileSync(file, 'SINS_ENV_T1=from_file\nSINS_ENV_EXISTING=should_not_override\n');
        delete process.env.SINS_ENV_T1; process.env.SINS_ENV_EXISTING = 'keep';
        assert.equal(loadEnv(file), 1);
        assert.equal(process.env.SINS_ENV_T1, 'from_file');
        assert.equal(process.env.SINS_ENV_EXISTING, 'keep');
        assert.equal(loadEnv(sb.resolvePath('no_such_env_file')), 0);
        delete process.env.SINS_ENV_T1; delete process.env.SINS_ENV_EXISTING;
    });

    it('الحظر: المالك والمطورين محميين، والمحظور بيشتري ويستخدم فك_حظر ويرجع يشتغل', async () => {
        const blockedFile = sb.resolvePath('bot', 'data', 'blockedUsers.json');
        const blocked = () => JSON.parse(fs.readFileSync(blockedFile, 'utf8'));
        fs.writeFileSync(blockedFile, '[]');
        const DEV2 = '201555555555@s.whatsapp.net';
        h.dm.set('developers', [h.DEV, DEV2]);
        assert.match(await h.run(h.DEV, '.حظر', { reply: h.OWNER }), /المالك/);
        assert.match(await h.run(h.DEV, '.حظر', { reply: DEV2 }), /مطور/);
        assert.deepEqual(blocked(), []);
        assert.match(await h.run(h.OWNER, '.حظر', { reply: DEV2 }), /تم الحظر/);
        assert.deepEqual(blocked(), [DEV2]);
        assert.match(await h.run(h.OWNER, '.حظر', { reply: DEV2 }), /إلغاء/);

        assert.match(await h.run(h.OWNER, '.حظر', { reply: h.U1 }), /تم الحظر/);
        assert.equal(await h.run(h.U1, '.رصيد'), '');
        sb.require('bot/libs/shop/inventory').addItem(h.U1, 'فك_حظر', 1);
        assert.match(await h.run(h.U1, '.استخدم فك_حظر'), /تم فك حظرك/);
        assert.deepEqual(blocked(), []);
        assert.match(await h.run(h.U1, '.رصيد'), /رصيدك/);
    });

    it('audit.log بيتحوّل لـ audit.log.1 لما يعدّي 5MB', async () => {
        const { auditLog, LOG_FILE } = sb.require('bot/utils/auditLog');
        fs.mkdirSync(path.dirname(LOG_FILE), { recursive: true });
        fs.writeFileSync(LOG_FILE, 'x'.repeat(5 * 1024 * 1024 + 10));
        auditLog({ action: 'rotation-test' });
        await sleep(150);
        assert.ok(fs.existsSync(LOG_FILE + '.1'));
        assert.ok(fs.statSync(LOG_FILE).size < 1000);
    });
});
