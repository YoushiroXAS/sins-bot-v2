'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const { spawn } = require('child_process');
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');

exitWhenDone(after);

/*
 * بيشغّل index.js الحقيقي في النسخة المؤقتة ويتأكد إن كتابة معلّقة بتتحفظ عند الإغلاق.
 * بيتخطى نفسه لو مكتبة baileys الحقيقية متثبّتة: عشان index.js هيحاول يتصل بواتساب فعلًا،
 * والاختبار ده مش المفروض يعمل كده أبدًا.
 */
describe('الإغلاق الآمن (index.js الحقيقي)', () => {
    let sb, skipReason = null;
    before(() => {
        sb = createSandbox();
        if (!sb.stubbed.has('@whiskeysockets/baileys')) skipReason = 'baileys الحقيقية متثبّتة: التشغيل الفعلي هيتصل بواتساب';
        fs.writeFileSync(sb.resolvePath('preload.js'), `
setTimeout(() => {
  const dm = require(${JSON.stringify(sb.resolvePath('bot/core/Container'))}).get('dataManager');
  const bank = dm.get('bank'); bank.__marker = 'PENDING_WRITE_MARK'; dm.set('bank', bank);
  console.log('PENDING_MARKED');
}, 1500);
if (process.env.KEEP_ALIVE) setInterval(() => {}, 1000);   // بيحاكي الـ websocket اللي بيخلّي البوت الحقيقي صاحي
`);
    });

    function startBot(env = {}) {
        const child = spawn(process.execPath, ['-r', sb.resolvePath('preload.js'), 'index.js'], { cwd: sb.root, env: { ...process.env, ...env }, stdio: ['ignore', 'pipe', 'pipe'] });
        let out = '';
        child.stdout.on('data', d => { out += d; }); child.stderr.on('data', d => { out += d; });
        return { child, output: () => out, exited: new Promise(res => child.on('exit', (code, signal) => res({ code, signal }))) };
    }
    const waitFor = async (predicate, ms = 15000) => { const t0 = Date.now(); while (!predicate()) { if (Date.now() - t0 > ms) throw new Error('timeout'); await new Promise(r => setTimeout(r, 50)); } };
    const bankHasMarker = () => fs.readFileSync(sb.resolvePath('bot', 'data', 'bank.json'), 'utf8').includes('PENDING_WRITE_MARK');

    it('SIGTERM والكتابة معلّقة في الـ debounce: بتتحفظ والـ process بيقفل بنظافة', async (t) => {
        if (skipReason) return t.skip(skipReason);
        const bot = startBot({ KEEP_ALIVE: '1' });
        await waitFor(() => bot.output().includes('PENDING_MARKED'));
        assert.equal(bankHasMarker(), false);
        bot.child.kill('SIGTERM');
        const { code } = await bot.exited;
        assert.equal(code, 0);
        assert.equal(bankHasMarker(), true);
        assert.match(bot.output(), /All services stopped cleanly/);
    });

    it('خروج طبيعي والكتابة معلّقة (من غير socket صاحي): بتتحفظ برضه', async (t) => {
        if (skipReason) return t.skip(skipReason);
        fs.writeFileSync(sb.resolvePath('bot', 'data', 'bank.json'), '{}');
        const bot = startBot();
        const result = await Promise.race([bot.exited, new Promise(res => setTimeout(() => res({ timeout: true }), 20000))]);
        if (result.timeout) bot.child.kill('SIGKILL');
        assert.ok(!result.timeout, 'البروسيس مقفلش لوحده');
        assert.equal(bankHasMarker(), true);
    });
});
