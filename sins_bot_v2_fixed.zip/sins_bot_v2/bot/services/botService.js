/**
 * BotService - WhatsApp Connection Manager (V2)
 * Replaces index.js logic with clean, service-based architecture
 * All dependencies injected via container
 */
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
const pino = require('pino');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const { cleanupExpired: cleanupExpiredShopData } = require('../libs/shop/maintenance');

class BotService {
    constructor(container) {
        this.container = container;
        this.sock = null;
        this.sessionDir = path.join(__dirname, '..', 'session');
        this.isRunning = false;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 10;
        this._stopping = false;
        this._reconnectTimer = null;
        this._dailyResetTimer = null;
        this._cleanupTimer = null;
        this._seenMessages = new Map(); // key -> وقت أول استلام (لمنع تنفيذ نفس الرسالة مرتين)
        
        // Services (lazy-loaded)
        this._logger = null;
        this._monitor = null;
        this._eventBus = null;
        this._dataManager = null;
        this._registry = null;
        this._handler = null;
    }

    // Lazy getters for services
    get logger() { 
        if (!this._logger) this._logger = this.container.get('logger');
        return this._logger;
    }
    get monitor() {
        if (!this._monitor) this._monitor = this.container.get('monitor');
        return this._monitor;
    }
    get eventBus() {
        if (!this._eventBus) this._eventBus = this.container.get('eventBus');
        return this._eventBus;
    }
    get dataManager() {
        if (!this._dataManager) this._dataManager = this.container.get('dataManager');
        return this._dataManager;
    }
    get registry() {
        if (!this._registry) this._registry = this.container.get('commandRegistry');
        return this._registry;
    }
    get handler() {
        if (!this._handler) this._handler = new (require('../handlers/handler'))(this.container);
        return this._handler;
    }

    async start() {
        if (this.isRunning) return;
        
        this.logger.info('Starting bot service...');
        
        if (!fs.existsSync(this.sessionDir)) {
            fs.mkdirSync(this.sessionDir, { recursive: true });
        }

        const { state, saveCreds } = await useMultiFileAuthState(this.sessionDir);
        const { version } = await fetchLatestBaileysVersion().catch(() => ({ 
            version: [2, 3000, 1017539702] 
        }));

        this.sock = makeWASocket({
            version,
            auth: state,
            printQRInTerminal: false,
            logger: pino({ level: 'silent' }),
            browser: ["Linux", "Chrome", "131.0.0.0"],
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: false,
            syncFullHistory: false
        });

        // Pairing code for first-time setup
        if (!this.sock.authState.creds.registered) {
            await this._requestPairingCode();
        }

        // Connection events
        this.sock.ev.on('connection.update', (update) => this._handleConnectionUpdate(update));
        this.sock.ev.on('creds.update', saveCreds);
        this.sock.ev.on('messages.upsert', (m) => this._handleMessages(m));
        
        // Scheduled tasks
        this._scheduleDailyReset();
        this._scheduleCleanup();
        
        this.isRunning = true;
        this.logger.success('Bot service initialized');
    }

    async _requestPairingCode() {
        const defaultPhone = config.defaultPhone || '201228393767';
        this.logger.info(`Requesting pairing code for: ${defaultPhone}`);
        
        setTimeout(async () => {
            try {
                const code = await this.sock.requestPairingCode(defaultPhone);
                console.log(`\n🔑 Pairing Code: ${code}\n`);
                console.log('⚠️ Open WhatsApp > Linked Devices > Link Device > Enter code');
            } catch (err) {
                this.logger.error('Failed to get pairing code', err);
            }
        }, 4000);
    }

    async _handleConnectionUpdate(update) {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'open') {
            this.reconnectAttempts = 0;
            this.logger.success('Connected to WhatsApp');
            this.monitor.trackMessage(); // Track connection as event
            
            // Emit connected event
            this.eventBus.emit('bot:connected', { 
                timestamp: Date.now(),
                jid: this.sock.user?.id 
            });

            // تشغيل init(sock) للبلجنز على الـ socket الحالي (الترحيب التلقائي مثلًا)
            try {
                this.container.get('commandRegistry').initPlugins(this.sock);
            } catch (e) {
                this.logger.error('Plugin init failed', e);
            }
        }
        
        if (connection === 'close') {
            if (this._stopping) return; // إيقاف متعمّد (shutdown): متعيدش الاتصال

            const statusCode = lastDisconnect?.error?.output?.statusCode;

            if (statusCode === DisconnectReason.loggedOut) {
                this.logger.error('Logged out. Delete session folder and restart.');
                return;
            }

            // 440: جلسة تانية (نسخة تانية من البوت) حلّت محل دي. لو أعدنا الاتصال
            // هندخل ونتطرد من بعض في حلقة مفرغة، فنقف ونكتب السبب بوضوح.
            if (statusCode === (DisconnectReason.connectionReplaced ?? 440)) {
                this.logger.error('Connection replaced by another session. Not reconnecting - make sure only one instance of the bot is running.');
                return;
            }

            if (this._reconnectTimer) return; // فيه إعادة اتصال مجدولة بالفعل (حدث close مكرر): متزوّدش العداد

            // 515: واتساب طلب إعادة تشغيل الاتصال (بيحصل بعد الربط) - مش فشل ومبيتحسبش محاولة
            const restartRequired = statusCode === (DisconnectReason.restartRequired ?? 515);
            if (!restartRequired) {
                this.reconnectAttempts++;
                if (this.reconnectAttempts > this.maxReconnectAttempts) {
                    this.logger.error('Max reconnection attempts reached');
                    // إيقاف آمن (بيحفظ البيانات) بدل process.exit المباشر
                    process.emit('app:fatal', 'max reconnection attempts reached');
                    return;
                }
            }

            const delay = restartRequired
                ? 1000
                : Math.min(5000 * this.reconnectAttempts, 30000) + Math.floor(Math.random() * 1000); // + jitter
            this.logger.warn(`Disconnected (code ${statusCode ?? 'unknown'}). Reconnecting in ${Math.round(delay / 1000)}s... (attempt ${this.reconnectAttempts})`);

            this._reconnectTimer = setTimeout(() => {
                this._reconnectTimer = null;
                if (this._stopping) return;
                this._detachSocket();
                this.isRunning = false;
                this.start().catch(err => {
                    this.logger.error('Reconnection failed', err);
                });
            }, delay);
        }
    }

    // تنضيف الـ socket القديم قبل إنشاء واحد جديد، عشان listeners القديمة
    // متفضلش شغالة وتعالج نفس الرسايل مرتين.
    _detachSocket() {
        const old = this.sock;
        if (!old) return;
        try { old.ev?.removeAllListeners?.(); } catch { /* ignore */ }
        try { old.end?.(undefined); } catch { /* ignore */ }
    }

    // رسالة اتعالجت قبل كده (واتساب بيعيد بث الرسايل أحيانًا بعد reconnect)؟
    _isDuplicateMessage(msg) {
        const id = msg?.key?.id;
        if (!id) return false;
        const k = `${msg.key.remoteJid}:${id}`;
        if (this._seenMessages.has(k)) return true;
        const now = Date.now();
        this._seenMessages.set(k, now);
        if (this._seenMessages.size > 5000) {
            for (const [key, t] of this._seenMessages) {          // الأقدم الأول
                if (now - t > 10 * 60 * 1000 || this._seenMessages.size > 4000) this._seenMessages.delete(key);
                else break;
            }
        }
        return false;
    }

    async _handleMessages(m) {
        if (!m.messages?.length) return;
        // 🔧 بنعالج الرسايل الجديدة بس (notify). 'append' هي رسايل قديمة/history
        // بتتعاد بعد الاتصال وكانت بتتنفذ كأنها أوامر جديدة.
        if (m.type && m.type !== 'notify') return;

        for (const msg of m.messages) {
            if (this._isDuplicateMessage(msg)) continue;
            try {
                await this.handler.handle(this.sock, msg);
            } catch (error) {
                this.logger.error('Message handling error', error);
                this.eventBus.emit('error:caught', { error, context: 'message_handler' });
            }
        }
    }

    _scheduleDailyReset() {
        if (this._stopping) return;
        // 🔧 كل reconnect بينادي start() اللي بينادي الدالة دي، فكانت بتتراكم سلاسل
        // جدولة (وملخص منتصف الليل يتبعت أكتر من مرة). دلوقتي دايمًا سلسلة واحدة.
        if (this._dailyResetTimer) clearTimeout(this._dailyResetTimer);
        const msUntilMidnight = this._msUntilNextCairoMidnight();
        
        this._dailyResetTimer = setTimeout(async () => {
            this.logger.info('Running daily reset...');
            try {
                await this._performDailyReset();
            } catch (e) {
                this.logger.error('Daily reset failed', e);
            }
            // Schedule next
            this._scheduleDailyReset();
        }, msUntilMidnight);
        if (this._dailyResetTimer.unref) this._dailyResetTimer.unref();
        
        this.logger.info(`Daily reset scheduled in ${Math.round(msUntilMidnight / 60000)} minutes`);
    }

    async _performDailyReset() {
        const statsData = this.dataManager.get('stats') || { groups: {} };
        const pointsData = this.dataManager.get('points') || {};
        
        const groupIds = new Set([
            ...Object.keys(statsData.groups || {}),
            ...Object.keys(pointsData)
        ]);

        for (const groupId of groupIds) {
            try {
                await this._resetGroup(groupId, statsData, pointsData);
            } catch (e) {
                this.logger.error(`Failed to reset group ${groupId}`, e);
            }
        }

        // Clear stats
        statsData.groups = {};
        statsData.totalMessages = {};
        this.dataManager.set('stats', statsData);
        
        // Clear points
        for (const key of Object.keys(pointsData)) {
            delete pointsData[key];
        }
        this.dataManager.set('points', pointsData);
        
        this.logger.success('Daily reset completed');
    }

    async _resetGroup(groupId, statsData, pointsData) {
        const titlesData = this.dataManager.get('titles') || {};
        let summary = `🌙 *『 Daily Reset 』* 🌙\n━━━━━━━━━━━━━━━━━━━━\n`;
        let hasContent = false;
        const mentions = [];

        // Top chatter
        const groupStats = statsData.groups?.[groupId];
        if (groupStats?.users && Object.keys(groupStats.users).length) {
            const sorted = Object.entries(groupStats.users)
                .sort((a, b) => (b[1].total || 0) - (a[1].total || 0));
            const [topJid, topData] = sorted[0];
            const topTitle = titlesData[groupId]?.[topJid];
            
            if (topTitle) {
                summary += `🏆 *Top Chatter:* ${topTitle} (${topData.total || 0} msgs)\n`;
            } else {
                summary += `🏆 *Top Chatter:* @${topJid.split('@')[0]} (${topData.total || 0} msgs)\n`;
                mentions.push(topJid);
            }
            hasContent = true;
        }

        // Top points
        const groupPoints = pointsData[groupId]?.users || {};
        const sortedPoints = Object.entries(groupPoints).sort((a, b) => b[1] - a[1]);
        if (sortedPoints.length) {
            const [topPJid, topPoints] = sortedPoints[0];
            const topPName = titlesData[groupId]?.[topPJid];
            if (topPName) {
                summary += `👑 *Top Presenter:* ${topPName} (${topPoints} pts)\n`;
            } else {
                summary += `👑 *Top Presenter:* @${topPJid.split('@')[0]} (${topPoints} pts)\n`;
                mentions.push(topPJid);
            }
            hasContent = true;
        }

        if (hasContent) {
            summary += `━━━━━━━━━━━━━━━━━━━━\n♻️ Stats reset for a new day.`;
            await this.sock.sendMessage(groupId, { text: summary, mentions }).catch(() => {});
        }
    }

    _scheduleCleanup() {
        // 🔧 كان بيعمل setInterval جديد مع كل reconnect (ومبيتقفلش)، فبعد كذا
        // reconnect كان بيشتغل أكتر من تنضيف كل دقيقة. دلوقتي مرة واحدة بس.
        if (this._cleanupTimer) return;
        // Cleanup expired data every minute
        this._cleanupTimer = setInterval(() => {
            try {
                this._cleanupExpired();
            } catch (e) {
                this.logger.error('Cleanup error', e);
            }
        }, 60000);
        if (this._cleanupTimer.unref) this._cleanupTimer.unref();
    }

    _cleanupExpired() {
        // الحجوزات والحماية بيمتلكها المتجر (libs/shop/storage.js) فالتنضيف بيتم هناك
        cleanupExpiredShopData();
    }

    _msUntilNextCairoMidnight() {
        const parts = new Intl.DateTimeFormat('en-GB', {
            timeZone: 'Africa/Cairo',
            hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
        }).formatToParts(new Date());
        
        const obj = {};
        parts.forEach(p => { obj[p.type] = p.value; });
        
        const hour = parseInt(obj.hour, 10) || 0;
        const minute = parseInt(obj.minute, 10) || 0;
        const second = parseInt(obj.second, 10) || 0;
        
        const secondsSinceMidnight = hour * 3600 + minute * 60 + second;
        let secondsRemaining = (24 * 3600) - secondsSinceMidnight;
        if (secondsRemaining <= 0) secondsRemaining += 24 * 3600;
        
        return secondsRemaining * 1000;
    }

    // إيقاف الخدمة (بيتنادى من gracefulShutdown في index.js): بيوقف كل الـ timers
    // ومبيسمحش بإعادة اتصال أثناء الإغلاق. حفظ البيانات بيعمله dataManager.shutdown().
    // 🔧 كل الألعاب بتخزّن حالتها في الذاكرة بس، فأي إيقاف للبوت بيلغيها من غير ما اللاعبين
    // يعرفوا. قبل ما نقفل بنبلّغ الجروبات اللي فيها لعبة أو تسجيل مفتوح (بحد أقصى 3 ثواني،
    // وفشل جروب واحد مبيعطّلش الباقي).
    async _announceInterruptedGames() {
        if (!this.sock) return 0;
        let chats = [];
        try { chats = this._handler?._gameRouter?.getActiveGameChats?.() || []; } catch { return 0; }
        if (!chats.length) return 0;
        const text = '⚠️ *تنبيه:* البوت بيتعمله إعادة تشغيل دلوقتي، فالفعالية الجارية في الجروب ده اتلغت. ابدأوها من جديد بعد دقايق.';
        let timer;
        await Promise.race([
            Promise.allSettled(chats.map(chat => Promise.resolve().then(() => this.sock.sendMessage(chat, { text })))),
            new Promise(resolve => { timer = setTimeout(resolve, 3000); }),
        ]);
        clearTimeout(timer);
        return chats.length;
    }

    async shutdown() {
        if (!this._stopping) {
            try { await this._announceInterruptedGames(); } catch { /* الإعلان محاولة، مبتعطّلش الإغلاق */ }
        }
        this._stopping = true;
        this.isRunning = false;
        if (this._reconnectTimer) clearTimeout(this._reconnectTimer);
        if (this._dailyResetTimer) clearTimeout(this._dailyResetTimer);
        if (this._cleanupTimer) clearInterval(this._cleanupTimer);
        this._reconnectTimer = this._dailyResetTimer = this._cleanupTimer = null;
        this._detachSocket();
    }

    async stop() {
        await this.shutdown();
        this.isRunning = false;
        this.logger.info('Stopping bot service...');
        
        if (this.sock) {
            await this.sock.ws.close();
        }
        
        await this.dataManager.shutdown();
        this.logger.success('Bot service stopped');
    }
}

module.exports = BotService;
