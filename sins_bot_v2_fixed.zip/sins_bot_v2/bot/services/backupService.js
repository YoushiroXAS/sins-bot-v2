/**
 * BackupService - نسخ احتياطي دوري لكل ملفات bot/data/*.json
 *
 * - كل 6 ساعات (ومرة عند التشغيل لو آخر نسخة أقدم من ساعة).
 * - بيحتفظ بآخر 10 نسخ في bot/backups/<التاريخ_الوقت>/.
 * - مبينسخش ملف JSON تالف (عشان النسخ الاحتياطية تفضل سليمة).
 * - dataManager بيستخدم آخر نسخة سليمة تلقائيًا لو ملف اتلف وقت التشغيل.
 */
const fs = require('fs').promises;
const path = require('path');

const BACKUP_NAME = /^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$/;
const SIX_HOURS = 6 * 60 * 60 * 1000;
const ONE_HOUR = 60 * 60 * 1000;

class BackupService {
    constructor(options = {}) {
        this.dataDir = options.dataDir || path.join(__dirname, '..', 'data');
        this.backupDir = options.backupDir || path.join(__dirname, '..', 'backups');
        this.intervalMs = options.intervalMs || SIX_HOURS;
        this.keep = options.keep || 10;
        this.logger = options.logger || null;
        this._timer = null;
        this._running = null;
    }

    _log(level, msg) {
        const fn = this.logger?.[level];
        if (typeof fn === 'function') fn.call(this.logger, `[Backup] ${msg}`);
        else console[level === 'error' ? 'error' : 'log'](`[Backup] ${msg}`);
    }

    start() {
        if (this._timer) return;
        this._latestAgeMs().then(age => {
            if (age === null || age > ONE_HOUR) return this.backupNow();
        }).catch(e => this._log('error', `فشل النسخ عند التشغيل: ${e.message}`));
        this._timer = setInterval(() => {
            this.backupNow().catch(e => this._log('error', `فشل النسخ الدوري: ${e.message}`));
        }, this.intervalMs);
        if (this._timer.unref) this._timer.unref();
    }

    backupNow() {
        if (!this._running) {
            this._running = this._doBackup().finally(() => { this._running = null; });
        }
        return this._running;
    }

    async _listBackups() {
        try {
            const entries = await fs.readdir(this.backupDir, { withFileTypes: true });
            // مجلدات النسخ بس (التاريخ_الوقت)؛ مجلدات تانية زي bank-resets متتحسبش ولا تتمسح
            return entries.filter(e => e.isDirectory() && BACKUP_NAME.test(e.name)).map(e => e.name).sort(); // الأقدم الأول
        } catch { return []; }
    }

    async _latestAgeMs() {
        const dirs = await this._listBackups();
        if (!dirs.length) return null;
        const st = await fs.stat(path.join(this.backupDir, dirs[dirs.length - 1]));
        return Date.now() - st.mtimeMs;
    }

    async _doBackup() {
        const entries = await fs.readdir(this.dataDir, { withFileTypes: true });
        const files = entries.filter(e => e.isFile() && e.name.endsWith('.json')).map(e => e.name);
        const stamp = new Date().toISOString().replace('T', '_').replace(/[:.]/g, '-').slice(0, 19);
        const target = path.join(this.backupDir, stamp);
        await fs.mkdir(target, { recursive: true });

        let copied = 0, skipped = 0;
        for (const name of files) {
            try {
                const raw = await fs.readFile(path.join(this.dataDir, name), 'utf8');
                JSON.parse(raw); // ملف تالف = مبنسخهوش
                await fs.writeFile(path.join(target, name), raw);
                copied++;
            } catch (e) {
                skipped++;
                this._log('warn', `اتخطّى ${name}: ${e.message}`);
            }
        }
        await this._prune();
        this._log('info', `نسخة جديدة ${stamp} (${copied} ملف${skipped ? `، ${skipped} اتخطّى` : ''})`);
        return { target, copied, skipped };
    }

    async _prune() {
        const dirs = await this._listBackups();
        const extra = dirs.slice(0, Math.max(0, dirs.length - this.keep));
        for (const d of extra) {
            await fs.rm(path.join(this.backupDir, d), { recursive: true, force: true }).catch(() => {});
        }
    }

    async shutdown() {
        if (this._timer) clearInterval(this._timer);
        this._timer = null;
        if (this._running) await this._running.catch(() => {});
    }
}

module.exports = BackupService;
