/**
 * MoneyMachineScheduler - بينادي processMoneyMachines كل ساعة.
 * بيشتغل مرة أول ما البوت يفتح كمان، عشان يعوّض أي ساعات عدّت والبوت مقفول.
 * الـ timer مع .unref() وفيه shutdown() (بيتنادى من index.js).
 */
const { processMoneyMachines } = require('../libs/shop/moneyMachine');

const ONE_HOUR = 60 * 60 * 1000;

class MoneyMachineScheduler {
    constructor(dataManager, logger = null, intervalMs = ONE_HOUR) {
        this.dataManager = dataManager;
        this.logger = logger;
        this.intervalMs = intervalMs;
        this._timer = null;
    }

    start() {
        if (this._timer) return;
        this.tick();
        this._timer = setInterval(() => this.tick(), this.intervalMs);
        if (this._timer.unref) this._timer.unref();
    }

    tick() {
        try {
            const bank = this.dataManager.get('bank');
            if (!bank) return false;
            return processMoneyMachines(bank, () => this.dataManager.set('bank', bank));
        } catch (e) {
            (this.logger?.error || console.error).call(this.logger || console, `[MoneyMachine] فشل: ${e.message}`);
            return false;
        }
    }

    shutdown() {
        if (this._timer) clearInterval(this._timer);
        this._timer = null;
    }
}

module.exports = MoneyMachineScheduler;
