/**
 * Rate Limit Middleware - Global spam prevention
 * Uses the shared rate limiter from container
 */
function createRateLimitMiddleware(rateLimiter) {
    return function rateLimitMiddleware(context, command) {
        // Skip rate limit for owner
        if (context.isOwner) return true;
        
        if (!rateLimiter.isAllowed(context.sender)) {
            // رسالة واحدة بس لكل فترة حظر (الباقي بيتجاهل بصمت)
            if (rateLimiter.shouldNotify(context.sender)) {
                context.sock.sendMessage(context.from, {
                    text: '⏳ تم حظرك مؤقتاً بسبب الإرسال السريع. انتظر دقيقة.'
                }).catch(() => {});
            }
            return false;
        }
        return true;
    };
}

module.exports = createRateLimitMiddleware;
