/**
 * Cooldown Middleware - Per-command rate limiting
 * Tracks cooldown per user per command
 *
 * 🔧 قبل كده الـ Map كانت بتخزّن آخر وقت استخدام لكل (مستخدم + أمر)
 * ومبتمسحش أي مدخل أبدًا، فكانت بتكبر طول عمر البوت. دلوقتي بنخزّن
 * وقت انتهاء الـ cooldown، وبنمسح المنتهي كل دقيقة تقريبًا - من جوه
 * نفس الـ middleware عند أول أمر بعد الدقيقة. مفيش timer منفصل، فمفيش
 * حاجة إضافية تتوقف في shutdown ولا بتمنع إغلاق الـ process.
 */
const SWEEP_INTERVAL_MS = 60 * 1000;

function createCooldownMiddleware() {
    const cooldowns = new Map(); // key -> وقت انتهاء الـ cooldown (ms)
    let lastSweep = Date.now();

    function sweepExpired(now) {
        lastSweep = now;
        for (const [key, expiresAt] of cooldowns) {
            if (expiresAt <= now) cooldowns.delete(key);
        }
    }

    function cooldownMiddleware(context, command) {
        if (!command.cooldown) return true;

        const now = Date.now();
        if (now - lastSweep >= SWEEP_INTERVAL_MS) sweepExpired(now);

        // الاسم الأساسي للأمر: لو استخدمت alias تاني للأمر نفسه، الـ cooldown لسه سارية
        const key = `${context.sender}:${command.canonical || command.name}`;
        const expiresAt = cooldowns.get(key);

        if (expiresAt && now < expiresAt) {
            const remaining = Math.ceil((expiresAt - now) / 1000);
            context.sock.sendMessage(context.from, {
                text: `⏳ انتظر ${remaining} ثانية.`
            }).catch(() => {});
            return false;
        }

        cooldowns.set(key, now + command.cooldown * 1000);
        return true;
    }

    // للاختبار والمراقبة فقط (monitor/status ممكن يستخدمها لاحقًا)
    cooldownMiddleware.size = () => cooldowns.size;

    return cooldownMiddleware;
}

module.exports = createCooldownMiddleware;
