/**
 * Permission Middleware - Role-based access control
 * 
 * Permission levels (from most to least restrictive):
 *   'owner'      - Bot owner only
 *   'developer'  - Owner + Developers
 *   'elite'      - Owner + Developers + Elites
 *   'admin'      - Group admins (future)
 *   'group'      - Group chats only
 *   'everyone'   - No restrictions (default)
 */
function createPermissionMiddleware() {
    return function permissionMiddleware(context, command) {
        const { isOwner, isDeveloper, isElite, isGroup, from, sock } = context;
        const required = command.permission || 'everyone';

        const reply = (text) => sock.sendMessage(from, { text }).catch(() => {});

        switch (required) {
            case 'owner':
                if (!isOwner) {
                    reply('❌ هذا الأمر للمالك فقط.');
                    return false;
                }
                break;

            case 'developer':
                if (!isOwner && !isDeveloper) {
                    reply('❌ هذا الأمر للمالك والمطورين فقط.');
                    return false;
                }
                break;

            case 'elite':
                if (!isOwner && !isDeveloper && !isElite) {
                    reply('❌ هذا الأمر للنخبة فقط.');
                    return false;
                }
                break;

            case 'group':
                if (!isGroup) {
                    reply('❌ هذا الأمر يعمل في المجموعات فقط.');
                    return false;
                }
                break;
        }

        return true;
    };
}

module.exports = createPermissionMiddleware;
