module.exports = {
    command: 'تست',
    async execute(sock, msg, body, isGroup, from) {
        await sock.sendMessage(from, { text: '𝑺𝑰𝑵𝑺_𝑩𝑶𝑻 𝑰𝑺 𝑾𝑶𝑹𝑲𝑰𝑵𝑮 🍂' });
    }
};