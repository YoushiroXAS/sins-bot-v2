const { handleMove, activeGames } = require('../libs/sudoku');

module.exports = {
    command: 'خ',
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل في المجموعات فقط.' });
        const game = activeGames.get(from);
        if (!game || game.type !== 'sudoku') return sock.sendMessage(from, { text: '❌ لا توجد لعبة سودوكو نشطة.' });
        if (args.length < 2) return sock.sendMessage(from, { text: '❌ استخدم: .خ <خلية> <رقم>\nمثال: .خ A1 5' });
        await handleMove(sock, from, sender, args[0], parseInt(args[1]), context);
    }
};