const fs = require('fs');
const path = require('path');
const nicknameFile = path.join(__dirname, '..', 'data', 'nickname.json');

function saveTitles(data) {
    fs.writeFileSync(nicknameFile, JSON.stringify(data, null, 2));
}

module.exports = {
    command: ['لقبي', 'قائمة', 'تسجيل', 'حذف'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!isGroup) return;
        const titles = context.titlesData;
        const command = body.slice(1).trim().split(/\s+/)[0]?.toLowerCase();

        if (command === 'لقبي') {
            const myTitle = context.getDisplayTitle(sender);
            if (!myTitle) { await sock.sendMessage(from, { text: '⚠️ ليس لديك لقب مسجل.' }); return; }
            await sock.sendMessage(from, { text: `👑 لقبك الحالي: *${myTitle}*` });
        }
        else if (command === 'قائمة' && args[0] === 'القاب') {
            const groupTitles = titles[from] || {};
            const entries = Object.entries(groupTitles);
            if (!entries.length) { await sock.sendMessage(from, { text: '🍂 لا توجد ألقاب.' }); return; }
            let listMsg = `🍂 *ألقاب هذا الجروب*\n\n`;
            const mentions = [];
            entries.forEach(([jid, title], index) => {
                const displayTitle = context.getDisplayTitle(jid) || title;
                listMsg += `${index+1}. @${jid.split('@')[0]} ➔ *${displayTitle}*\n`;
                mentions.push(jid);
            });
            await sock.sendMessage(from, { text: listMsg, mentions });
        }
        else if (command === 'تسجيل') {
            if (!context.isOwner && !context.isDeveloper && !context.isElite) {
                await sock.sendMessage(from, { text: '❌ للنخبة والمالك والمطورين فقط.' }); return;
            }
            let target = msg.message.extendedTextMessage?.contextInfo?.participant ||
                         msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || sender;
            let titleArgs = args;
            if (msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                titleArgs = args.filter(a => !a.includes(target.split('@')[0]));
            }
            const targetTitle = titleArgs.join(' ').trim();
            if (!targetTitle) { await sock.sendMessage(from, { text: '⚠️ اكتب اللقب.' }); return; }

            if (!titles[from]) titles[from] = {};
            const isTaken = Object.entries(titles[from]).some(
                ([jid, t]) => jid !== target && t.toLowerCase() === targetTitle.toLowerCase()
            );
            if (isTaken) { await sock.sendMessage(from, { text: '⚠️ اللقب محجوز.' }); return; }

            titles[from][target] = targetTitle;
            saveTitles(titles);
            await sock.sendMessage(from, { text: `✅ تم تسجيل اللقب: *${targetTitle}*` });
        }
        else if (command === 'حذف' && args[0] === 'تسجيل') {
            if (!context.isOwner && !context.isDeveloper && !context.isElite) {
                await sock.sendMessage(from, { text: '❌ للنخبة والمالك والمطورين فقط.' }); return;
            }
            let target = msg.message.extendedTextMessage?.contextInfo?.participant ||
                         msg.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || sender;

            if (!titles[from]) titles[from] = {};
            if (titles[from][target]) {
                delete titles[from][target];
                if (Object.keys(titles[from]).length === 0) delete titles[from];
                saveTitles(titles);
                await sock.sendMessage(from, { text: '🗑️ تم إزالة اللقب.' });
            } else { await sock.sendMessage(from, { text: '⚠️ لا يوجد لقب.' }); }
        }
    }
};