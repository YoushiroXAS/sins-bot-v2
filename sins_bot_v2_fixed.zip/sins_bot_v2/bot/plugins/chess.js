const { makeMove } = require('../libs/chess');

module.exports = {
    command: 'شطرنج',
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!isGroup) return sock.sendMessage(from, { text: '❌ الشطرنج يعمل في المجموعات فقط.' });
        const moveText = args.join(' ').trim();
        if (!moveText) return sock.sendMessage(from, { text: '♟️ استخدم: .شطرنج <الحركة>' });
        await makeMove(sock, from, sender, moveText, msg);
    }
};