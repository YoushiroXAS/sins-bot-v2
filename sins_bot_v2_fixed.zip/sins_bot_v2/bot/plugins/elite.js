// 🔧 نفس إصلاح developer.js بالظبط: موديول غير موجود + توقيع دالة قديم.
// استخدام context.dataManager على مخزن 'elites' الجاهز في bootstrap.js.
const { auditLog } = require('../utils/auditLog');

module.exports = {
    command: 'مشرف',
    async execute(context) {
        const { sock, from, isOwner, isDeveloper, msg, args, dataManager, elitesData } = context;

        if (!isOwner && !isDeveloper) {
            await sock.sendMessage(from, { text: '❌ هذا الأمر مخصص للمالك والمطورين فقط.' });
            return;
        }

        const sub = args[0]?.toLowerCase();
        if (!['اضف', 'ازل'].includes(sub)) {
            await sock.sendMessage(from, { text: '⚠️ استخدم `.مشرف اضف` أو `.مشرف ازل`.' });
            return;
        }

        let targetJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
                     || msg.message?.extendedTextMessage?.contextInfo?.participant;

        if (!targetJid && args[1]) {
            const num = args[1].replace(/\D/g, '');
            if (num) targetJid = num + '@s.whatsapp.net';
        }

        if (!targetJid) {
            await sock.sendMessage(from, { text: '⚠️ منشن أو رد على الشخص، أو اكتب رقمه مباشرة.' });
            return;
        }

        const clean = (jid) => (jid || '').replace(/\D/g, '');
        const list = [...elitesData]; // نسخة، مش تعديل مصدر الـ context مباشرة
        const isMatch = (j) => j === targetJid || clean(j) === clean(targetJid);

        if (sub === 'اضف') {
            if (list.some(isMatch)) {
                await sock.sendMessage(from, { text: '⚠️ موجود بالفعل.' });
                return;
            }
            list.push(targetJid);
            dataManager.set('elites', list);
            auditLog({ action: 'elite-add', group: from, actor: context.sender, target: targetJid });
            await sock.sendMessage(from, { text: '✅ تمت الإضافة للنخبة.' });
        } else {
            if (!list.some(isMatch)) {
                await sock.sendMessage(from, { text: '⚠️ ليس من النخبة.' });
                return;
            }
            dataManager.set('elites', list.filter(j => !isMatch(j)));
            auditLog({ action: 'elite-remove', group: from, actor: context.sender, target: targetJid });
            await sock.sendMessage(from, { text: '✅ تمت الإزالة من النخبة.' });
        }
    }
};
