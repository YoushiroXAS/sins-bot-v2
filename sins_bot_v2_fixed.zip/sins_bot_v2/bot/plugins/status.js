/**
 * Status Plugin - Shows bot system status
 * V2 Feature: Uses monitor from container
 */
module.exports = {
    command: ['حالة', 'status', 'ستاتس'],
    description: 'عرض حالة البوت والنظام',
    cooldown: 10,
    
    async execute(context) {
        const { sock, from, isOwner } = context;
        
        if (!isOwner) {
            await sock.sendMessage(from, { text: '❌ هذا الأمر للمالك فقط.' });
            return;
        }

        const monitor = context.dataManager ? null : null;
        // Get monitor via global container (injected via context in real usage)
        const container = require('../core/Container');
        const mon = container.get('monitor');
        const cache = container.get('cache');
        const registry = container.get('commandRegistry');
        const dataManager = container.get('dataManager');
        const rateLimiter = container.get('rateLimiter');
        
        const stats = mon.getStats();
        const cacheStats = cache.getStats();
        const cmdStats = registry.getStats();
        const dataStats = dataManager.getStats();
        const rateStats = rateLimiter.getStats();
        
        const text = `📊 *SINS_BOT V2 System Status*

⏱️ *Uptime:* ${stats.uptimeFormatted}
📨 *Messages:* ${stats.messagesProcessed}
⚡ *Commands:* ${stats.commandsExecuted}
❌ *Errors:* ${stats.errors}
🧠 *Memory:* ${stats.memoryUsage}

🎮 *Active Games:* ${stats.activeGames}
📦 *Data Stores:* ${dataStats.stores}
💾 *Cache Hit Rate:* ${cacheStats.hitRate}

⚡ *Commands:* ${cmdStats.totalCommands} total
📂 *Categories:* ${cmdStats.categories}

🚫 *Rate Limited:* ${rateStats.blockedUsers} users
👥 *Active Users:* ${rateStats.activeUsers}

*Top Commands:*
${stats.topCommands.map((c, i) => `${i + 1}. ${c.name}: ${c.count}`).join('\n')}`;

        await sock.sendMessage(from, { text });
    }
};
