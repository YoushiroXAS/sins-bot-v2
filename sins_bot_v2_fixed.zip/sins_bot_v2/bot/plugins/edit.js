const { handleEdit } = require('../libs/edit');

module.exports = {
    command: 'ايديت',
    async execute(sock, msg, body, isGroup, from, sender, context) {
        await handleEdit(sock, msg, body, isGroup, from, sender, context);
    }
};