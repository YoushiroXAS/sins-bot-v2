const fs = require('fs');
const path = require('path');
const axios = require('axios');
const logger = require('../utils/logger');

let sharp;
try { sharp = require('sharp'); } catch (e) {}

const activePath = path.join(__dirname, '..', 'data', 'activeWelcome.json');
const dataDir = path.dirname(activePath);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(activePath)) fs.writeFileSync(activePath, JSON.stringify([]));

const welcomed = new Set();
// 🔧 كان boolean (welcomeListenerAdded) بيفضل true للأبد، فبعد أول reconnect الـ socket الجديد
// مكانش بياخد listener. دلوقتي بنفتكر الـ socket نفسه، فكل socket جديد بياخد listener مرة واحدة.
let listeningSock = null;

async function fetchAnimePFP(query) {
    if (!query) return null;
    try {
        const res = await axios.get('https://api.jikan.moe/v4/characters', {
            params: { q: query, limit: 5, order_by: 'favorites', sort: 'desc' },
            timeout: 10000
        });
        const results = res.data?.data || [];
        if (results.length) return results[0].images?.jpg?.image_url;
    } catch (e) {}
    return null;
}

function registerWelcomeListener(sock) {
    if (!sock || listeningSock === sock) return;
    listeningSock = sock;
    sock.ev.on('group-participants.update', async (update) => {
        try {
            if (update.action !== 'add') return;
            const groupId = update.id;
            const activeGrps = JSON.parse(fs.readFileSync(activePath, 'utf8'));
            if (!activeGrps.includes(groupId)) return;
            for (const participant of update.participants) {
                const jid = typeof participant === 'string' ? participant : participant.jid;
                if (!jid) continue;
                const key = `${groupId}:${jid}`;
                if (welcomed.has(key)) continue;
                welcomed.add(key);
                setTimeout(() => welcomed.delete(key), 5 * 60 * 1000);
                const img = await fetchAnimePFP('anime welcome');
                const caption = `🌸 أهلاً وسهلاً بك في المجموعة!\n👤 @${jid.split('@')[0]}`;
                if (img) {
                    await sock.sendMessage(groupId, { image: { url: img }, caption, mentions: [jid] });
                } else {
                    await sock.sendMessage(groupId, { text: caption, mentions: [jid] });
                }
            }
        } catch (err) { logger.error('خطأ في الترحيب التلقائي:', err); }
    });
}

module.exports = {
    command: 'ترحيب',
    init(sock) {
        registerWelcomeListener(sock);
        welcomed.clear();
    },
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل داخل المجموعات فقط.' });
        const sub = args[0] || '';
        if (sub === 'تشغيل') {
            let act = JSON.parse(fs.readFileSync(activePath, 'utf8'));
            if (act.includes(from)) return sock.sendMessage(from, { text: '✅ الترحيب التلقائي مفعل مسبقاً.' });
            act.push(from);
            fs.writeFileSync(activePath, JSON.stringify(act, null, 2));
            registerWelcomeListener(sock);
            return sock.sendMessage(from, { text: '✅ تم تفعيل الترحيب التلقائي.' });
        }
        if (sub === 'وقف' || sub === 'إيقاف') {
            let act = JSON.parse(fs.readFileSync(activePath, 'utf8'));
            act = act.filter(j => j !== from);
            fs.writeFileSync(activePath, JSON.stringify(act, null, 2));
            return sock.sendMessage(from, { text: '⛔ تم إيقاف الترحيب التلقائي.' });
        }
        let targetJid = msg.message?.extendedTextMessage?.contextInfo?.participant ||
                        msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!targetJid) return sock.sendMessage(from, { text: '⚠️ استخدم المنشن أو الرد!' });
        const welcomeTitle = args.slice(1).join(' ').trim() || context.getGroupTitle?.(targetJid) || targetJid.split('@')[0];
        const imgUrl = await fetchAnimePFP(welcomeTitle);
        const caption = `🌟 مرحباً ${welcomeTitle}!\n👤 @${targetJid.split('@')[0]}`;
        if (imgUrl) {
            await sock.sendMessage(from, { image: { url: imgUrl }, caption, mentions: [targetJid] });
        } else {
            await sock.sendMessage(from, { text: `⚠️ لا صورة.\n\n${caption}`, mentions: [targetJid] });
        }
    }
};