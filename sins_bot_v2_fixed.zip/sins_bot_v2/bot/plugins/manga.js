const { handleManga } = require('../libs/manga');

module.exports = {
    command: ['مانجا', 'manga'],
    async execute(sock, msg, body, isGroup, from, sender, context) {
        await handleManga(sock, msg, body, isGroup, from, sender, context);
    }
};