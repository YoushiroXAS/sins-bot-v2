const { handleManhwa } = require('../libs/manhwa');

module.exports = {
    command: ['مانهوا', 'manhwa'],
    async execute(sock, msg, body, isGroup, from, sender, context) {
        await handleManhwa(sock, msg, body, isGroup, from, sender, context);
    }
};