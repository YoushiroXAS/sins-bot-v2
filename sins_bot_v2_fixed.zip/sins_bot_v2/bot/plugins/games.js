const gameHandler = require('../libs/games');

module.exports = {
    command: ['فعالية', 'تلميح', 'hint', 'الفعاليات'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        const command = body.slice(1).trim().split(/\s+/)[0]?.toLowerCase();
        if (command === 'فعالية') {
            if (!isGroup) return;
            const type = args[0];
            const eventArgs = args.slice(1);
            await gameHandler.startEvent(sock, from, sender, type, eventArgs, context, msg);
        } else if (command === 'تلميح' || command === 'hint') {
            if (!isGroup) return;
            // 🔧 'تلميح' كان معرّف في deathnote_commands.js كمان، وبيكسب الأخير تحميلًا (هنا)،
            // وuseHint بتاعت الألعاب العامة بترجع من غير حاجة لو اللعبة الشغالة مذكرة الموت.
            // دلوقتي: لعبة عامة شغالة؟ ليها. غير كده ومذكرة الموت شغالة؟ ليها.
            const deathnote = require('../libs/deathnote');
            if (!gameHandler.hasActiveGame(from) && deathnote.activeGames.has(from)) {
                await deathnote.useHint(sock, from);
            } else {
                await gameHandler.useHint(sock, from);
            }
        } else if (command === 'الفعاليات') {
            await gameHandler.sendEventsMenu(sock, from);
        }
    }
};