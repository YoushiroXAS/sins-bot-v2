const { handleShop } = require('../libs/shop');

module.exports = {
    command: [
        'متجر', 'رصيد', 'تحويل', 'ايداع', 'إيداع', 'خصم',
        'سوق', 'تاجر', 'شراء', 'استخدم', 'هيبة', 'مخزون',
        'صناديق', 'صندوق', 'عجلة', 'عجلة_حظ', 'روليت',
        'سحب_الظلال',
        'جاكبوت', 'تطوير',
    ],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        return await handleShop(sock, msg, body, isGroup, from, sender, context);
    }
};
