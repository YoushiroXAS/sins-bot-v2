const { downloadBestMatchFromSoundCloud } = require('../libs/audioDownload');
const logger = require('../utils/logger');

module.exports = {
    command: ['قرآن', 'قران', 'سورة', 'سوره'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        const rawBody = body.startsWith('.') ? body.slice(1).trim() : body.trim();
        const parts = rawBody.split(/\s+/);
        const cmd = parts.shift()?.toLowerCase();
        const surahName = parts.join(' ').trim();

        if (!surahName) {
            await sock.sendMessage(from, { text: `🕋 *يرجى كتابة اسم السورة!*\n\n📌 مثال:\n*.قرآن الكهف*` }, { quoted: msg });
            return;
        }

        try {
            await sock.sendMessage(from, { text: `🔎 *جاري البحث عن تلاوة "${surahName}"...*` });
            const match = await downloadBestMatchFromSoundCloud(`سورة ${surahName} تلاوة`);
            if (!match) {
                await sock.sendMessage(from, { text: `❌ تعذر العثور على التلاوة أو تحميلها.` }, { quoted: msg });
                return;
            }
            await sock.sendMessage(from, {
                audio: match.buffer, mimetype: 'audio/mpeg', ptt: false,
                contextInfo: {
                    externalAdReply: {
                        title: match.info.title,
                        body: 'تلاوة مباركة من القرآن الكريم',
                        mediaType: 2, mediaUrl: match.info.url, sourceUrl: match.info.url,
                        containsAutoReply: true, renderLargerThumbnail: true, showAdAttribution: false,
                    }
                }
            }, { quoted: msg });
        } catch (err) {
            logger.error('Quran error:', err);
            await sock.sendMessage(from, { text: `❌ فشل التحميل: ${err.message}` }, { quoted: msg });
        }
    }
};