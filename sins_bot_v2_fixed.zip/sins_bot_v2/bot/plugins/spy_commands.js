const { registerPlayer, startGameFromRegistration, handleSpyGuess, handleVote, handleFinalGuess, chooseCategory, activeGames, registrationSessions } = require('../libs/spygame');
const logger = require('../utils/logger');

module.exports = {
    // 'شارك' و'ابدأ' بيتوجّهوا من global_commands.js (شوف التعليق في deathnote_commands.js)
    command: ['تخمين', 'صوت', 'تصنيف', 'تخمين_نهائي'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        const command = body.slice(1).trim().split(/\s+/)[0]?.toLowerCase();
        try {
            if (command === 'تصنيف') {
                if (!isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل في المجموعات فقط.' });
                const index = args[0];
                if (!index) return sock.sendMessage(from, { text: '❌ استخدم: .تصنيف <الرقم>' });
                await chooseCategory(sock, from, sender, index, context);
            }
            else if (command === 'تخمين') {
                if (isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل في الخاص فقط.' });
                const word = args.join(' ');
                if (!word) return sock.sendMessage(from, { text: '⚠️ اكتب الكلمة.' });
                let tg = null;
                for (const [gid, game] of activeGames) { if (game.participants?.includes(sender)) { tg = gid; break; } }
                if (!tg) return sock.sendMessage(from, { text: '❌ لست مشاركاً.' });
                await handleSpyGuess(sock, sender, word, tg);
            }
            else if (command === 'تخمين_نهائي') {
                if (isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل في الخاص فقط.' });
                const opt = args[0];
                if (!opt) return sock.sendMessage(from, { text: '⚠️ استخدم: .تخمين_نهائي <الرقم>' });
                let tg = null;
                for (const [gid, game] of activeGames) { if (game.participants?.includes(sender)) { tg = gid; break; } }
                if (!tg) return sock.sendMessage(from, { text: '❌ لست مشاركاً.' });
                await handleFinalGuess(sock, sender, opt, tg);
            }
            else if (command === 'صوت') {
                if (!isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل في المجموعة فقط.' });
                const game = activeGames.get(from);
                if (!game || (game.phase !== 'voting' && game.phase !== 'final_guess'))
                    return sock.sendMessage(from, { text: '❌ التصويت غير متاح.' });
                const suspect = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
                if (!suspect) return sock.sendMessage(from, { text: '⚠️ منشن المشتبه به.' });
                await handleVote(sock, from, sender, suspect);
            }
        } catch (e) {
            logger.error('Spy command error:', e);
        }
    }
};