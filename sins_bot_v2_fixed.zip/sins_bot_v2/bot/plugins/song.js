const { handleSong } = require('../libs/song');

module.exports = {
    command: 'اغنية',
    async execute(sock, msg, body, isGroup, from, sender, context) {
        await handleSong(sock, msg, body, isGroup, from, sender, context);
    }
};