const { registerPlayer: dnRegister, startGame: dnStart, registrationSessions: dnRegSessions } = require('../libs/deathnote');
const { registerPlayer: spyRegister, startGameFromRegistration: spyStart, registrationSessions: spyRegSessions } = require('../libs/spygame');

module.exports = {
    command: ['شارك', 'ابدأ'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!isGroup) {
            await sock.sendMessage(from, { text: '❌ هذا الأمر يعمل في المجموعات فقط.' });
            return;
        }
        const command = body.slice(1).trim().split(/\s+/)[0]?.toLowerCase();

        if (command === 'شارك') {
            if (dnRegSessions.has(from)) {
                await dnRegister(sock, from, sender, context);
            } else if (spyRegSessions.has(from)) {
                await spyRegister(sock, from, sender, context);
            } else {
                await sock.sendMessage(from, { text: '❌ لا يوجد باب تسجيل مفتوح حالياً (مذكرة الموت أو الجاسوس).' });
            }
        }
        else if (command === 'ابدأ') {
            if (dnRegSessions.has(from)) {
                await dnStart(sock, from, sender, context);
            } else if (spyRegSessions.has(from)) {
                await spyStart(sock, from, sender, context);
            } else {
                await sock.sendMessage(from, { text: '❌ لا يوجد باب تسجيل مفتوح.' });
            }
        }
    }
}