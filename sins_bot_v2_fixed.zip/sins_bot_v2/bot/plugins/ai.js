const { askAI } = require('../libs/ai');
const logger = require('../utils/logger');

module.exports = {
    command: ['ai', 'ايانو'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        const question = args.join(' ').trim();
        if (!question) {
            return sock.sendMessage(from, { text: '♟️ *𝑨𝒚𝒂𝒏𝒐𝒌𝒐𝒖𝒋𝒊:* أهلاً! اكتب سؤالك بعد .ai أو .ايانو' });
        }
        await sock.sendMessage(from, { text: '⏳ *𝑨𝒚𝒂𝒏𝒐𝒌𝒐𝒖𝒋𝒊 ♟️ بيفكر...*' });
        try {
            const reply = await askAI(question, sender, msg);
            if (reply?.type === 'generated_image') {
                await sock.sendMessage(from, { image: reply.buffer, caption: `🎨 ${reply.prompt}` });
            } else if (reply?.type === 'images') {
                for (const url of reply.images) await sock.sendMessage(from, { image: { url }, caption: reply.keyword });
            } else {
                await sock.sendMessage(from, { text: `♟️ *𝑨𝒚𝒂𝒏𝒐𝒌𝒐𝒖𝒋𝒊:*\n${reply}` });
            }
        } catch (err) {
            logger.error('AI command error:', err);
            await sock.sendMessage(from, { text: '❌ حدث خطأ.' });
        }
    }
};