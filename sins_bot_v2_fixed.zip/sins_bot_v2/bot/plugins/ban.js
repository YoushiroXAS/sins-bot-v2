const fs = require('fs');
const path = require('path');
const config = require('../config');
const { auditLog } = require('../utils/auditLog');

const blockFile = path.join(__dirname, '..', 'data', 'blockedUsers.json');

// 🔧 الـ handler بينادي isUserBlocked مع كل رسالة، وكانت بتقرا الملف وتحلله من
// الأول في كل مرة. دلوقتي بنكاشي القائمة وبنعيد القراءة بس لما وقت تعديل الملف
// يتغير (فأي كاتب تاني زي أمر فك الحظر المدفوع بيتشاف فورًا). ولو الملف اتلف
// مؤقتًا بنستخدم آخر قائمة سليمة بدل ما نعتبر كل الناس غير محظورين.
let cache = { mtime: -1, list: [] };
function loadBlocked() {
    try {
        const st = fs.statSync(blockFile);
        if (st.mtimeMs !== cache.mtime) {
            cache = { mtime: st.mtimeMs, list: JSON.parse(fs.readFileSync(blockFile, 'utf8')) };
        }
    } catch (e) {
        if (e.code === 'ENOENT') cache = { mtime: -1, list: [] };
    }
    return cache.list;
}
function saveBlocked(data) {
    const tmp = blockFile + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
    fs.renameSync(tmp, blockFile); // كتابة ذرية
}

const jidUser = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

module.exports = {
    command: 'حظر',
    async execute(sock, msg, body, isGroup, from, sender, context) {
        if (!context.isOwner && !context.isDeveloper) {
            await sock.sendMessage(from, { text: '❌ هذا الأمر مخصص للمطورين والمالك فقط.' });
            return;
        }
        if (!isGroup) return;
        let targetJid = msg.message?.extendedTextMessage?.contextInfo?.participant ||
                        msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!targetJid) { await sock.sendMessage(from, { text: '⚠️ منشن أو رد على الشخص.' }); return; }
        const blocked = [...loadBlocked()];
        if (blocked.includes(targetJid)) {
            saveBlocked(blocked.filter(j => j !== targetJid));
            auditLog({ action: 'unblock', group: from, actor: sender, target: targetJid });
            await sock.sendMessage(from, { text: '✅ تم إلغاء الحظر.' });
        } else {
            // 🔧 أي مطور كان يقدر يحظر المالك أو مطور تاني. دلوقتي: المالك محمي دايمًا،
            // والمطورين محدش يحظرهم غير المالك.
            const targetId = jidUser(targetJid);
            const isTargetOwner = [config.ownerNumber, config.ownerLID].map(jidUser).filter(Boolean).includes(targetId);
            const isTargetDev = (context.developersData || []).some(j => jidUser(j) === targetId);
            if (isTargetOwner || (isTargetDev && !context.isOwner)) {
                auditLog({ action: 'block', result: 'denied-protected', group: from, actor: sender, target: targetJid });
                await sock.sendMessage(from, { text: isTargetOwner ? '⛔ مينفعش تحظر المالك.' : '⛔ مينفعش تحظر مطور، ده للمالك بس.' });
                return;
            }
            blocked.push(targetJid);
            saveBlocked(blocked);
            auditLog({ action: 'block', result: 'ok', group: from, actor: sender, target: targetJid });
            await sock.sendMessage(from, { text: '🚫 تم الحظر.' });
        }
    }
};
module.exports.isUserBlocked = function(jid) { return loadBlocked().includes(jid); };
