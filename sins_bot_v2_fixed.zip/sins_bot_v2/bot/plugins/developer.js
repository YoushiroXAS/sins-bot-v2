// 🔧 كان بيستورد موديول غير موجود (../haykala/elite) وبتوقيع دالة قديم
// (execute(sock, msg, ...args متعددة)) غير متوافق مع نظام الأوامر
// الحالي اللي بينادي كل أمر بـ context واحد بس: command.execute(context).
// الإصلاح: استخدام context.dataManager مباشرة على مخزن 'developers'
// الجاهز أصلاً في bootstrap.js - بدون أي موديول خارجي إضافي.
const { auditLog } = require('../utils/auditLog');

module.exports = {
    command: 'مطور',
    async execute(context) {
        const { sock, from, isOwner, msg, args, dataManager, developersData } = context;

        if (!isOwner) {
            await sock.sendMessage(from, { text: '❌ هذا الأمر مخصص للمالك فقط.' });
            return;
        }

        const sub = args[0]?.toLowerCase();
        if (!['اضف', 'ازل'].includes(sub)) {
            await sock.sendMessage(from, { text: '⚠️ استخدم `.مطور اضف` أو `.مطور ازل`.' });
            return;
        }

        let targetJid = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
                     || msg.message?.extendedTextMessage?.contextInfo?.participant;

        if (!targetJid && args[1]) {
            const num = args[1].replace(/\D/g, '');
            if (num) targetJid = num + '@s.whatsapp.net';
        }

        if (!targetJid) {
            await sock.sendMessage(from, { text: '⚠️ منشن أو رد على الشخص، أو اكتب رقمه مباشرة.' });
            return;
        }

        const clean = (jid) => (jid || '').replace(/\D/g, '');
        const list = [...developersData]; // نسخة، مش تعديل مصدر الـ context مباشرة
        const isMatch = (j) => j === targetJid || clean(j) === clean(targetJid);

        if (sub === 'اضف') {
            if (list.some(isMatch)) {
                await sock.sendMessage(from, { text: '⚠️ هذا المستخدم مطور بالفعل.' });
                return;
            }
            list.push(targetJid);
            dataManager.set('developers', list);
            auditLog({ action: 'developer-add', group: from, actor: context.sender, target: targetJid });
            await sock.sendMessage(from, { text: '✅ تمت إضافة المطور بنجاح.' });
        } else {
            if (!list.some(isMatch)) {
                await sock.sendMessage(from, { text: '⚠️ هذا المستخدم ليس مطوراً.' });
                return;
            }
            dataManager.set('developers', list.filter(j => !isMatch(j)));
            auditLog({ action: 'developer-remove', group: from, actor: context.sender, target: targetJid });
            await sock.sendMessage(from, { text: '✅ تمت إزالة المطور بنجاح.' });
        }
    }
};
