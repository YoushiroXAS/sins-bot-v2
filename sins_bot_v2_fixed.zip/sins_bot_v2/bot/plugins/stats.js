const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '..', 'data');
const statsFile = path.join(dataDir, 'stats.json');
const pointsFile = path.join(dataDir, 'points.json');
const titlesFile = path.join(dataDir, 'nickname.json');

function loadJSON(file) {
    try { if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) {}
    return {};
}

module.exports = {
    command: ['تفاعل', 'الترتيب'],
    async execute(sock, msg, body, isGroup, from, sender, context) {
        if (!isGroup) return;
        const command = body.slice(1).trim().split(/\s+/)[0]?.toLowerCase();

        if (command === 'تفاعل') {
            const statsData = loadJSON(statsFile);
            const titlesData = loadJSON(titlesFile);
            const groupStats = statsData.groups?.[from];
            const totalMessages = statsData.totalMessages?.[from] || 0;

            if (!groupStats?.users || totalMessages === 0) {
                await sock.sendMessage(from, { text: '📉 لا توجد إحصائيات لهذا الجروب بعد.' });
                return;
            }

            const types = groupStats.types || {};
            let msgText = `📊 *『 إحصائيات الدردشة 』*\n📈 *إجمالي الرسائل:* 【 *${totalMessages}* رسالة 】\n\n`;
            msgText += `💬 نص: *${types.text || 0}*\n🖼️ صور: *${types.image || 0}*\n`;
            msgText += `🎥 فيديو: *${types.video || 0}*\n✨ ملصقات: *${types.sticker || 0}*\n`;
            msgText += `🎙️ صوت: *${types.audio || 0}*\n━━━━━━━━━━━━━━━\n🏆 *الأعضاء المتفاعلون:*\n`;

            const sortedUsers = Object.entries(groupStats.users).sort((a, b) => (b[1].total || 0) - (a[1].total || 0));
            const mentions = [];
            sortedUsers.forEach(([jid, uData], index) => {
                const title = titlesData[from]?.[jid];
                const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : `${index + 1}.`;
                if (title) {
                    msgText += `${medal} *${title}* ➜ *${uData.total || 0}* رسالة\n`;
                } else {
                    msgText += `${medal} @${jid.split('@')[0]} ➜ *${uData.total || 0}* رسالة\n`;
                    mentions.push(jid);
                }
            });

            await sock.sendMessage(from, { text: msgText, mentions });
        }
        else if (command === 'الترتيب') {
            const pointsData = loadJSON(pointsFile);
            const titlesData = loadJSON(titlesFile);
            const groupPoints = pointsData[from]?.users || {};

            const sorted = Object.entries(groupPoints).sort((a, b) => b[1] - a[1]);
            if (!sorted.length) {
                await sock.sendMessage(from, { text: '📉 لوحة صدارة المشرفين فارغة.' });
                return;
            }

            let msgText = `👑 *نقاط المشرفين*\n\n`;
            const mentions = [];
            sorted.forEach(([jid, points], index) => {
                const title = titlesData[from]?.[jid];
                if (title) {
                    msgText += `${index + 1}. *${title}* ➜ *${points} نقطة*\n`;
                } else {
                    msgText += `${index + 1}. @${jid.split('@')[0]} ➜ *${points} نقطة*\n`;
                    mentions.push(jid);
                }
            });

            await sock.sendMessage(from, { text: msgText, mentions });
        }
    }
};