const { handleChoice, activeGames } = require('../libs/deathnote');
const logger = require('../utils/logger');

module.exports = {
    // 🔧 'شارك' و'ابدأ' بيتوجّهوا من global_commands.js (بيشوف أنهي لعبة تسجيلها مفتوح)، و'تلميح'
    // بيتوجّه من plugins/games.js. قبل كده 4 بلجنز كانوا بيتسابقوا على نفس الأسماء والأخير
    // (spy_commands) كان بيكسب، فمذكرة الموت مكانش حد يقدر يدخلها ولا يبدأها.
    command: ['اختار'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        const command = body.slice(1).trim().split(/\s+/)[0]?.toLowerCase();
        try {
            if (command === 'اختار') {
                if (!isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل في المجموعة فقط.' });
                const game = activeGames.get(from);
                if (!game || game.phase !== 'playing' || game.waitingForChoice !== sender)
                    return sock.sendMessage(from, { text: '❌ لا يمكنك الاختيار الآن.' });
                const target = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
                if (!target) return sock.sendMessage(from, { text: '⚠️ استخدم: .اختار @اللقب' });
                await handleChoice(sock, from, sender, target);
            }
        } catch (e) {
            logger.error('Deathnote command error:', e);
        }
    }
};