const fs = require('fs');
const path = require('path');
const { updateBotStatusCache } = require('../handlers/handler');

const statusFile = path.join(__dirname, '..', 'data', 'bot_status.txt');

module.exports = {
    command: ['تشغيل', 'ايقاف'],
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!context.isOwner && !context.isDeveloper) {
            await sock.sendMessage(from, { text: '❌ هذا الأمر مخصص للمالك والمطورين فقط.' });
            return;
        }
        const command = body.slice(context.prefix.length).trim().split(/\s+/)[0]?.toLowerCase();
        if (command === 'تشغيل') {
            fs.writeFileSync(statusFile, '[on]');
            updateBotStatusCache(true);
            await sock.sendMessage(from, { text: '✅ تم تشغيل البوت.' });
        } else {
            fs.writeFileSync(statusFile, '[off]');
            updateBotStatusCache(false);
            await sock.sendMessage(from, { text: '⛔ تم إيقاف البوت مؤقتاً.' });
        }
    }
};