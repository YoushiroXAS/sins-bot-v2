/**
 * GameManager - Manages active game sessions
 * Features: queue-based ops, auto-cleanup, auto-save, crash recovery
 */
class GameManager {
    constructor(saveInterval = 60000) {
        this.activeGames = new Map();
        this._operationQueue = new Map();
        this._saveInterval = null;
        this._cleanupInterval = null;
        this.config = {
            MAX_PLAYERS: 20,
            GAME_TIMEOUT: 30 * 60 * 1000,
            ANSWER_TIMEOUT: 30 * 1000,
            CLEANUP_INTERVAL: 5 * 60 * 1000,
            SAVE_INTERVAL: saveInterval,
        };
        this._startCleanup();
        this._startAutoSave();
    }

    async startGame(groupId, gameType, data = {}, saveCallback = null) {
        if (this.activeGames.has(groupId)) {
            throw new Error('Game already active in this group');
        }
        const session = {
            groupId,
            type: gameType,
            data,
            startedAt: Date.now(),
            lastActivity: Date.now(),
            isActive: true,
            timer: null,
            saveCallback
        };
        this.activeGames.set(groupId, session);
        return session;
    }

    async endGame(groupId, cleanupData = true) {
        const session = this.activeGames.get(groupId);
        if (!session) return false;
        
        if (session.timer) { clearTimeout(session.timer); session.timer = null; }
        if (session.saveCallback && session.data) {
            try { await session.saveCallback(session.data); } catch (e) {}
        }
        if (cleanupData && session.data?.players) {
            for (const playerId of Object.keys(session.data.players)) {
                delete session.data.players[playerId];
            }
        }
        session.isActive = false;
        this.activeGames.delete(groupId);
        return true;
    }

    async safeOperation(groupId, operation) {
        if (!this._operationQueue.has(groupId)) {
            this._operationQueue.set(groupId, Promise.resolve());
        }
        const queue = this._operationQueue.get(groupId);
        const result = queue.then(async () => {
            try { return await operation(); } catch (e) { throw e; }
        });
        this._operationQueue.set(groupId, result.catch(() => {}));
        return result;
    }

    async checkAnswer(groupId, userId, answer, checkFn) {
        return this.safeOperation(groupId, async () => {
            const session = this.activeGames.get(groupId);
            if (!session?.isActive) return false;
            session.lastActivity = Date.now();
            return checkFn(session, userId, answer);
        });
    }

    setGameTimer(groupId, callback, timeout) {
        const session = this.activeGames.get(groupId);
        if (!session) return;
        if (session.timer) clearTimeout(session.timer);
        session.timer = setTimeout(async () => {
            try { await callback(); } catch (e) {}
        }, timeout);
    }

    async isBotAdmin(sock, groupId) {
        try {
            // 🔧 كانت بتقارن p.id بـ JID البوت (...@s.whatsapp.net) بس. في الجروبات اللي بتستخدم LID
            // الـ id بيبقى @lid فكان البوت مبيلاقيش نفسه ومبيتعرفش إنه أدمن. دلوقتي بنقارن بالجزء
            // الخاص بالمستخدم (من غير الدومين ولا رقم الجهاز) على id/jid/phoneNumber/lid.
            const userPart = (j) => String(j || '').split('@')[0].split(':')[0];
            const botIds = new Set([sock.user?.id, sock.user?.lid].map(userPart).filter(Boolean));
            const metadata = await sock.groupMetadata(groupId);
            const participant = metadata.participants.find(p =>
                [p.id, p.jid, p.phoneNumber, p.lid].some(x => botIds.has(userPart(x))));
            return participant?.admin === 'admin' || participant?.admin === 'superadmin';
        } catch (e) { return false; }
    }

    _startCleanup() {
        this._cleanupInterval = setInterval(() => {
            const now = Date.now();
            for (const [groupId, session] of this.activeGames) {
                if (session.isActive && now - session.lastActivity > this.config.GAME_TIMEOUT) {
                    this.endGame(groupId).catch(() => {});
                }
            }
        }, this.config.CLEANUP_INTERVAL);
        if (this._cleanupInterval.unref) this._cleanupInterval.unref();
    }

    _startAutoSave() {
        this._saveInterval = setInterval(async () => {
            for (const [groupId, session] of this.activeGames) {
                if (session.saveCallback && session.data) {
                    try { await session.saveCallback(session.data); } catch (e) {}
                }
            }
        }, this.config.SAVE_INTERVAL);
        if (this._saveInterval.unref) this._saveInterval.unref();
    }

    async shutdown() {
        if (this._cleanupInterval) clearInterval(this._cleanupInterval);
        if (this._saveInterval) clearInterval(this._saveInterval);
        for (const [groupId] of this.activeGames) {
            await this.endGame(groupId, false);
        }
    }

    getStats() {
        return {
            activeGames: this.activeGames.size,
            games: Array.from(this.activeGames.entries()).map(([id, s]) => ({
                groupId: id, type: s.type, duration: Date.now() - s.startedAt
            }))
        };
    }
}

module.exports = GameManager;
