/**
 * loadEnv - تحميل ملف .env من جذر المشروع من غير مكتبة dotenv
 *
 * 🔧 ai.js و config.js بيقروا GROQ_API_KEY و OPENROUTER_API_KEY من process.env، لكن مفيش
 * حاجة في المشروع كانت بتحمّل ملف .env (مفيش dotenv ولا --env-file)، فالمفاتيح اللي
 * في الملف كانت بتتجاهل بصمت. على استضافة زي bot-hosting.net تقدر برضه تحطها
 * كـ Environment Variables من اللوحة، والمتغيرات الموجودة بالفعل بتتقدّم على الملف.
 *
 * الصيغة: KEY=VALUE في كل سطر، أسطر # للتعليق، وعلامات التنصيص حوالين القيمة بتتشال.
 */
const fs = require('fs');
const path = require('path');

function parseEnv(text) {
    const out = {};
    for (const raw of String(text).split(/\r?\n/)) {
        const line = raw.trim();
        if (!line || line.startsWith('#')) continue;
        const m = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
        if (!m) continue;
        let value = m[2].trim();
        if ((value.startsWith('"') && value.endsWith('"') && value.length >= 2) ||
            (value.startsWith("'") && value.endsWith("'") && value.length >= 2)) {
            value = value.slice(1, -1);
        }
        out[m[1]] = value;
    }
    return out;
}

function loadEnv(filePath = path.join(__dirname, '..', '..', '.env')) {
    let text;
    try { text = fs.readFileSync(filePath, 'utf8'); } catch { return 0; } // مفيش ملف: عادي
    let loaded = 0;
    for (const [key, value] of Object.entries(parseEnv(text))) {
        if (process.env[key] === undefined) { process.env[key] = value; loaded++; }
    }
    return loaded;
}

module.exports = { loadEnv, parseEnv };
