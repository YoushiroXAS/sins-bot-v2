/**
 * DataManager - Unified Data Layer (V2)
 * 
 * Problem it solves: In V1, data was stored in TWO parallel systems
 * (index.js store + dataManager.js). This caused corruption and race conditions.
 * 
 * V2 Solution: ALL data flows through this single manager.
 * Features:
 * - Atomic writes (write to temp file, then rename)
 * - Debounced writes: many set() calls in a short window are coalesced
 *   into a single disk write per key (default 2s window)
 * - Auto-save safety net every 5 minutes (catches anything not yet flushed)
 * - Per-key write lock (a slow write to one file never blocks another file)
 * - Graceful shutdown with flush
 * - Dirty tracking (only writes changed data)
 */
const fs = require('fs').promises;
const path = require('path');

const DEFAULT_DEBOUNCE_MS = 2000;

class DataManager {
    constructor(options = {}) {
        this._store = new Map();
        this._writeTimers = new Map();   // key -> Timeout handle (pending debounced write)
        this._inFlight = new Map();      // key -> Promise (write currently happening for that key)
        this._autoSaveInterval = null;
        this._debounceMs = options.debounceMs || DEFAULT_DEBOUNCE_MS;
        // أقصى تأخير للكتابة حتى لو الـ set() فضلت تتكرر (لو مفيش maxWait، مفتاح
        // بيتعدّل كل أقل من ثانيتين مكانش هيتكتب لحد ما النشاط يوقف)
        this._maxWaitMs = options.maxWaitMs || 10000;
        this._firstDirtyAt = new Map(); // key -> وقت أول تعديل لسه ماتكتبش
        // نفس المسار اللي BackupService بيكتب فيه (bot/backups)
        this._backupDir = options.backupDir || path.join(__dirname, '..', 'backups');
    }

    async init(key, filePath, defaultValue = {}, autoSave = true) {
        let data = defaultValue;
        let restored = false;
        try {
            const dir = path.dirname(filePath);
            await fs.mkdir(dir, { recursive: true }).catch(() => {});
            
            const raw = await fs.readFile(filePath, 'utf8').catch(() => null);
            if (raw) {
                try {
                    data = JSON.parse(raw);
                } catch (parseErr) {
                    // 🔧 كان هنا: أي ملف تالف بيتحوّل للقيمة الافتراضية من غير إنذار،
                    // وأول حفظ بعد كده بيكتب الفاضي فوق الملف (فلوس/ألقاب كل اللاعبين تضيع).
                    ({ data, restored } = await this._recoverCorrupt(key, filePath, defaultValue, parseErr));
                }
            } else {
                await fs.writeFile(filePath, JSON.stringify(defaultValue, null, 2));
            }
        } catch (e) {
            console.error(`[DataManager] Failed to load ${key}:`, e.message);
        }

        this._store.set(key, {
            data,
            filePath,
            dirty: restored,
            lastSave: Date.now()
        });
        if (restored) this._scheduleWrite(key); // اكتب النسخة المسترجعة على الملف الأصلي

        if (autoSave && !this._autoSaveInterval) {
            this._startAutoSave();
        }

        return data;
    }

    /**
     * ملف تالف: بنحفظ نسخة منه جنبه (.corrupt-<وقت>) وبنحاول نرجّع آخر نسخة
     * احتياطية سليمة من bot/backups، ولو مفيش بنستخدم القيمة الافتراضية.
     */
    async _recoverCorrupt(key, filePath, defaultValue, err) {
        const aside = `${filePath}.corrupt-${Date.now()}`;
        await fs.copyFile(filePath, aside).catch(() => {});
        console.error(`[DataManager] ${key}: الملف تالف (${err.message}). اتحفظت نسخة منه في ${path.basename(aside)}.`);

        const backup = await this._loadLatestBackup(filePath);
        if (backup !== undefined) {
            console.warn(`[DataManager] ${key}: اتسترجع من آخر نسخة احتياطية سليمة.`);
            return { data: backup, restored: true };
        }
        console.warn(`[DataManager] ${key}: مفيش نسخة احتياطية سليمة، هيتم استخدام القيمة الافتراضية.`);
        return { data: defaultValue, restored: false };
    }

    async _loadLatestBackup(filePath) {
        let dirs;
        try {
            const entries = await fs.readdir(this._backupDir, { withFileTypes: true });
            dirs = entries.filter(e => e.isDirectory() && /^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$/.test(e.name)).map(e => e.name).sort().reverse(); // الأحدث الأول
        } catch { return undefined; }
        for (const d of dirs) {
            try {
                return JSON.parse(await fs.readFile(path.join(this._backupDir, d, path.basename(filePath)), 'utf8'));
            } catch { /* جرّب اللي قبلها */ }
        }
        return undefined;
    }

    get(key) {
        const entry = this._store.get(key);
        return entry ? entry.data : null;
    }

    set(key, newData) {
        const entry = this._store.get(key);
        if (!entry) {
            console.warn(`[DataManager] Key "${key}" not initialized`);
            return;
        }
        entry.data = newData;
        entry.dirty = true;
        entry.lastSave = Date.now();
        this._scheduleWrite(key);
    }

    update(key, updater) {
        const entry = this._store.get(key);
        if (!entry) return;
        const newData = updater(JSON.parse(JSON.stringify(entry.data))); // Clone to avoid mutations
        this.set(key, newData);
    }

    /**
     * Debounce writes per key: if set() is called repeatedly on the same key
     * within the debounce window, only ONE disk write happens after things
     * settle down, instead of one write per set() call.
     */
    _scheduleWrite(key) {
        if (this._writeTimers.has(key)) {
            clearTimeout(this._writeTimers.get(key));
        }
        const now = Date.now();
        if (!this._firstDirtyAt.has(key)) this._firstDirtyAt.set(key, now);
        const waited = now - this._firstDirtyAt.get(key);
        const delay = Math.max(0, Math.min(this._debounceMs, this._maxWaitMs - waited));
        const timer = setTimeout(() => {
            this._writeTimers.delete(key);
            this._firstDirtyAt.delete(key);
            this._flushKey(key).catch(e =>
                console.error(`[DataManager] Debounced write failed for ${key}:`, e.message)
            );
        }, delay);
        // 🔧 كان هنا timer.unref() بحجة إن الكتابة المعلّقة متمنعش إغلاق البروسيس، بس ده
        // معناه إن أي خروج طبيعي والكتابة لسه معلّقة بيضيّعها بصمت. الـ timer ده
        // عمره أقصى maxWait (10 ثواني) فمفيش مشكلة إنه يستنّى لحد ما الكتابة تخلص.
        this._writeTimers.set(key, timer);
    }

    /**
     * Write a single key to disk. Uses a per-key lock so a write to one file
     * can never be blocked by (or block) a write to a different file. If a
     * write is already in flight for this key when called again, it waits
     * for that write to finish and then flushes once more if still dirty
     * (so no update is ever silently dropped).
     */
    async _flushKey(key) {
        if (this._inFlight.has(key)) {
            await this._inFlight.get(key);
            const entry = this._store.get(key);
            if (!entry || !entry.dirty) return;
        }

        const writePromise = this._doWrite(key);
        this._inFlight.set(key, writePromise);
        try {
            await writePromise;
        } finally {
            this._inFlight.delete(key);
        }
    }

    async _doWrite(key) {
        const entry = this._store.get(key);
        if (!entry || !entry.dirty) return;

        // Snapshot dirty flag/data before the async write so a set() that
        // happens mid-write correctly leaves the entry dirty again.
        const snapshot = entry.data;
        entry.dirty = false;
        try {
            await this._atomicWrite(entry.filePath, snapshot);
        } catch (e) {
            console.error(`[DataManager] Write failed for ${key}:`, e.message);
            entry.dirty = true; // retry on next autosave / set()
        }
    }

    async saveAll() {
        // Cancel pending debounced writes - the flush below writes the
        // current data anyway, so there is no need for the timer to fire later.
        for (const [, timer] of this._writeTimers) {
            clearTimeout(timer);
        }
        this._writeTimers.clear();
        this._firstDirtyAt.clear();

        const promises = [];
        for (const [key, entry] of this._store) {
            if (entry.dirty) {
                promises.push(this._flushKey(key));
            }
        }
        await Promise.all(promises);
    }

    async _atomicWrite(filePath, data) {
        const tempPath = filePath + '.tmp';
        await fs.writeFile(tempPath, JSON.stringify(data, null, 2));
        await fs.rename(tempPath, filePath);
    }

    _startAutoSave() {
        this._autoSaveInterval = setInterval(() => {
            this.saveAll().catch(e => console.error('[DataManager] Auto-save:', e.message));
        }, 5 * 60 * 1000); // Every 5 minutes
        // 🔧 بدون .unref() هنا، الـ interval ده كان بيمنع الـ process من
        // الإغلاق الطبيعي لحد 5 دقايق حتى لو كل حاجة تانية خلصت - نفس
        // فئة مشكلة logger.js/rateLimiter.js/recovery.js.
        if (this._autoSaveInterval.unref) this._autoSaveInterval.unref();
    }

    async shutdown() {
        if (this._autoSaveInterval) clearInterval(this._autoSaveInterval);
        console.log('[DataManager] Flushing all data...');
        await this.saveAll();
        console.log('[DataManager] All data saved.');
    }

    getStats() {
        return {
            stores: this._store.size,
            dirtyStores: [...this._store.values()].filter(e => e.dirty).length,
            keys: Array.from(this._store.keys())
        };
    }
}

module.exports = DataManager;
