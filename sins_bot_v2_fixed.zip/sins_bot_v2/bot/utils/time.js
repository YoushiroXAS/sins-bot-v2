/**
 * time - مفاتيح اليوم والأسبوع بتوقيت البوت (config.timezone، الافتراضي Africa/Cairo)
 *
 * 🔧 حدود العجلة والروليت والجاكبوت اليومية كانت بتتصفّر على تاريخ UTC (الساعة 2 أو 3 الفجر
 * بتوقيت القاهرة)، بينما تصفير الإحصائيات والملخص اليومي في botService على منتصف ليل
 * القاهرة. دلوقتي كله على نفس التوقيت. صيغة المفتاح YYYY-MM-DD زي ما هي، فالبيانات
 * المحفوظة متوافقة.
 */
const config = require('../config');

const TZ = config.timezone || 'Africa/Cairo';
const dayFormatter = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' });

// new Date(Date.now()) بدل new Date() عشان الاختبارات تقدر تتحكم في الساعة بـ Date.now
const nowDate = () => new Date(Date.now());

const todayKey = (date = nowDate()) => dayFormatter.format(date);

// Date بتحمل ساعة الحائط بتوقيت البوت (الحقول getFullYear/getDay.. بترجّع قيم القاهرة)
const zonedNow = (date = nowDate()) => new Date(date.toLocaleString('en-US', { timeZone: TZ }));

// نفس معادلة الأسبوع القديمة بالظبط (عشان مفاتيح الأسابيع المحفوظة تفضل متوافقة)، بس على ساعة القاهرة
function weekKey(date = nowDate()) {
    const d = zonedNow(date);
    const onejan = new Date(d.getFullYear(), 0, 1);
    const week = Math.ceil((((d - onejan) / 864e5) + onejan.getDay() + 1) / 7);
    return `${d.getFullYear()}-W${week}`;
}

module.exports = { todayKey, weekKey, zonedNow, TZ };
