/**
 * RateLimiter - Spam prevention with sliding window
 * Features: per-user tracking, auto-block, auto-cleanup
 */
class RateLimiter {
    constructor(config = {}) {
        this._requests = new Map();
        this._blocked = new Map();
        this._cleanupInterval = null;
        this._notified = new Map(); // userId -> وقت انتهاء الحظر اللي اتبلّغ عنه بالفعل
        // 🔧 config.js فيه rateLimit بمفاتيح MAX_REQUESTS/WINDOW_MS/BLOCK_DURATION، لكن الـ
        // constructor كان بيقرا maxRequests/windowMs/blockDuration، والـ Container كان
        // بينشئه من غير إعدادات أصلاً، فتعديل config.rateLimit مكانش بيأثر على حاجة.
        // دلوقتي الصيغتين مقبولتين.
        this.config = {
            MAX_REQUESTS: config.MAX_REQUESTS ?? config.maxRequests ?? 10,
            WINDOW_MS: config.WINDOW_MS ?? config.windowMs ?? 10000,
            BLOCK_DURATION: config.BLOCK_DURATION ?? config.blockDuration ?? 60000,
            CLEANUP_INTERVAL: 60000,
        };
        this._startCleanup();
    }

    isAllowed(userId) {
        // Check block
        if (this._blocked.has(userId)) {
            const blockExpiry = this._blocked.get(userId);
            if (Date.now() < blockExpiry) return false;
            this._blocked.delete(userId);
        }

        const now = Date.now();
        const record = this._requests.get(userId);

        // New window
        if (!record || now - record.timestamp > this.config.WINDOW_MS) {
            this._requests.set(userId, { count: 1, timestamp: now });
            return true;
        }

        // Rate limit hit
        if (record.count >= this.config.MAX_REQUESTS) {
            this._blocked.set(userId, now + this.config.BLOCK_DURATION);
            return false;
        }

        record.count++;
        return true;
    }

    // 🔧 الـ middleware كان بيبعت رسالة "تم حظرك" على كل محاولة مرفوضة، فمستخدم بيعمل سبام
    // كان بيخلّي البوت نفسه يبعت مئات الرسايل (خطر على رقم واتساب). دلوقتي بيتبلّغ مرة
    // واحدة بس لكل فترة حظر.
    shouldNotify(userId) {
        const expiry = this._blocked.get(userId);
        if (!expiry || Date.now() >= expiry) return false;
        if (this._notified.get(userId) === expiry) return false;
        this._notified.set(userId, expiry);
        return true;
    }

    reset(userId) {
        this._requests.delete(userId);
        this._blocked.delete(userId);
        this._notified.delete(userId);
    }

    _startCleanup() {
        this._cleanupInterval = setInterval(() => {
            const now = Date.now();
            for (const [userId, record] of this._requests) {
                if (now - record.timestamp > this.config.WINDOW_MS * 2) {
                    this._requests.delete(userId);
                }
            }
            for (const [userId, expiry] of this._blocked) {
                if (now > expiry) this._blocked.delete(userId);
            }
            for (const [userId, expiry] of this._notified) {
                if (now > expiry) this._notified.delete(userId);
            }
        }, this.config.CLEANUP_INTERVAL);
        if (this._cleanupInterval.unref) this._cleanupInterval.unref();
    }

    shutdown() {
        if (this._cleanupInterval) clearInterval(this._cleanupInterval);
    }

    getStats() {
        return {
            activeUsers: this._requests.size,
            blockedUsers: this._blocked.size
        };
    }
}

module.exports = RateLimiter;
