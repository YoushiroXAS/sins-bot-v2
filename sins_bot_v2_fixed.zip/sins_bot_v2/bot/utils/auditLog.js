/**
 * auditLog - سجل تدقيق للعمليات الإدارية والمالية (إيداع/خصم/تحويل/حظر/تعيين مطور...)
 *
 * بيكتب سطر JSON لكل عملية في bot/logs/audit.log: الوقت، منفّذ العملية، الهدف،
 * الجروب، المبلغ، والنتيجة. بيحتوي JIDs ومبالغ بس (مفيش أسرار ولا نصوص رسايل).
 * - مبيرميش خطأ أبدًا: فشل الكتابة مينفعش يعطّل أمر الإدارة نفسه.
 * - لما الملف يعدّي 5MB بيتحوّل لـ audit.log.1 (نسخة واحدة قديمة بتتستبدل).
 */
const fs = require('fs');
const path = require('path');

const LOG_DIR = path.join(__dirname, '..', 'logs');
const LOG_FILE = path.join(LOG_DIR, 'audit.log');
const MAX_BYTES = 5 * 1024 * 1024;

function auditLog(event) {
    try {
        fs.mkdirSync(LOG_DIR, { recursive: true });
        try {
            if (fs.statSync(LOG_FILE).size > MAX_BYTES) fs.renameSync(LOG_FILE, LOG_FILE + '.1');
        } catch { /* الملف لسه مش موجود */ }
        const line = JSON.stringify({ ts: new Date().toISOString(), ...event }) + '\n';
        fs.appendFile(LOG_FILE, line, () => { /* مفيش تعطيل لو فشل */ });
    } catch { /* ignore */ }
}

module.exports = { auditLog, LOG_FILE };
