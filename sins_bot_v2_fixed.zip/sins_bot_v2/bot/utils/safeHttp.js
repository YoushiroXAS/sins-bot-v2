/**
 * safeHttp - تحميل ملفات من روابط جاية من مصادر خارجية بشكل آمن (Part 9 M9)
 *
 * ytDownloader كان بياخد رابط التحميل من API خارجي (savetube) ويحمّله كله في الذاكرة
 * من غير سقف حجم، ومن غير ما يتأكد إن الرابط مش بيشاور على شبكة داخلية. هنا:
 *  - مسموح http/https بس، ومن غير بيانات دخول جوه الرابط.
 *  - رفض localhost والعناوين الداخلية (127/8، 10/8، 172.16/12، 192.168/16، 169.254/16،
 *    CGNAT، IPv6 المحلي) سواء كتبها المصدر كـ IP أو كاسم بيتحل (DNS) لعنوان داخلي.
 *  - سقف حجم (maxContentLength) وعدد إعادات توجيه محدود، وإعادة التوجيه نفسها
 *    بتتفحص قبل ما تتبع.
 */
const dns = require('dns').promises;
const net = require('net');

const DEFAULT_MAX_BYTES = 50 * 1024 * 1024;

function isPrivateIp(ip) {
    if (net.isIPv4(ip)) {
        const [a, b] = ip.split('.').map(Number);
        return a === 0 || a === 10 || a === 127 || a >= 224
            || (a === 169 && b === 254)
            || (a === 172 && b >= 16 && b <= 31)
            || (a === 192 && b === 168)
            || (a === 100 && b >= 64 && b <= 127);
    }
    if (net.isIPv6(ip)) {
        const l = ip.toLowerCase();
        if (l === '::' || l === '::1') return true;
        if (l.startsWith('::ffff:')) {
            const v4 = l.slice(7);
            return net.isIPv4(v4) ? isPrivateIp(v4) : true; // الشكل الـ hex: نعتبره غير آمن
        }
        return /^f[cd]/.test(l) || /^fe[89ab]/.test(l);
    }
    return true; // مش IP صالح
}

function isSafeHostnameSync(hostname) {
    const h = String(hostname || '').toLowerCase().replace(/^\[|\]$/g, '');
    if (!h) return false;
    if (net.isIP(h)) return !isPrivateIp(h);
    if (h === 'localhost' || /\.(localhost|local|internal|lan|home|corp)$/.test(h)) return false;
    return /^[a-z0-9.-]+$/.test(h) && h.includes('.');
}

async function assertSafeUrl(urlStr) {
    let u;
    try { u = new URL(urlStr); } catch { throw new Error('رابط غير صالح'); }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') throw new Error('نوع الرابط غير مسموح');
    if (u.username || u.password) throw new Error('الرابط فيه بيانات دخول');
    if (!isSafeHostnameSync(u.hostname)) throw new Error('عنوان غير آمن');
    const host = u.hostname.replace(/^\[|\]$/g, '');
    if (!net.isIP(host)) {
        const addrs = await dns.lookup(host, { all: true });
        if (!addrs.length || addrs.some(a => isPrivateIp(a.address))) throw new Error('الاسم بيشاور على عنوان داخلي');
    }
    return u;
}

async function downloadBuffer(client, url, opts = {}) {
    const { maxBytes = DEFAULT_MAX_BYTES, timeout = 20000, assertUrl = assertSafeUrl } = opts;
    await assertUrl(url);
    const res = await client.get(url, {
        responseType: 'arraybuffer',
        timeout,
        maxContentLength: maxBytes,
        maxBodyLength: maxBytes,
        maxRedirects: 3,
        beforeRedirect: (options) => {
            if (!isSafeHostnameSync(options.hostname || options.host)) throw new Error('إعادة توجيه لعنوان غير آمن');
        },
    });
    return Buffer.from(res.data);
}

module.exports = { isPrivateIp, isSafeHostnameSync, assertSafeUrl, downloadBuffer, DEFAULT_MAX_BYTES };
