/**
 * Database Abstraction Layer
 * Currently uses JSON files via DataManager
 * Can be swapped for SQLite/MongoDB without changing business logic
 */

class DatabaseInterface {
    async get(key) { throw new Error('Not implemented'); }
    async set(key, value) { throw new Error('Not implemented'); }
    async delete(key) { throw new Error('Not implemented'); }
    async has(key) { throw new Error('Not implemented'); }
}

class JSONDatabase extends DatabaseInterface {
    constructor(dataManager) {
        super();
        this.dm = dataManager;
    }

    async get(key) { return this.dm.get(key); }
    async set(key, value) { this.dm.set(key, value); }
    async delete(key) { this.dm.set(key, null); }
    async has(key) { return this.dm.get(key) !== null; }
}

// Future: SQLiteDatabase, MongoDatabase, etc.
// class SQLiteDatabase extends DatabaseInterface { ... }

module.exports = { DatabaseInterface, JSONDatabase };
