/**
 * CacheLayer - In-memory cache with TTL
 * Prevents redundant file reads and API calls
 */
class CacheLayer {
    constructor(ttlMs = 60000) {
        this._cache = new Map();
        this._ttl = ttlMs;
        this._hits = 0;
        this._misses = 0;
    }

    async get(key, factory) {
        const cached = this._cache.get(key);
        if (cached && Date.now() - cached.timestamp < this._ttl) {
            this._hits++;
            return cached.value;
        }
        this._misses++;
        const value = await factory();
        this._cache.set(key, { value, timestamp: Date.now() });
        return value;
    }

    getSync(key) {
        const cached = this._cache.get(key);
        if (cached && Date.now() - cached.timestamp < this._ttl) {
            this._hits++;
            return cached.value;
        }
        return undefined;
    }

    setSync(key, value) {
        this._cache.set(key, { value, timestamp: Date.now() });
    }

    invalidate(key) { this._cache.delete(key); }
    clear() { this._cache.clear(); }
    
    getStats() {
        return {
            hits: this._hits,
            misses: this._misses,
            size: this._cache.size,
            hitRate: this._hits + this._misses > 0 
                ? ((this._hits / (this._hits + this._misses)) * 100).toFixed(1) + '%' 
                : 'N/A'
        };
    }
}

module.exports = CacheLayer;
