/**
 * Bootstrap - Wires all core modules together
 * This is where the magic happens: container → services → events → middlewares
 */
const path = require('path');
const fs = require('fs');

const DATA_DIR = path.join(__dirname, '..', 'data');
const SESSION_DIR = path.join(__dirname, '..', 'session');

// Ensure directories exist
[DATA_DIR, SESSION_DIR].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

async function bootstrap(container) {
    console.log('[BOOT] Initializing core services...');

    // 1. Data Manager (foundation - everything else depends on it)
    const dataManager = container.get('dataManager');
    
    // Initialize all data stores
    const dataFiles = [
        ['bank', path.join(DATA_DIR, 'bank.json'), { accounts: {} }],
        ['stats', path.join(DATA_DIR, 'stats.json'), { totalMessages: {}, groups: {} }],
        ['cumulativeMessages', path.join(DATA_DIR, 'cumulative_messages.json'), {}],
        ['bonusState', path.join(DATA_DIR, 'bonus_state.json'), { messages: {} }],
        ['titles', path.join(DATA_DIR, 'nickname.json'), {}],
        ['points', path.join(DATA_DIR, 'points.json'), {}],
        // reservations و protection بيمتلكهم المتجر (libs/shop/storage.js) لوحده - مش هنا
        ['developers', path.join(DATA_DIR, 'developers.json'), []],
        ['elites', path.join(DATA_DIR, 'elites.json'), []],
    ];
    
    for (const [key, filePath, defaultVal] of dataFiles) {
        await dataManager.init(key, filePath, defaultVal, true);
    }
    console.log('[BOOT] Data manager initialized with', dataFiles.length, 'stores');

    // 2. Event Bus (connects everything)
    const eventBus = container.get('eventBus');
    
    // Wire event listeners
    eventBus.on('command:executed', (data) => {
        container.get('monitor')?.trackCommand(data.command);
    });
    
    eventBus.on('message:received', () => {
        container.get('monitor')?.trackMessage();
    });
    
    eventBus.on('error:caught', (data) => {
        container.get('monitor')?.trackError();
        container.get('logger')?.error(data.error, { context: data.context });
    });
    
    eventBus.on('game:started', (data) => {
        container.get('recovery')?.saveGameState(data.groupId, data.type, data);
    });
    
    console.log('[BOOT] Event bus wired with listeners');

    // 3. Cache Layer
    const cache = container.get('cache');
    console.log('[BOOT] Cache layer active (TTL: 60s)');

    // 4. Monitor
    const monitor = container.get('monitor');
    console.log('[BOOT] Monitor active - Uptime:', monitor.getStats().uptimeFormatted);

    // 5. Recovery
    const recovery = container.get('recovery');
    console.log('[BOOT] Crash recovery active');

    // 6. Rate Limiter
    const rateLimiter = container.get('rateLimiter');
    console.log('[BOOT] Rate limiter active');

    // 7. Command Registry with middlewares
    const registry = container.get('commandRegistry');
    
    // Attach middlewares IN ORDER (they run sequentially)
    const rateLimitMiddleware = container.get('rateLimitMiddleware');
    const permissionMiddleware = container.get('permissionMiddleware');
    const cooldownMiddleware = container.get('cooldownMiddleware');
    
    registry.use(rateLimitMiddleware);
    registry.use(permissionMiddleware);
    registry.use(cooldownMiddleware);
    
    // Load all plugins
    const pluginsDir = path.join(__dirname, '..', 'plugins');
    if (fs.existsSync(pluginsDir)) {
        const report = registry.loadAllWithPluginsDir(pluginsDir);
        if (report?.failures?.length) {
            const lg = container.get('logger');
            for (const f of report.failures) lg.warn(`Plugin failed to load: ${f.file} - ${f.error}`);
        }
    }
    console.log('[BOOT] Command registry loaded with', registry.getCommandCount(), 'commands');

    // 8. Logger (unified)
    const logger = container.get('logger');
    logger.info('SINS_BOT V2 started successfully');

    // 9. Bot Service (Baileys connection)
    const botService = container.get('botService');
    console.log('[BOOT] Bot service ready');

    // 10. نسخ احتياطي دوري + أرباح ماكينة الأموال (الاتنين بيتوقفوا في gracefulShutdown)
    container.get('backupService').start();
    container.get('moneyMachineScheduler').start();

    console.log('[BOOT] All systems operational');
}

module.exports = bootstrap;
