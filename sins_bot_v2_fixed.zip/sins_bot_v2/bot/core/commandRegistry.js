/**
 * CommandRegistry - Professional Command Router (V2)
 * 
 * Features:
 * - Middleware pipeline (rate limit → permission → cooldown)
 * - Plugin loader with hot-reload support
 * - Event emission on execute
 * - Error boundary per command
 */
const fs = require('fs');
const path = require('path');

class CommandRegistry {
    constructor() {
        this._commands = new Map();
        this._middlewares = [];
        this._categories = new Map();
        this._loadFailures = [];   // [{ file, error }] بلجنز رمت خطأ وقت التحميل (مكتبة ناقصة مثلًا)
        this._skippedFiles = [];   // ملفات في plugins مش أوامر (مفيهاش command/execute)
        this._onExecute = null;
    }

    set onExecute(fn) { this._onExecute = fn; }

    // ====== Middleware Pipeline ======
    use(middleware) {
        this._middlewares.push(middleware);
    }

    // ====== Command Registration ======
    register(command) {
        const name = command.name.toLowerCase();
        if (this._commands.has(name)) {
            console.warn(`⚠️ Command conflict: "${name}" already registered`);
        }
        
        this._commands.set(name, command);

        const category = command.category || 'general';
        if (!this._categories.has(category)) {
            this._categories.set(category, []);
        }
        this._categories.get(category).push(name);

        if (command.aliases) {
            for (const alias of command.aliases) {
                this._commands.set(alias.toLowerCase(), command);
            }
        }
    }

    // ====== Execution with Middleware ======
    async execute(commandName, context) {
        const command = this._commands.get(commandName.toLowerCase());
        if (!command) return false;

        // Run middleware pipeline
        for (const middleware of this._middlewares) {
            try {
                const result = await middleware(context, command);
                if (result === false) return true; // Middleware blocked
            } catch (e) {
                console.error(`Middleware error:`, e);
                return true;
            }
        }

        // Execute command
        try {
            await command.execute(context);
            this._onExecute?.(commandName);
            return true;
        } catch (err) {
            console.error(`Command "${commandName}" failed:`, err.message);
            throw err; // Let handler send error message
        }
    }

    // ====== Plugin Loading ======
    loadAllWithPluginsDir(pluginsDir) {
        if (!fs.existsSync(pluginsDir)) {
            console.warn(`Plugins directory not found: ${pluginsDir}`);
            return;
        }

        const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
        this._loadFailures = [];
        this._skippedFiles = [];

        for (const file of files) {
            this._loadPlugin(path.join(pluginsDir, file));
        }

        // 🔧 قبل كده فشل تحميل البلجن (زي مكتبة ناقصة) كان سطر واحد في الكونسول وسط
        // اللوج وبعدين البوت بيشتغل عادي من غير الأوامر دي. دلوقتي فيه ملخص واضح
        // وبيرجّع تقرير بيستخدمه bootstrap عشان يكتبه في اللوج.
        const report = this.getLoadReport(files.length);
        console.log(`✅ Loaded ${this._commands.size} commands from ${report.loaded} plugins`);
        if (report.failures.length) {
            console.error(`[Registry] ⚠️ فشل تحميل ${report.failures.length} بلجن: ${report.failures.map(f => f.file).join(', ')}`);
        }
        return report;
    }

    /**
     * 🔧 البلجنز اللي عندها init(sock) (زي الترحيب التلقائي) محدش كان بينادي عليها خالص،
     * فالـ listener بتاعها مكانش بيتسجّل إلا لو حد شغّل الأمر يدويًا. دلوقتي botService
     * بينادي الدالة دي مع كل اتصال جديد (أول مرة وبعد أي reconnect) بالـ socket الحالي.
     */
    initPlugins(sock) {
        const seen = new Set();
        for (const command of this._commands.values()) {
            if (typeof command.init !== 'function' || seen.has(command.path)) continue;
            seen.add(command.path);
            try {
                command.init(sock);
            } catch (e) {
                console.error(`[Registry] فشل init للبلجن ${path.basename(command.path)}:`, e.message);
            }
        }
        return seen.size;
    }

    getLoadReport(total = null) {
        const skipped = this._skippedFiles.length;
        return {
            total,
            loaded: total === null ? null : total - this._loadFailures.length - skipped,
            failures: [...this._loadFailures],
            skipped: [...this._skippedFiles],
            commands: this._commands.size,
        };
    }

    _loadPlugin(pluginPath) {
        try {
            delete require.cache[require.resolve(pluginPath)];
        } catch (e) { /* not loaded before */ }

        try {
            const plugin = require(pluginPath);
            if (!plugin || !plugin.command || typeof plugin.execute !== 'function') {
                this._skippedFiles.push(path.basename(pluginPath));
                return false;
            }

            const execute = this._normalizeExecute(plugin);
            const commands = Array.isArray(plugin.command) ? plugin.command : [plugin.command];
            const canonical = String(commands[0]); // الاسم الأساسي (للـ cooldown: الـ alias مينفعش يتخطاه)
            for (const cmd of commands) {
                const key = cmd.toLowerCase();
                const previous = this._commands.get(key);
                if (previous && previous.path !== pluginPath) {
                    // مبنغيّرش السلوك الحالي (آخر ملف بيتحمّل بيكسب)، بس بنكتب تحذير
                    // واضح عشان التعارض ميبقاش صامت.
                    console.warn(`[Registry] تعارض أوامر: "${cmd}" معرّف في ${path.basename(previous.path)} وهيتم استبداله بـ ${path.basename(pluginPath)}`);
                }
                this._commands.set(key, {
                    ...plugin,
                    execute,
                    name: cmd,
                    canonical,
                    path: pluginPath
                });
            }
            return true;
        } catch (error) {
            console.error(`Failed to load plugin ${path.basename(pluginPath)}:`, error.message);
            this._loadFailures.push({ file: path.basename(pluginPath), error: String(error.message).split('\n')[0] });
            return false;
        }
    }

    /**
     * 🔧 الـ registry بينادي كل أمر بـ context واحد: command.execute(context).
     * لكن 22 من 25 بلجن في bot/plugins مكتوبين بالتوقيع القديم:
     *   execute(sock, msg, body, isGroup, from, sender, context, args)
     * يعني كانوا هيستقبلوا الـ context كله في `sock` وباقي الباراميترات
     * undefined، وأول سطر فيهم كان هيرمي TypeError (المتجر، البنك، الألعاب،
     * الألقاب، القرآن، ping...). بدل ما نعيد كتابة 22 ملف، بنكتشف التوقيع
     * القديم من عدد الباراميترات (execute.length > 1) ونحوّله هنا مرة واحدة.
     * البلجنز الجديدة execute(context) بتفضل زي ما هي.
     */
    _normalizeExecute(plugin) {
        const original = plugin.execute;
        if (original.length <= 1) return original;
        return (ctx) => original.call(
            plugin, ctx.sock, ctx.msg, ctx.body, ctx.isGroup, ctx.from, ctx.sender, ctx, ctx.args
        );
    }

    // ====== Hot Reload ======
    reload(commandName) {
        const command = this._commands.get(commandName.toLowerCase());
        if (!command?.path) return false;
        // 🔧 كان بينادي this.register(newPlugin) والـ register بتقرأ command.name
        // (والبلجن عنده command مش name) فكانت بترمي TypeError وبترجّع false
        // دايمًا. _loadPlugin بتعمل نفس الشغل (مسح الكاش + تحميل + تحويل التوقيع).
        const ok = this._loadPlugin(command.path);
        if (ok) console.log(`🔄 Reloaded: ${commandName}`);
        return ok === true;
    }

    // ====== Queries ======
    getCommand(name) { return this._commands.get(name.toLowerCase()); }
    getCommandCount() { return this._commands.size; }
    getByCategory(category) { return this._categories.get(category) || []; }
    getCategories() { return Array.from(this._categories.keys()); }
    
    getStats() {
        return {
            totalCommands: this._commands.size,
            categories: this._categories.size,
            categoryBreakdown: Object.fromEntries(
                Array.from(this._categories.entries()).map(([k, v]) => [k, v.length])
            )
        };
    }
}

module.exports = CommandRegistry;
