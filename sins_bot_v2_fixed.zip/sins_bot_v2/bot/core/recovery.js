/**
 * CrashRecovery - Saves and restores game states
 * Prevents game progress loss on bot restart
 */
const fs = require('fs');
const path = require('path');

const RECOVERY_FILE = path.join(__dirname, '..', 'data', 'recovery.json');
const MAX_AGE_MS = 30 * 60 * 1000; // 30 minutes
const CLEANUP_INTERVAL = 10 * 60 * 1000; // 10 minutes

class CrashRecovery {
    constructor() {
        this._state = {};
        this._cleanupInterval = null;
        this._load();
        
        // Periodic cleanup
        this._cleanupInterval = setInterval(() => this._cleanup(), CLEANUP_INTERVAL);
        if (this._cleanupInterval.unref) this._cleanupInterval.unref();
    }

    saveGameState(groupId, gameType, data) {
        this._state[groupId] = {
            gameType,
            data: JSON.parse(JSON.stringify(data)), // Deep clone
            savedAt: Date.now()
        };
        this._flush();
    }

    restoreGameState(groupId) {
        const state = this._state[groupId];
        if (!state) return null;
        
        if (Date.now() - state.savedAt > MAX_AGE_MS) {
            delete this._state[groupId];
            this._flush();
            return null;
        }
        
        delete this._state[groupId];
        this._flush();
        return state;
    }

    _flush() {
        try {
            const dir = path.dirname(RECOVERY_FILE);
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
            fs.writeFileSync(RECOVERY_FILE, JSON.stringify(this._state, null, 2));
        } catch (e) {
            console.error('Recovery save failed:', e.message);
        }
    }

    _load() {
        try {
            if (fs.existsSync(RECOVERY_FILE)) {
                this._state = JSON.parse(fs.readFileSync(RECOVERY_FILE, 'utf8'));
            }
        } catch (e) {
            this._state = {};
        }
    }

    _cleanup() {
        const now = Date.now();
        let changed = false;
        for (const groupId of Object.keys(this._state)) {
            if (now - this._state[groupId].savedAt > 60 * 60 * 1000) {
                delete this._state[groupId];
                changed = true;
            }
        }
        if (changed) this._flush();
    }

    shutdown() {
        if (this._cleanupInterval) clearInterval(this._cleanupInterval);
    }
}

module.exports = CrashRecovery;
