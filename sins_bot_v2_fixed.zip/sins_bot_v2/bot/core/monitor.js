/**
 * Monitor - Performance & Statistics Tracking
 * Tracks: uptime, commands, messages, errors, memory, top commands
 */
class Monitor {
    constructor() {
        this._startTime = Date.now();
        this._commandsExecuted = 0;
        this._messagesProcessed = 0;
        this._errors = 0;
        this._commandStats = new Map();
        this._activeGames = 0;
    }

    trackCommand(name) {
        this._commandsExecuted++;
        const cmd = this._commandStats.get(name) || { count: 0 };
        cmd.count++;
        cmd.lastUsed = Date.now();
        this._commandStats.set(name, cmd);
    }

    trackMessage() { this._messagesProcessed++; }
    trackError() { this._errors++; }
    setActiveGames(count) { this._activeGames = count; }

    getStats() {
        const uptime = Date.now() - this._startTime;
        return {
            uptime: Math.floor(uptime / 1000),
            uptimeFormatted: this._formatUptime(uptime),
            commandsExecuted: this._commandsExecuted,
            messagesProcessed: this._messagesProcessed,
            errors: this._errors,
            activeGames: this._activeGames,
            commandsPerMinute: (this._commandsExecuted / (uptime / 60000)).toFixed(1),
            memoryUsage: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1)}MB`,
            topCommands: [...this._commandStats.entries()]
                .sort((a, b) => b[1].count - a[1].count)
                .slice(0, 10)
                .map(([name, stats]) => ({ name, count: stats.count })),
        };
    }

    getStatusText() {
        const s = this.getStats();
        return `📊 *SINS_BOT Status*
⏱️ Uptime: ${s.uptimeFormatted}
📨 Messages: ${s.messagesProcessed}
⚡ Commands: ${s.commandsExecuted}
❌ Errors: ${s.errors}
🎮 Active Games: ${s.activeGames}
🧠 Memory: ${s.memoryUsage}
⚡ Cmd/min: ${s.commandsPerMinute}`;
    }

    _formatUptime(ms) {
        const d = Math.floor(ms / 86400000);
        const h = Math.floor((ms % 86400000) / 3600000);
        const m = Math.floor((ms % 3600000) / 60000);
        return `${d}d ${h}h ${m}m`;
    }
}

module.exports = Monitor;
