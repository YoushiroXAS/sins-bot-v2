/**
 * EventBus - Async Event System
 * Priority-based listeners with error isolation
 */
class EventBus {
    constructor() {
        this._listeners = new Map();
    }

    on(event, callback, priority = 0) {
        if (!this._listeners.has(event)) {
            this._listeners.set(event, []);
        }
        this._listeners.get(event).push({ callback, priority });
        this._listeners.get(event).sort((a, b) => b.priority - a.priority);
    }

    async emit(event, data) {
        const listeners = this._listeners.get(event) || [];
        for (const listener of listeners) {
            try {
                await listener.callback(data);
            } catch (e) {
                console.error(`[EventBus:${event}]`, e.message);
            }
        }
    }

    off(event, callback) {
        if (!this._listeners.has(event)) return;
        const listeners = this._listeners.get(event);
        this._listeners.set(event, listeners.filter(l => l.callback !== callback));
    }

    listenerCount(event) {
        return this._listeners.get(event)?.length || 0;
    }
}

module.exports = EventBus;
