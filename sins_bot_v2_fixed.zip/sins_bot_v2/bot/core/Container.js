/**
 * Container - Dependency Injection Container (Enhanced V2)
 * 
 * All core modules are registered here and wired together.
 * This is the heart of the bot's architecture.
 * 
 * Services:
 * - dataManager: Unified data layer
 * - eventBus: Event-driven communication
 * - cache: In-memory caching
 * - monitor: Performance monitoring
 * - recovery: Crash recovery
 * - rateLimiter: Spam prevention
 * - rateLimitMiddleware: Rate limiting as middleware
 * - permissionMiddleware: Permission checking
 * - cooldownMiddleware: Command cooldowns
 * - commandRegistry: Command routing
 * - logger: Structured logging
 * - botService: WhatsApp connection
 * - gameManager: Game state management
 */

/**
 * الكلاس الفعلي بتاع الـ DI Container.
 *
 * 🔧 كان هنا قبل كده: const Container = require('./Container');
 * الملف كان بينادي نفسه (self-require) - على أي نظام حساس لحالة
 * الأحرف (Linux) ده كان هيتحل لنفس الملف بالظبط، وNode.js بيرجّع
 * {} فاضي لأي ملف بينادي نفسه وهو لسه بيتحمّل (circular dependency)،
 * فـ `new Container()` تحت كانت هترمي "Container is not a constructor"
 * فورًا. مفيش أي كلاس Container معرّف في أي ملف تاني بالمشروع، فالكلاس
 * اتعرّف هنا مباشرة - بنفس الأسلوب المستخدم في باقي كلاسات المشروع
 * (RateLimiter, EventBus, ...): كل حاجة في ملفها.
 */
class Container {
    constructor() {
        this._factories = new Map();   // name -> { factory, singleton }
        this._instances = new Map();   // name -> singleton instance (بعد أول get())
        this._resolving = new Set();   // لاكتشاف أي اعتمادية دائرية بين الخدمات
    }

    register(name, factory, isSingleton = false) {
        this._factories.set(name, { factory, singleton: !!isSingleton });
    }

    get(name) {
        if (this._instances.has(name)) return this._instances.get(name);

        const entry = this._factories.get(name);
        if (!entry) {
            throw new Error(`[Container] الخدمة "${name}" غير مسجّلة.`);
        }
        if (this._resolving.has(name)) {
            throw new Error(`[Container] اعتمادية دائرية (circular dependency) عند تحميل "${name}".`);
        }

        this._resolving.add(name);
        let instance;
        try {
            instance = entry.factory(this); // بنمرر الـ container نفسه عشان الـ factory تقدر تعمل get() لخدمات تانية
        } finally {
            this._resolving.delete(name);
        }

        if (entry.singleton) this._instances.set(name, instance);
        return instance;
    }
}

const DataManager = require('../utils/dataManager');
const EventBus = require('./eventBus');
const CacheLayer = require('./cache');
const Monitor = require('./monitor');
const CrashRecovery = require('./recovery');
const RateLimiter = require('../utils/rateLimiter');
const appConfig = require('../config');
const CommandRegistry = require('./commandRegistry');
const Logger = require('../utils/logger');
const BotService = require('../services/botService');
const GameManager = require('../utils/gameManager');
const MoneyMachineScheduler = require('../services/moneyMachineScheduler');
const BackupService = require('../services/backupService');
const createRateLimitMiddleware = require('../middlewares/rateLimitMiddleware');
const createPermissionMiddleware = require('../middlewares/permissionMiddleware');
const createCooldownMiddleware = require('../middlewares/cooldownMiddleware');

const container = new Container();

// ====== Register Core Services ======

// 1. Logger (no dependencies - register first so others can use it)
container.register('logger', () => {
    const instance = new Logger();
    Logger.setDefault(instance); // البلجنز اللي بتستورد utils/logger مباشرة بتستخدم نفس النسخة
    return instance;
}, true);

// 2. Data Manager (no dependencies)
container.register('dataManager', () => new DataManager(), true);

// 3. Event Bus (no dependencies)
container.register('eventBus', () => new EventBus(), true);

// 4. Cache (no dependencies)
container.register('cache', () => new CacheLayer(60000), true);

// 5. Monitor (no dependencies)
container.register('monitor', () => new Monitor(), true);

// 6. Recovery (no dependencies)
container.register('recovery', () => new CrashRecovery(), true);

// 7. Rate Limiter (no dependencies)
container.register('rateLimiter', () => new RateLimiter(appConfig.rateLimit), true);

// 8. Command Registry (depends on: eventBus, monitor)
container.register('commandRegistry', (c) => {
    const registry = new CommandRegistry();
    const eventBus = c.get('eventBus');
    const monitor = c.get('monitor');
    
    // Wire events into registry
    registry.onExecute = (cmdName) => {
        eventBus.emit('command:executed', { command: cmdName, timestamp: Date.now() });
        monitor.trackCommand(cmdName);
    };
    
    return registry;
}, true);

// 9. Rate Limit Middleware (depends on: rateLimiter)
// 🔧 الـ middlewares التلاتة (9, 10, 11) كانت مكرّرة inline هنا، وملفاتها
// الأصلية في bot/middlewares/ كانت ميتة (مفيش حد بيستوردها). النسخة
// الـ inline كانت ناقصة تخطي الـ rate limit للمالك. دلوقتي كل middleware
// معرّف في ملفه بس، والـ Container بس بيوصّله.
container.register('rateLimitMiddleware', (c) => createRateLimitMiddleware(c.get('rateLimiter')), true);

// 10. Permission Middleware
container.register('permissionMiddleware', () => createPermissionMiddleware(), true);

// 11. Cooldown Middleware
container.register('cooldownMiddleware', () => createCooldownMiddleware(), true);

// 12. Game Manager (depends on: logger, recovery)
container.register('gameManager', (c) => {
    const gm = new GameManager(60000);
    const recovery = c.get('recovery');
    const logger = c.get('logger');
    
    // Wire recovery
    gm.onGameStart = (groupId, type, data) => {
        recovery.saveGameState(groupId, type, data);
    };
    
    return gm;
}, true);

// 13. Bot Service (depends on: commandRegistry, dataManager, eventBus, monitor, logger, gameManager)
container.register('botService', (c) => {
    return new BotService(c);
}, true);

// 14. Money Machine Scheduler (depends on: dataManager, logger)
container.register('moneyMachineScheduler', (c) => new MoneyMachineScheduler(c.get('dataManager'), c.get('logger')), true);

// 15. Backup Service (depends on: logger)
container.register('backupService', (c) => new BackupService({ logger: c.get('logger') }), true);

module.exports = container;
