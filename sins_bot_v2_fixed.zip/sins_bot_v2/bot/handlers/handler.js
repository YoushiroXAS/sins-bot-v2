/**
 * Handler - Thin Message Router (V2)
 * 
 * V1 Problem: God handler (262 lines) did everything
 * V2 Solution: Thin router that delegates to specialized services
 * 
 * Flow:
 *   1. Extract message info
 *   2. Build context from container
 *   3. Run middleware pipeline
 *   4. Route to appropriate handler
 *   5. Emit events
 */
const config = require('../config');
const { getSabotageTitle } = require('../libs/shop/playerState');
const { state: shopState } = require('../libs/shop/storage');

// 🔧 الجزء الخاص بالمستخدم من الـ JID بدون الدومين ولا رقم الجهاز:
// '201061487911:12@s.whatsapp.net' و '272683665227808@lid' -> أرقام بس.
const jidUser = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');

// 🔧 حالة تشغيل/إيقاف البوت كانت بتتقرا من الملف مع كل رسالة. دلوقتي كاش في
// الذاكرة بيتحدّث من أمر .تشغيل/.ايقاف (MessageHandler.updateBotStatusCache).
let botEnabledCache = null;

class MessageHandler {
    constructor(container) {
        this.container = container;
        this.eventBus = container.get('eventBus');
        this.monitor = container.get('monitor');
        this.dataManager = container.get('dataManager');
        this.rateLimiter = container.get('rateLimiter');
        this.registry = container.get('commandRegistry');
        this.logger = container.get('logger');
        
        // Load specialized handlers lazily
        this._statsHandler = null;
        this._gameRouter = null;
    }

    get statsHandler() {
        if (!this._statsHandler) this._statsHandler = new (require('./statsHandler'))(this.container);
        return this._statsHandler;
    }

    get gameRouter() {
        if (!this._gameRouter) this._gameRouter = new (require('./gameRouter'))(this.container);
        return this._gameRouter;
    }

    async handle(sock, msg) {
        // Skip invalid messages
        if (!msg?.message) return;

        const messageType = this._getMessageType(msg);
        
        // Skip ignored types
        if (['protocolMessage', 'reactionMessage', 'senderKeyDistributionMessage', 'editedMessage']
            .includes(messageType)) return;

        // Extract core info
        const from = msg.key.remoteJid;
        const isGroup = from.endsWith('@g.us');
        const botJid = this._getBotJid(sock);
        const sender = msg.key.fromMe ? botJid : (msg.key.participant || msg.key.remoteJid);
        const body = this._extractBody(msg);

        // Emit message received event
        this.eventBus.emit('message:received', { from, sender, body, isGroup, messageType });

        // 1. Stats tracking (always)
        // رسايل البوت نفسه (fromMe) مبتتحسبش في إحصائيات الأعضاء
        if (isGroup && !msg.key.fromMe) {
            this.statsHandler.track(msg, messageType, from, sender, botJid);
        }

        // 🔧 config.limits.MAX_MESSAGE_LENGTH كان معرّف في config.js ومحدش بيطبّقه.
        // الرسايل الضخمة غير الطبيعية بتتجاهل قبل أي معالجة (أوامر/ألعاب/regex)
        // عشان متستهلكش ذاكرة ومعالج. الإحصائيات فوق اتسجلت قبل كده زي ما هي.
        const maxLen = config.limits?.MAX_MESSAGE_LENGTH || 4096;
        if (body && body.length > maxLen) return;

        // 2. Check if bot is enabled
        if (!this._isBotEnabled() && body !== config.prefix + 'تشغيل') return;

        // 3. Check if user is blocked
        if (await this._isBlocked(sender, body)) return;

        // 4. Build context
        const context = this._buildContext(sock, from, sender, isGroup, botJid);

        // 5. Check bonuses
        if (isGroup && !msg.key.fromMe) {
            await this.statsHandler.checkBonuses(sock, from, sender, context);
        }

        // 6. Route games (numbers, game answers, etc.)
        const gameHandled = await this.gameRouter.route(sock, msg, body, from, sender, isGroup, context);
        if (gameHandled) return;

        // 7. Handle commands
        if (body && body.startsWith(config.prefix)) {
            await this._handleCommand(sock, msg, body, from, sender, isGroup, context);
        }
    }

    _getMessageType(msg) {
        const types = Object.keys(msg.message);
        return types.find(t => !['protocolMessage', 'reactionMessage', 'senderKeyDistributionMessage', 'editedMessage'].includes(t)) || types[0];
    }

    _getBotJid(sock) {
        const id = sock.user?.id || '';
        return id.includes(':') ? id.split(':')[0] + '@s.whatsapp.net' : id;
    }

    _extractBody(msg) {
        return msg.message.conversation
            || msg.message.extendedTextMessage?.text
            || msg.message.imageMessage?.caption
            || msg.message.videoMessage?.caption
            || msg.message.buttonsResponseMessage?.selectedButtonId
            || msg.message.listResponseMessage?.title
            || '';
    }

    _isBotEnabled() {
        if (botEnabledCache !== null) return botEnabledCache;
        try {
            const fs = require('fs');
            const path = require('path');
            const file = path.join(__dirname, '..', 'data', 'bot_status.txt');
            botEnabledCache = fs.existsSync(file)
                ? fs.readFileSync(file, 'utf8').trim() !== '[off]'
                : true;
        } catch {
            botEnabledCache = true;
        }
        return botEnabledCache;
    }

    async _isBlocked(sender, body) {
        const banModule = require('../plugins/ban');
        if (banModule.isUserBlocked?.(sender)) {
            const cleaned = body.startsWith('.') ? body.slice(1).trim() : body.trim();
            const lower = cleaned.toLowerCase();
            // 🔧 كان مسموح بـ "شراء فك_حظر" بس، فالمحظور كان يدفع 500K وبعدين أمر الاستخدام
            // (استخدم فك_حظر) يتمنع ومعرفش يفك حظره. دلوقتي الشراء والاستخدام الاتنين مسموحين.
            const allowed = ['شراء فك_حظر', 'شراء فك حظر', 'استخدم فك_حظر', 'استخدم فك حظر'];
            return !allowed.some(a => lower.startsWith(a));
        }
        return false;
    }

    _buildContext(sock, from, sender, isGroup, botJid) {
        const bankData = this.dataManager.get('bank') || {};
        const titlesData = this.dataManager.get('titles') || {};
        // نفس الكائنات اللي المتجر بيمتلكها (قراءة بس) - من غير نسخة تانية من الملفات
        const reservations = shopState.reservations;
        const protection = shopState.protection;
        const developersData = this.dataManager.get('developers') || [];
        const elitesData = this.dataManager.get('elites') || [];

        // 🔧 كانت المقارنة بآخر 10 أرقام (endsWith) فأي رقم بينتهي بنفس الأرقام كان
        // ممكن يتحسب مالك، و ownerLID (موجود في config) مكانش بيتستخدم خالص.
        // دلوقتي مقارنة دقيقة بعد تطبيع الـ JID، والمالك بيتعرف برقمه أو بالـ LID.
        const senderId = jidUser(sender);
        const ownerIds = new Set([config.ownerNumber, config.ownerLID].map(jidUser).filter(Boolean));
        const isOwner = ownerIds.has(senderId);
        const inList = (list) => list.some(j => j === sender || (senderId && jidUser(j) === senderId));
        const isDeveloper = inList(developersData);
        const isElite = inList(elitesData);

        return {
            sock,
            from,
            sender,
            isGroup,
            botJid,
            isOwner,
            isDeveloper,
            isElite,
            bankData,
            titlesData,
            reservations,
            protection,
            developersData,
            elitesData,
            prefix: config.prefix,
            ownerNumber: config.ownerNumber,
            dataManager: this.dataManager,
            logger: this.logger,
            // Helper methods
            getGroupTitle: (jid) => titlesData[from]?.[jid] || null,
            mentionName: (jid) => {
                const title = titlesData[from]?.[jid];
                return title ? { text: title, mentions: [] } : { text: `@${jid.split('@')[0]}`, mentions: [jid] };
            },
            addBankMoney: (g, j, a) => {
                if (!bankData[g]) bankData[g] = { accounts: {} };
                if (!bankData[g].accounts[j]) bankData[g].accounts[j] = 0;
                bankData[g].accounts[j] += a;
                this.dataManager.set('bank', bankData);
            },

            // 🔧 الدوال التلاتة دي كان الكود (المتجر، بلجن البنك، بلجن الألقاب)
            // بينادي عليها من الـ context ومكانتش موجودة، فكل عملية شراء/تحويل
            // كانت بتعدّل الرصيد في الذاكرة وبعدين ترمي "saveBank is not a
            // function" قبل الحفظ. الحفظ لازم يمر من dataManager.set عشان
            // الـ entry تتعلّم dirty وتتكتب على القرص (التعديل المباشر على
            // الكائن لوحده مبيعلّمش حاجة).
            saveBank: () => this.dataManager.set('bank', bankData),
            updateTitlesDirect: (g, j, title) => {
                if (!titlesData[g]) titlesData[g] = {};
                titlesData[g][j] = title;
                this.dataManager.set('titles', titlesData);
            },
            // اللقب اللي بيظهر للعضو في الجروب الحالي: لقب التخريب (من سلعة
            // التخريب) لو شغّال، وإلا اللقب المسجّل، وإلا null.
            getDisplayTitle: (jid) => getSabotageTitle(from, jid) || titlesData[from]?.[jid] || null,
        };
    }

    async _handleCommand(sock, msg, body, from, sender, isGroup, context) {
        const args = body.slice(config.prefix.length).trim().split(/\s+/);
        const command = args.shift()?.toLowerCase();
        if (!command) return;

        this.logger.info(`Command: ${command} from ${sender} in ${from}`);

        try {
            const executed = await this.registry.execute(command, {
                ...context,
                msg,
                body,
                args,
                command
            });

            if (executed) {
                this.eventBus.emit('command:executed', { command, sender, from });
                this.logger.success(`Executed: ${command}`);
            } else {
                // Unknown command - could add suggestion logic here
                this.logger.warn(`Unknown command: ${command}`);
            }
        } catch (err) {
            this.logger.error(`Command failed: ${command}`, err);
            this.eventBus.emit('error:caught', { error: err, context: `command:${command}` });
            
            await sock.sendMessage(from, { 
                text: config.messages.error || '❌ حدث خطأ أثناء تنفيذ الأمر.' 
            }).catch(() => {});
        }
    }
}

// بيتنادى من plugins/botstatus.js بعد ما يكتب حالة التشغيل في الملف
MessageHandler.updateBotStatusCache = (enabled) => { botEnabledCache = !!enabled; };

module.exports = MessageHandler;
