/**
 * GameRouter - Routes game-related messages to appropriate handlers
 * Extracted from the god handler
 * 
 * Handles:
 * - Number-based inputs (manga, manhwa, songs)
 * - Active game answers (Death Note, Chess, general games)
 * - Game state management via gameManager
 */
class GameRouter {
    constructor(container) {
        this.container = container;
        this.logger = container.get('logger');
        this.gameManager = container.get('gameManager');
        
        // Lazy-load game libraries
        this._games = null;
        this._deathnote = null;
        this._chess = null;
        this._songHandler = null;
        this._mangaHandler = null;
        this._manhwaHandler = null;
        this._loggedErrors = new Set(); // عشان نفس الخطأ ميتسجّلش مع كل رسالة
    }

    /**
     * كل الجروبات اللي فيها لعبة أو باب تسجيل مفتوح دلوقتي (كل الألعاب بتخزّن حالتها في الذاكرة
     * بس، فأي إيقاف للبوت بيلغيها - شوف docs/GAME_STATE.md). بنفحص بس المكتبات اللي اتحمّلت
     * فعلًا (المكتبة اللي محدش استخدمها مفيهاش ألعاب)، وبنرجّع الجروبات (@g.us) بس.
     */
    getActiveGameChats() {
        const chats = new Set();
        const loaded = (rel) => {
            try {
                const resolved = require.resolve(rel);
                return require.cache[resolved] ? require(rel) : null;
            } catch { return null; }
        };
        try { for (const id of (loaded('../libs/games')?.listActiveGames?.() || [])) chats.add(id); } catch { /* ignore */ }
        for (const [rel, props] of [
            ['../libs/deathnote', ['activeGames', 'registrationSessions']],
            ['../libs/spygame', ['activeGames', 'registrationSessions']],
            ['../libs/chess', ['activeGames']],
            ['../libs/sudoku', ['activeGames']],
        ]) {
            const lib = loaded(rel);
            if (!lib) continue;
            for (const prop of props) {
                try { for (const id of lib[prop]?.keys?.() || []) chats.add(id); } catch { /* ignore */ }
            }
        }
        return [...chats].filter(id => typeof id === 'string' && id.endsWith('@g.us'));
    }

    // 🔧 كانت كل الـ catch هنا فاضية (catch (e) {}) فأي خطأ في لعبة بيختفي ومحدش يعرف.
    // دلوقتي بيتسجّل (باسم اللعبة والجروب) مرة واحدة لكل نوع خطأ.
    _logError(label, e, from) {
        const key = `${label}:${e?.message}`;
        if (this._loggedErrors.has(key)) return;
        this._loggedErrors.add(key);
        this.logger.error(`[GameRouter] ${label} failed (chat ${from})`, e);
    }

    // Lazy getters to avoid circular deps
    get games() {
        if (!this._games) this._games = require('../libs/games');
        return this._games;
    }
    get deathnote() {
        if (!this._deathnote) this._deathnote = require('../libs/deathnote');
        return this._deathnote;
    }
    get chess() {
        if (!this._chess) this._chess = require('../libs/chess');
        return this._chess;
    }

    async route(sock, msg, body, from, sender, isGroup, context) {
        // 1. Private chat: number input for manga/manhwa
        if (!isGroup && /^\d+$/.test(body.trim())) {
            return await this._handlePrivateNumber(sock, from, sender, body.trim(), context, msg);
        }

        // 2. Group chat: number input
        // 🔧 كان الرقم في الجروب بيروح لاختيار الأغنية بس ويرجّع النتيجة، فإجابات
        // الألعاب الرقمية (لعبة شغالة في الجروب) عمرها ما كانت بتوصل. دلوقتي لو
        // العضو عنده بحث أغاني شغّال الرقم ليه، وإلا بيكمل لألعاب الجروب النشطة.
        if (isGroup && /^\d+$/.test(body.trim())) {
            if (await this._handleSongNumber(sock, msg, body, from, sender, context)) return true;
            return await this._handleActiveGames(sock, from, sender, body, msg);
        }

        // 3. Group chat: active game answers
        if (isGroup) {
            return await this._handleActiveGames(sock, from, sender, body, msg);
        }

        return false;
    }

    async _handlePrivateNumber(sock, from, sender, number, context, msg) {
        try {
            const { handleMangaNumber } = require('../libs/manga');
            const handled = await handleMangaNumber(sock, from, sender, number, context, msg);
            if (handled) return true;
        } catch (e) { this._logError('manga number', e, from); }

        try {
            const { handleManhwaNumber } = require('../libs/manhwa');
            await handleManhwaNumber(sock, from, sender, number, context, msg);
            return true;
        } catch (e) { this._logError('manhwa number', e, from); }

        return false;
    }

    async _handleSongNumber(sock, msg, body, from, sender, context) {
        try {
            const { handleSong, hasActiveSearch } = require('../libs/song');
            if (hasActiveSearch(sender)) {
                await handleSong(sock, msg, body, true, from, sender, context);
                return true;
            }
        } catch (e) {
            this.logger.error('Song number handler error', e);
        }
        return false;
    }

    async _handleActiveGames(sock, from, sender, body, msg) {
        // Death Note
        try {
            if (this.deathnote.activeGames?.has(from)) {
                const answered = await this.deathnote.checkAnswer(sock, from, sender, body);
                if (answered) return true;
            }
        } catch (e) { this._logError('deathnote answer', e, from); }

        // Chess
        try {
            if (this.chess.activeGames?.has(from) && !body.startsWith('.')) {
                await this.chess.makeMove(sock, from, sender, body.trim(), msg);
                return true;
            }
        } catch (e) { this._logError('chess move', e, from); }

        // General games
        try {
            if (this.games.hasActiveGame?.(from)) {
                const answered = await this.games.checkGameAnswer(sock, from, sender, body, {});
                if (answered) return true;
            }
        } catch (e) { this._logError('game answer', e, from); }

        return false;
    }
}

module.exports = GameRouter;
