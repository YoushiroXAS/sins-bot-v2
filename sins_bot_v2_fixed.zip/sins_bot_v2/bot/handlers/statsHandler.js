/**
 * StatsHandler - Chat Statistics & Bonus System
 * Extracted from the god handler for single responsibility
 */
const config = require('../config');
const { todayKey } = require('../utils/time');

class StatsHandler {
    constructor(container) {
        this.container = container;
        this.dataManager = container.get('dataManager');
        this.logger = container.get('logger');
    }

    track(msg, messageType, from, sender, botJid) {
        const statsData = this.dataManager.get('stats') || { groups: {} };
        const cumulativeMessages = this.dataManager.get('cumulativeMessages') || {};
        
        if (!statsData.groups) statsData.groups = {};
        if (!statsData.groups[from]) {
            statsData.groups[from] = { 
                types: { text: 0, image: 0, video: 0, sticker: 0, audio: 0, document: 0 }, 
                users: {} 
            };
        }
        
        const groupData = statsData.groups[from];
        const currentSender = msg.key.fromMe ? botJid : sender;
        
        if (!groupData.users[currentSender]) {
            groupData.users[currentSender] = { 
                total: 0, text: 0, image: 0, video: 0, sticker: 0, audio: 0, document: 0 
            };
        }

        const typeMap = {
            conversation: 'text', extendedTextMessage: 'text',
            imageMessage: 'image', videoMessage: 'video',
            stickerMessage: 'sticker', audioMessage: 'audio',
            documentMessage: 'document'
        };
        
        const typeKey = typeMap[messageType] || 'text';
        groupData.types[typeKey] = (groupData.types[typeKey] || 0) + 1;
        groupData.users[currentSender].total++;
        groupData.users[currentSender][typeKey]++;
        
        if (!statsData.totalMessages) statsData.totalMessages = {};
        statsData.totalMessages[from] = (statsData.totalMessages[from] || 0) + 1;
        
        this.dataManager.set('stats', statsData);

        // Cumulative messages
        if (!cumulativeMessages[from]) cumulativeMessages[from] = {};
        if (!cumulativeMessages[from][currentSender]) cumulativeMessages[from][currentSender] = 0;
        cumulativeMessages[from][currentSender]++;
        this.dataManager.set('cumulativeMessages', cumulativeMessages);
    }

    async checkBonuses(sock, from, sender, context) {
        const cumulativeMessages = this.dataManager.get('cumulativeMessages') || {};
        const bonusState = this.dataManager.get('bonusState') || { messages: {} };
        const titlesData = this.dataManager.get('titles') || {};
        
        if (!cumulativeMessages[from]?.[sender]) return;
        
        const msgCount = cumulativeMessages[from][sender];
        if (msgCount < 1000) return;
        
        if (!bonusState.messages[from]) bonusState.messages[from] = {};
        const userBonuses = bonusState.messages[from][sender] || {};
        
        // 🔧 مكافأة الرسايل (500K عند 1000 رسالة ثم 250K كل 500) مكانش عليها أي حد زمني،
        // والرسايل العادية مش بتعدي على الـ rate limit، فسبام 500 رسالة كان بيكسب 250K.
        // دلوقتي فيه سقف يومي لكل عضو، والمكافآت اللي فاتت بتتصرف في الأيام اللي بعدها.
        const maxPerDay = config.economy?.MESSAGE_BONUS_MAX_PER_DAY ?? 2;
        const today = todayKey();
        if (!bonusState.daily) bonusState.daily = {};
        if (!bonusState.daily[from]) bonusState.daily[from] = {};
        let daily = bonusState.daily[from][sender];
        if (!daily || daily.date !== today) daily = bonusState.daily[from][sender] = { date: today, count: 0 };

        for (let threshold = 1000; threshold <= msgCount; threshold += 500) {
            if (!userBonuses[threshold]) {
                if (daily.count >= maxPerDay) break;
                daily.count++;
                const amount = (threshold === 1000) ? 500000 : 250000;
                userBonuses[threshold] = true;
                bonusState.messages[from][sender] = userBonuses;
                this.dataManager.set('bonusState', bonusState);
                
                if (typeof context.addBankMoney === 'function') {
                    context.addBankMoney(from, sender, amount);
                }
                
                const title = titlesData[from]?.[sender] || `@${sender.split('@')[0]}`;
                await sock.sendMessage(from, { 
                    text: `🎉 *مبروك!* ${title} وصلت رسائلك التراكمية إلى *${threshold}* رسالة وحصلت على مكافأة *${amount.toLocaleString()}$* 💰` 
                });
            }
        }
    }

    async showStats(sock, from) {
        const statsData = this.dataManager.get('stats') || {};
        const titlesData = this.dataManager.get('titles') || {};
        const groupData = statsData.groups?.[from];
        const totalMessages = statsData.totalMessages?.[from] || 0;
        
        if (totalMessages === 0 || !groupData?.users || !Object.keys(groupData.users).length) {
            await sock.sendMessage(from, { text: '📉 العداد فارغ حالياً.' });
            return;
        }
        
        const types = groupData.types || {};
        const calcPct = (count) => totalMessages > 0 ? ((count / totalMessages) * 100).toFixed(1) : '0.0';
        
        let statsMsg = `📊 *『 CHAT STATS 』* 📊\n📈 *إجمالي الرسائل:* 【 *${totalMessages}* رسالة 】\n\n`;
        statsMsg += `💬 نص: *${types.text || 0}* (${calcPct(types.text)}%)\n`;
        statsMsg += `🖼️ صور: *${types.image || 0}* (${calcPct(types.image)}%)\n`;
        statsMsg += `🎥 فيديو: *${types.video || 0}* (${calcPct(types.video)}%)\n`;
        statsMsg += `✨ ملصقات: *${types.sticker || 0}* (${calcPct(types.sticker)}%)\n`;
        statsMsg += `🎙️ صوت: *${types.audio || 0}* (${calcPct(types.audio)}%)\n`;
        statsMsg += `━━━━━━━━━━━━━━━━━━━━\n\n🏆 *الأعضاء الأكثر تفاعلاً:* \n`;
        
        const sorted = Object.entries(groupData.users)
            .sort((a, b) => (b[1].total || 0) - (a[1].total || 0))
            .slice(0, 10);
        
        const mentions = [];
        sorted.forEach(([jid, uData], index) => {
            const userPct = ((uData.total / totalMessages) * 100).toFixed(1);
            const title = titlesData[from]?.[jid];
            const name = title ? { text: title, mentions: [] } : { text: `@${jid.split('@')[0]}`, mentions: [jid] };
            const medal = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `${index + 1}. `;
            statsMsg += `${medal} ${name.text} ➜ *${uData.total}* رسالة (${userPct}%)\n`;
            mentions.push(...name.mentions);
        });
        
        await sock.sendMessage(from, { text: statsMsg, mentions });
    }

    async showPoints(sock, from) {
        const pointsData = this.dataManager.get('points') || {};
        const titlesData = this.dataManager.get('titles') || {};
        const groupPoints = pointsData[from]?.users || {};
        
        const sorted = Object.entries(groupPoints).sort((a, b) => b[1] - a[1]).slice(0, 10);
        if (!sorted.length) {
            await sock.sendMessage(from, { text: '📉 لوحة صدارة المشرفين فارغة لهذا الجروب.' });
            return;
        }
        
        let msg = `👑 *نقاط المشرفين لهذا الجروب*\n\n`;
        const mentions = [];
        
        sorted.forEach(([jid, points], i) => {
            const title = titlesData[from]?.[jid];
            const name = title ? { text: title, mentions: [] } : { text: `@${jid.split('@')[0]}`, mentions: [jid] };
            msg += `${i + 1}. ${name.text} ➜ *${points} نقطة*\n`;
            mentions.push(...name.mentions);
        });
        
        await sock.sendMessage(from, { text: msg, mentions });
    }
}

module.exports = StatsHandler;
