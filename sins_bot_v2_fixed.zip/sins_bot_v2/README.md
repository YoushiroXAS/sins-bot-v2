# SINS_BOT V2 - Professional WhatsApp Bot

## Overview
Complete architectural rewrite of SINS_BOT with professional-grade infrastructure.

**V1 Problems Fixed:**
- ✅ Core modules (container, eventBus, cache, monitor, recovery, rateLimiter) were dead code → **Now fully activated**
- ✅ God handler (262 lines) doing everything → **Split into 4 specialized handlers**
- ✅ Dual data storage causing corruption → **Unified through DataManager**
- ✅ Middlewares (cooldown, permission) orphaned → **Connected to execution pipeline**
- ✅ 3 conflicting logging systems → **Single unified logger**
- ✅ Module cache cleared on every message → **Smart hot-reload only**
- ✅ No rate limiting → **Per-user + per-command limiting**
- ✅ Memory leaks → **Bounded caches + cleanup**
- ✅ No crash recovery → **Game state persistence**

---

## Architecture

```
index.js (entry point - 20 lines)
    └── Container (DI)
         ├── Core Services
         │    ├── EventBus        ← Event-driven communication
         │    ├── CacheLayer       ← In-memory caching
         │    ├── DataManager      ← Unified data layer (atomic writes)
         │    ├── JSONDatabase     ← DB abstraction (swappable)
         │    ├── Monitor          ← Performance tracking
         │    └── Recovery         ← Crash recovery
         ├── Middleware Pipeline
         │    ├── RateLimiter      ← Spam prevention
         │    ├── PermissionCheck  ← Role-based access
         │    └── Cooldown         ← Per-command limits
         ├── CommandRegistry
         │    └── PluginLoader     ← Hot-reload support
         ├── Handlers (thin)
         │    ├── MessageHandler   ← Routes only
         │    ├── StatsHandler     ← Stats + bonuses
         │    └── GameRouter       ← Game routing
         └── BotService
              └── Baileys Connection Manager
```

---

## New Features in V2

| Feature | Status |
|---------|--------|
| Dependency Injection | ✅ Active |
| Event Bus | ✅ Active |
| Rate Limiting | ✅ Active |
| Cooldown System | ✅ Active |
| Permission Middleware | ✅ Active |
| Performance Monitor | ✅ Active |
| Crash Recovery | ✅ Active |
| Atomic File Writes | ✅ Active |
| Unified Logging | ✅ Active |
| Graceful Shutdown | ✅ Active |
| Hot Reload | ✅ Active |
| Bounded Caches | ✅ Active |

---

## File Structure

```
sins_bot_v2/
├── index.js                    ← Entry point (minimal)
├── AR.md                       ← Architecture Review (flaws + fixes)
├── README.md                   ← This file
├── package.json                ← Dependencies
│
└── bot/
    ├── config.js               ← Centralized config
    │
    ├── core/                   ← Core infrastructure
    │   ├── Container.js        ← DI container class
    │   ├── container.js        ← Service registrations
    │   ├── bootstrap.js        ← Wire everything
    │   ├── eventBus.js         ← Event system
    │   ├── cache.js            ← Cache layer
    │   ├── database.js         ← DB abstraction
    │   ├── commandRegistry.js  ← Command router
    │   ├── monitor.js          ← Performance monitor
    │   └── recovery.js         ← Crash recovery
    │
    ├── handlers/               ← Message handlers (thin)
    │   ├── handler.js          ← Main router
    │   ├── statsHandler.js     ← Statistics
    │   └── gameRouter.js       ← Game routing
    │
    ├── middlewares/            ← Middlewares (active!)
    │   ├── rateLimitMiddleware.js
    │   ├── permissionMiddleware.js
    │   └── cooldownMiddleware.js
    │
    ├── plugins/                ← Commands
    │   ├── status.js           ← Bot status (NEW)
    │   ├── menu.js             ← Command list
    │   ├── ping.js             ← Latency check
    │   ├── stats.js            ← Chat stats
    │   └── ban.js              ← User blocking
    │
    ├── services/
    │   └── botService.js       ← WhatsApp connection
    │
    ├── utils/
    │   ├── logger.js           ← Unified logging
    │   ├── dataManager.js      ← Data layer
    │   ├── gameManager.js      ← Game sessions
    │   └── rateLimiter.js      ← Rate limiting
    │
    ├── libs/                   ← Game libraries (from V1)
    ├── data/                   ← JSON data files
    └── logs/                   ← Log files
```

---

## Installation

```bash
# 1. Install dependencies
npm install

# 2. Start the bot
node index.js
```

---

## New Commands

| Command | Description | Permission |
|---------|-------------|------------|
| `.حالة` | Show system status | owner |
| `.menu` | List all commands | everyone |
| `.ping` | Check latency | everyone |

---

## Migration from V1

1. Copy your `bot/data/` folder (all JSON files)
2. Copy your `bot/session/` folder
3. Copy your `bot/plugins/` and `bot/libs/` folders
4. Run `npm install`
5. Start with `node index.js`

All V1 data files are compatible with V2.

---

## Performance Improvements

| Metric | V1 | V2 |
|--------|-----|-----|
| Handler lines | 262 | 45 (router only) |
| Core modules active | 0/7 | 7/7 |
| Middlewares active | 0/2 | 3/3 |
| Data writes | sync, unbounded | atomic, queued |
| Memory leaks | multiple | bounded |
| Rate limiting | none | multi-layer |

---

*SINS_BOT V2 - Built for scale*
