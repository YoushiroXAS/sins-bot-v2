#!/usr/bin/env node
/**
 * SINS_BOT V2 - Professional WhatsApp Bot
 * Entry point - minimal, delegates everything to the container
 * 
 * Architecture: Container-based DI with Event Bus
 * Core modules: All activated and wired
 */

// ====== Environment Setup ======
// تحميل .env (لو موجود) قبل ما أي ملف يقرا process.env (config.js / ai.js)
require('./bot/utils/loadEnv').loadEnv();
['HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy', 'ALL_PROXY', 'all_proxy']
    .forEach(k => delete process.env[k]);

// ====== Graceful Shutdown ======
// 🔧 قبل كده كان فيه SIGINT بس. الاستضافات (Docker / Pterodactyl / PM2) بتبعت
// SIGTERM عند الإيقاف أو الـ restart، فالبوت كان بيتقتل من غير حفظ. وبعد ما
// بقى الحفظ مؤجّل ثانيتين (debounce) ده معناه ضياع آخر التعديلات. كمان:
//   - uncaughtException كان بيخرج بعد 3 ثواني من غير أي حفظ.
//   - "الحد الأقصى لإعادة الاتصال" في botService كان بينادي process.exit مباشرة.
// دلوقتي كلهم بيعدّوا على نفس الدالة، والخدمات بتتوقف بالترتيب: الألعاب الأول
// (لأنها بتحفظ وهي بتنتهي)، وبعدين باقي الـ timers، وdataManager قبل الأخير
// عشان يحفظ كل حاجة، واللوجر في الآخر.
const SHUTDOWN_ORDER = [
    'botService', 'gameManager', 'moneyMachineScheduler', 'backupService',
    'rateLimiter', 'recovery', 'dataManager', 'logger',
];
let shuttingDown = false;

async function gracefulShutdown(reason, exitCode = 0) {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`\n[SYSTEM] ${reason} - shutting down...`);

    // لو إيقاف خدمة علّق، منستناش للأبد
    const forceTimer = setTimeout(() => {
        console.error('[SYSTEM] Shutdown timed out, forcing exit.');
        process.exit(exitCode || 1);
    }, 10000);

    let failed = false;
    try {
        const container = require('./bot/core/Container');
        for (const name of SHUTDOWN_ORDER) {
            try {
                await container.get(name)?.shutdown?.();
            } catch (e) {
                failed = true;
                console.error(`[SYSTEM] ${name} shutdown failed:`, e.message);
            }
        }
    } catch (e) {
        failed = true;
        console.error('[SYSTEM] Shutdown error:', e.message);
    }

    clearTimeout(forceTimer);
    console.log(failed ? '[SYSTEM] Stopped with errors.' : '[SYSTEM] All services stopped cleanly.');
    process.exit(failed ? 1 : exitCode);
}

// ====== Global Error Protection ======
process.on('unhandledRejection', (reason) => {
    console.error('[FATAL] Unhandled Rejection:', reason);
});
process.on('uncaughtException', (err) => {
    console.error('[FATAL] Uncaught Exception:', err);
    gracefulShutdown('uncaughtException', 1);
});
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
// أي جزء تاني من البوت يقدر يطلب إيقاف آمن بـ: process.emit('app:fatal', 'السبب')
process.on('app:fatal', (reason) => gracefulShutdown(`fatal: ${reason}`, 1));

// ====== Startup ======
async function main() {
    console.log('╔══════════════════════════════════════════╗');
    console.log('║     SINS_BOT V2 - Professional Mode      ║');
    console.log('║     Architecture: Container + Events     ║');
    console.log('╚══════════════════════════════════════════╝');

    // 1. Initialize the DI container (registers all services)
    const container = require('./bot/core/Container');
    
    // 2. Bootstrap all core modules
    const bootstrap = require('./bot/core/bootstrap');
    await bootstrap(container);

    // 3. Get the bot service and start
    const botService = container.get('botService');
    await botService.start();
}

main().catch(err => {
    console.error('[FATAL] Startup failed:', err);
    gracefulShutdown('startup failed', 1);
});
