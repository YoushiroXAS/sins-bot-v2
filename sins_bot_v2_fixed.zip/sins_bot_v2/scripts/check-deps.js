#!/usr/bin/env node
'use strict';
/**
 * check-deps - فحص المكتبات بعد `npm install` (npm run check-deps)
 *
 * بيتأكد من 3 حاجات:
 *  1) إصدار Node مدعوم (>= 18).
 *  2) كل مكتبة خارجية البوت محتاجاها بتتحمّل فعلًا وفيها الدوال اللي الكود بيستخدمها
 *     (مثلًا chess.js لازم تكون 1.x: isGameOver/isCheckmate/isDraw).
 *  3) أي require لمكتبة خارجية في الكود لازم تكون معلنة في package.json.
 * بيخرج بكود 1 لو في مشكلة، فينفع يتحط في CI.
 */
const fs = require('fs');
const path = require('path');
const { builtinModules } = require('module');

const ROOT = path.join(__dirname, '..');

const CHECKS = [
    { name: '@whiskeysockets/baileys', required: true,
      verify: (m) => typeof (m.default || m) === 'function' && typeof m.useMultiFileAuthState === 'function' && !!m.DisconnectReason,
      hint: 'مفيش default/useMultiFileAuthState/DisconnectReason: غالبًا إصدار غير متوافق (المطلوب 6.x)' },
    { name: 'pino', required: true, verify: (m) => typeof m === 'function', hint: 'pino لازم تكون دالة' },
    { name: 'axios', required: true, verify: (m) => typeof m.get === 'function' && typeof m.create === 'function', hint: 'axios ناقصة get/create' },
    { name: 'canvas', required: true, verify: (m) => typeof m.createCanvas === 'function', hint: 'canvas ناقصة createCanvas (محتاجة أدوات بناء على بعض الاستضافات)' },
    { name: 'cheerio', required: true, verify: (m) => typeof m.load === 'function', hint: 'cheerio ناقصة load (المطلوب 1.x)' },
    { name: 'chess.js', required: true,
      verify: (m) => { const c = new m.Chess(); return ['isGameOver', 'isCheckmate', 'isDraw', 'fen', 'turn', 'move'].every(f => typeof c[f] === 'function'); },
      hint: 'chess.js لازم تكون 1.x (isGameOver/isCheckmate/isDraw). الإصدارات 0.x بتستخدم أسماء تانية' },
    { name: 'soundcloud-downloader', required: true, verify: (m) => typeof (m.default || m).search === 'function', hint: 'soundcloud-downloader ناقصة search' },
    { name: 'yt-search', required: true, verify: (m) => typeof m === 'function', hint: 'yt-search لازم تكون دالة' },
    { name: 'sharp', required: false, verify: (m) => typeof m === 'function', hint: 'sharp اختيارية: بعض ميزات الصور هتتعطل من غيرها' },
];

function defaultLoad(name) {
    return require(require.resolve(name, { paths: [ROOT] }));
}

function runChecks({ load = defaultLoad, nodeVersion = process.versions.node } = {}) {
    const results = [];
    const major = Number(String(nodeVersion).split('.')[0]);
    results.push({ name: `Node.js ${nodeVersion}`, required: true, ok: major >= 18, detail: major >= 18 ? 'مدعوم' : 'لازم Node.js 18 أو أحدث' });
    for (const c of CHECKS) {
        try {
            const ok = !!c.verify(load(c.name));
            results.push({ name: c.name, required: c.required, ok, detail: ok ? 'تمام' : c.hint });
        } catch (e) {
            results.push({ name: c.name, required: c.required, ok: false, detail: `مش متثبّتة أو بتفشل في التحميل: ${String(e.message).split('\n')[0]}` });
        }
    }
    return results;
}

function walk(dir, out = []) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        if (['node_modules', '.git', 'backups', 'logs', 'session', 'assets', 'test'].includes(entry.name)) continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) walk(full, out);
        else if (entry.name.endsWith('.js')) out.push(full);
    }
    return out;
}

// بيشيل تعليق آخر السطر (// ...) مع احترام النصوص اللي بين علامات التنصيص (مثلًا https://)
function stripLineComment(line) {
    let quote = null;
    for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (quote) { if (ch === '\\') i++; else if (ch === quote) quote = null; continue; }
        if (ch === "'" || ch === '"' || ch === '`') { quote = ch; continue; }
        if (ch === '/' && line[i + 1] === '/') return line.slice(0, i);
    }
    return line;
}

function stripComments(source) {
    // تعليق الكتل لازم يبدأ بعد مسافة/بداية سطر (عشان أنماط زي '**/*.js' متتحسبش تعليق)
    const noBlock = source.replace(/(^|[\s;{}()])\/\*[\s\S]*?\*\//g, '$1');
    return noBlock.split('\n').map(stripLineComment).join('\n');
}

// أي مكتبة خارجية متطلوبة في الكود ومش معلنة في package.json
function findUndeclaredRequires(root = ROOT) {
    const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
    const declared = new Set([...Object.keys(pkg.dependencies || {}), ...Object.keys(pkg.optionalDependencies || {})]);
    const builtins = new Set(builtinModules.flatMap(m => [m, `node:${m}`]));
    const found = new Map();
    const files = [path.join(root, 'index.js'), ...walk(path.join(root, 'bot'))];
    for (const file of files) {
        const text = stripComments(fs.readFileSync(file, 'utf8'));
        for (const m of text.matchAll(/require\(\s*['"]([^./'"][^'"]*)['"]\s*\)/g)) {
            const spec = m[1];
            const base = spec.startsWith('@') ? spec.split('/').slice(0, 2).join('/') : spec.split('/')[0];
            if (builtins.has(base) || builtins.has(spec) || declared.has(base)) continue;
            if (!found.has(base)) found.set(base, []);
            found.get(base).push(path.relative(root, file));
        }
    }
    return [...found].map(([name, files]) => ({ name, files: [...new Set(files)] }));
}

function main() {
    let failed = false;
    console.log('فحص التبعيات:\n');
    for (const r of runChecks()) {
        const mark = r.ok ? '✅' : (r.required ? '❌' : '⚠️');
        console.log(`${mark} ${r.name.padEnd(28)} ${r.detail}`);
        if (!r.ok && r.required) failed = true;
    }
    const undeclared = findUndeclaredRequires();
    for (const u of undeclared) {
        failed = true;
        console.log(`❌ ${u.name.padEnd(28)} متطلوبة في الكود (${u.files.join(', ')}) ومش معلنة في package.json`);
    }
    if (!undeclared.length) console.log('✅ كل المكتبات المتطلوبة في الكود معلنة في package.json');
    console.log(failed ? '\nفيه مشاكل: شغّل npm install وراجع الأسطر ❌.' : '\nكل شيء سليم.');
    return failed ? 1 : 0;
}

if (require.main === module) process.exit(main());
module.exports = { runChecks, findUndeclaredRequires, CHECKS };
