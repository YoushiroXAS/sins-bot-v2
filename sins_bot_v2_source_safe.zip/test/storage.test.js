'use strict';
const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSandbox, exitWhenDone } = require('./helpers/sandbox');
const { sleep } = require('./helpers/harness');

exitWhenDone(after);

describe('التخزين: dataManager والمتجر والنسخ الاحتياطي', () => {
    let sb;
    before(() => { sb = createSandbox(); });
    const mkdir = (name) => { const d = sb.resolvePath('tmp-' + name); fs.mkdirSync(d, { recursive: true }); return d; };
    const quiet = { info() {}, warn() {}, error() {} };

    it('dataManager: ملف تالف بيتسترجع من أحدث نسخة سليمة وبيتكتب على الملف، والتالف بيتحفظ جنبه', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm');
        for (const [dir, v] of [['2026-01-01_00-00-00', 'old'], ['2026-01-02_00-00-00', 'newest']]) {
            fs.mkdirSync(path.join(T, 'backups', dir), { recursive: true });
            fs.writeFileSync(path.join(T, 'backups', dir, 'bank.json'), JSON.stringify({ v }));
        }
        fs.mkdirSync(path.join(T, 'data'), { recursive: true });
        fs.writeFileSync(path.join(T, 'data', 'bank.json'), '{"g":{"accounts":{"u1":12');
        const dm = new DataManager({ backupDir: path.join(T, 'backups'), debounceMs: 50 });
        assert.deepEqual(await dm.init('bank', path.join(T, 'data', 'bank.json'), {}, false), { v: 'newest' });
        assert.ok(fs.readdirSync(path.join(T, 'data')).some(f => f.includes('.corrupt-')));
        await sleep(250);
        assert.deepEqual(JSON.parse(fs.readFileSync(path.join(T, 'data', 'bank.json'), 'utf8')), { v: 'newest' });
    });

    it('dataManager: من غير نسخ احتياطية بيستخدم الافتراضي ويحفظ نسخة من التالف', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm2');
        fs.writeFileSync(path.join(T, 'titles.json'), 'not json');
        const dm = new DataManager({ backupDir: path.join(T, 'no_such_dir') });
        assert.deepEqual(await dm.init('titles', path.join(T, 'titles.json'), { def: true }, false), { def: true });
        assert.ok(fs.readdirSync(T).some(f => f.startsWith('titles.json.corrupt-')));
    });

    it('dataManager: فشل القراءة الحقيقي لا يتحول إلى بيانات افتراضية ولا يستبدل الملف', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm-read-error');
        const file = path.join(T, 'bank.json');
        fs.writeFileSync(file, JSON.stringify({ account: 123 }));
        const originalRead = fs.promises.readFile;
        fs.promises.readFile = async (target, ...args) => {
            if (String(target) === file) {
                const err = new Error('permission denied');
                err.code = 'EACCES';
                throw err;
            }
            return originalRead.call(fs.promises, target, ...args);
        };
        try {
            const dm = new DataManager({ backupDir: path.join(T, 'no-backups') });
            await assert.rejects(dm.init('bank', file, {}, false), { code: 'EACCES' });
            assert.deepEqual(JSON.parse(fs.readFileSync(file, 'utf8')), { account: 123 });
        } finally {
            fs.promises.readFile = originalRead;
        }
    });

    it('dataManager: تعديل مستمر بيتكتب أثناء النشاط (maxWait) ومش بيستنى لحد ما يوقف', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm3');
        const dm = new DataManager({ debounceMs: 400, maxWaitMs: 700, backupDir: path.join(T, 'nope') });
        await dm.init('k', path.join(T, 'k.json'), {}, false);
        let writes = 0; const orig = dm._atomicWrite.bind(dm);
        dm._atomicWrite = async (...a) => { writes++; return orig(...a); };
        for (let i = 0; i < 25; i++) { dm.set('k', { i }); await sleep(100); }
        assert.ok(writes >= 2, `writes=${writes}`);
        await dm.shutdown();
    });

    it('dataManager: فشل الحفظ بيتبلّغ للـ caller وبيسيب البيانات dirty لإعادة المحاولة', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm-write-error');
        const file = path.join(T, 'bank.json');
        const dm = new DataManager({ debounceMs: 5000, backupDir: path.join(T, 'no-backups') });
        await dm.init('bank', file, { balance: 10 }, false);
        dm.set('bank', { balance: 99 });
        const original = dm._atomicWrite.bind(dm);
        dm._atomicWrite = async () => { throw Object.assign(new Error('disk full'), { code: 'ENOSPC' }); };
        await assert.rejects(dm.saveAll(), { code: 'ENOSPC' });
        assert.equal(dm.getStats().dirtyStores, 1);
        assert.deepEqual(JSON.parse(fs.readFileSync(file, 'utf8')), { balance: 10 });
        dm._atomicWrite = original;
        await dm.saveAll();
        assert.equal(dm.getStats().dirtyStores, 0);
        assert.deepEqual(JSON.parse(fs.readFileSync(file, 'utf8')), { balance: 99 });
        await dm.shutdown();
    });

    it('dataManager: الكتابة المعلّقة في الـ debounce بتتحفظ في shutdown()', async () => {
        const DataManager = sb.require('bot/utils/dataManager');
        const T = mkdir('dm4');
        const dm = new DataManager({ debounceMs: 2000, backupDir: path.join(T, 'nope') });
        await dm.init('k', path.join(T, 'k.json'), {}, false);
        dm.set('k', { saved: true });
        assert.deepEqual(JSON.parse(fs.readFileSync(path.join(T, 'k.json'), 'utf8')), {});
        await dm.shutdown();
        assert.deepEqual(JSON.parse(fs.readFileSync(path.join(T, 'k.json'), 'utf8')), { saved: true });
    });

    it('تخزين المتجر: حفظ ذري، فشل الكتابة مبيكسرش الملف الأصلي، والملف التالف بيتحفظ منه نسخة', () => {
        const { loadJSON, saveJSON } = sb.require('bot/libs/shop/storage');
        const T = mkdir('shop');
        const file = path.join(T, 'inventory.json');
        assert.equal(saveJSON(file, { u1: { sword: 2 } }), true);
        assert.deepEqual(loadJSON(file, {}), { u1: { sword: 2 } });
        assert.equal(fs.existsSync(file + '.tmp'), false);

        const realWrite = fs.writeFileSync; const realError = console.error;
        fs.writeFileSync = (p, d) => { realWrite(p, String(d).slice(0, 5)); throw new Error('محاكاة قطع الكهرباء'); };
        console.error = () => {};
        let result;
        try { result = saveJSON(file, { u1: { sword: 99 } }); } finally { fs.writeFileSync = realWrite; console.error = realError; }
        assert.equal(result, false);
        assert.deepEqual(loadJSON(file, {}), { u1: { sword: 2 } });
        assert.equal(fs.existsSync(file + '.tmp'), false);

        fs.writeFileSync(file, '{"u1":{"sw');
        console.error = () => {};
        try { assert.deepEqual(loadJSON(file, {}), {}); } finally { console.error = realError; }
        const aside = fs.readdirSync(T).filter(f => f.includes('.corrupt-'));
        assert.equal(aside.length, 1);
        assert.equal(fs.readFileSync(path.join(T, aside[0]), 'utf8'), '{"u1":{"sw');
        assert.deepEqual(loadJSON(path.join(T, 'nope.json'), { a: 1 }), { a: 1 });
    });

    it('BackupService: بينسخ الـ JSON السليم بس، بيحذف الأقدم، ومبينسخش تاني عند التشغيل لو آخر نسخة حديثة', async () => {
        const BackupService = sb.require('bot/services/backupService');
        const B = mkdir('bk');
        fs.mkdirSync(path.join(B, 'data'), { recursive: true });
        fs.writeFileSync(path.join(B, 'data', 'a.json'), '{"a":1}');
        fs.writeFileSync(path.join(B, 'data', 'bad.json'), '{broken');
        fs.writeFileSync(path.join(B, 'data', 'note.txt'), 'x');
        fs.writeFileSync(path.join(B, 'data', 'a.json.tmp'), '{"half":');
        for (let i = 1; i <= 4; i++) fs.mkdirSync(path.join(B, 'backups', `2026-01-0${i}_00-00-00`), { recursive: true });
        const options = { dataDir: path.join(B, 'data'), backupDir: path.join(B, 'backups'), keep: 3, logger: quiet };
        const result = await new BackupService(options).backupNow();
        assert.deepEqual(fs.readdirSync(result.target), ['a.json']);
        assert.equal(result.skipped, 1);
        const dirs = fs.readdirSync(path.join(B, 'backups')).sort();
        assert.equal(dirs.length, 3);
        assert.ok(!dirs.includes('2026-01-01_00-00-00') && !dirs.includes('2026-01-02_00-00-00'));

        const second = new BackupService(options);
        second.start(); await sleep(200); await second.shutdown();
        assert.equal(fs.readdirSync(path.join(B, 'backups')).length, 3);
    });

    it('BackupService: فشل كتابة نسخة جديدة لا يحذف النسخ القديمة', async () => {
        const BackupService = sb.require('bot/services/backupService');
        const B = mkdir('bk-write-fail');
        const dataDir = path.join(B, 'data');
        const backupDir = path.join(B, 'backups');
        const oldBackup = path.join(backupDir, '2026-01-01_00-00-00');
        fs.mkdirSync(dataDir, { recursive: true });
        fs.mkdirSync(oldBackup, { recursive: true });
        fs.writeFileSync(path.join(dataDir, 'a.json'), '{"a":2}');
        fs.writeFileSync(path.join(oldBackup, 'a.json'), '{"a":1}');
        const originalWrite = fs.promises.writeFile;
        fs.promises.writeFile = async (target, ...args) => {
            if (String(target).includes(path.join(backupDir, '2026-'))) {
                throw Object.assign(new Error('disk full'), { code: 'ENOSPC' });
            }
            return originalWrite.call(fs.promises, target, ...args);
        };
        try {
            const service = new BackupService({ dataDir, backupDir, keep: 1, logger: quiet });
            await assert.rejects(service.backupNow(), { code: 'ENOSPC' });
            assert.ok(fs.existsSync(path.join(oldBackup, 'a.json')));
            assert.deepEqual(fs.readdirSync(backupDir), ['2026-01-01_00-00-00']);
        } finally { fs.promises.writeFile = originalWrite; }
    });

    it('BackupService: بيرفض مجلد نسخ احتياطي عبارة عن symlink', async () => {
        const BackupService = sb.require('bot/services/backupService');
        const B = mkdir('bk-symlink');
        const dataDir = path.join(B, 'data');
        const realBackupDir = path.join(B, 'outside');
        const linkBackupDir = path.join(B, 'backups');
        fs.mkdirSync(dataDir, { recursive: true });
        fs.mkdirSync(realBackupDir, { recursive: true });
        fs.writeFileSync(path.join(dataDir, 'safe.json'), '{"ok":true}');
        fs.symlinkSync(realBackupDir, linkBackupDir, 'dir');
        const service = new BackupService({ dataDir, backupDir: linkBackupDir, logger: quiet });
        await assert.rejects(service.backupNow(), /مجلد النسخ ليس مجلدًا حقيقيًا/);
        assert.deepEqual(fs.readdirSync(realBackupDir), []);
    });

    it('GameManager: يستدعي حفظ الاستعادة قبل تفعيل اللعبة ويرجع عند فشل الحفظ', async () => {
        const GameManager = sb.require('bot/utils/gameManager');
        const gm = new GameManager(60000);
        try {
            let saved = null;
            gm.onGameStart = async (...args) => { saved = args; };
            const session = await gm.startGame('group-1', 'quiz', { players: { u1: 1 } });
            assert.equal(saved[0], 'group-1');
            assert.equal(saved[1], 'quiz');
            assert.deepEqual(saved[2].data, { players: { u1: 1 } });
            assert.equal(gm.activeGames.get('group-1'), session);
            await gm.endGame('group-1');

            gm.onGameStart = async () => { throw new Error('disk full'); };
            await assert.rejects(gm.startGame('group-2', 'quiz', {}), /disk full/);
            assert.equal(gm.activeGames.has('group-2'), false);
        } finally { await gm.shutdown(); }
    });

    it('CrashRecovery: يحفظ حالة الاستعادة بكتابة ذرية ويستعيدها مرة واحدة', () => {
        const CrashRecovery = sb.require('bot/core/recovery');
        const recoveryPath = sb.resolvePath('bot', 'data', 'recovery.json');
        fs.mkdirSync(path.dirname(recoveryPath), { recursive: true });
        const recovery = new CrashRecovery();
        try {
            recovery.saveGameState('group-3', 'quiz', { question: 1 });
            const raw = JSON.parse(fs.readFileSync(recoveryPath, 'utf8'));
            assert.equal(raw['group-3'].gameType, 'quiz');
            assert.deepEqual(raw['group-3'].data, { question: 1 });
            assert.equal(fs.readdirSync(path.dirname(recoveryPath)).some(n => n.endsWith('.tmp')), false);
            assert.equal(recovery.restoreGameState('group-3').gameType, 'quiz');
            assert.equal(recovery.restoreGameState('group-3'), null);
        } finally { recovery.shutdown(); }
    });
});
