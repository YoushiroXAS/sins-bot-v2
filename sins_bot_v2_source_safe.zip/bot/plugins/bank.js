const fs = require('fs');
const path = require('path');
const { auditLog } = require('../utils/auditLog');

// 🔧 `.بنك تصفير` كان بيمسح كل حسابات الجروب بأمر واحد من غير أي تأكيد ولا نسخة.
// دلوقتي: خطوتين (طلب ثم `.بنك تصفير تأكيد` خلال دقيقة)، ونسخة من بيانات الجروب
// بتتحفظ قبل المسح (ولو فشل حفظ النسخة التصفير بيتلغي)، وسجل تدقيق.
const CONFIRM_WINDOW_MS = 60 * 1000;
const RESET_BACKUP_DIR = path.resolve(__dirname, '..', 'backups', 'bank-resets');
const pendingResets = new Map(); // `${group}:${sender}` -> وقت انتهاء فرصة التأكيد

function snapshotGroupBank(groupId, groupBank) {
    fs.mkdirSync(RESET_BACKUP_DIR, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    // A chat/JID is external input. Never use it raw as a path segment.
    const rawId = String(groupId || '').split('@')[0];
    const safeId = rawId.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 100) || 'unknown-group';
    const file = path.resolve(RESET_BACKUP_DIR, `${stamp}_${safeId}.json`);
    if (path.dirname(file) !== RESET_BACKUP_DIR) throw new Error('Invalid backup destination');
    const tmp = `${file}.${process.pid}.${require('crypto').randomBytes(8).toString('hex')}.tmp`;
    try {
        fs.writeFileSync(tmp, JSON.stringify({ groupId, savedAt: new Date().toISOString(), data: groupBank }, null, 2), { flag: 'wx' });
        fs.renameSync(tmp, file);
    } catch (err) {
        try { fs.unlinkSync(tmp); } catch (_) {}
        throw err;
    }
    return file;
}

module.exports = {
    command: 'بنك',
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!isGroup) return;
        if (args[0] === 'تصفير') {
            if (!context.isOwner) {
                await sock.sendMessage(from, { text: "❌ هذا الأمر مخصص للإدارة العليا فقط." });
                return;
            }
            const now = Date.now();
            for (const [k, deadline] of pendingResets) if (deadline < now) pendingResets.delete(k);

            const groupBank = context.bankData[from];
            const accounts = groupBank?.accounts || {};
            const count = Object.keys(accounts).length;
            const total = Object.values(accounts).reduce((sum, v) => sum + (Number(v) || 0), 0);
            const key = `${from}:${sender}`;

            if (args[1] !== 'تأكيد') {
                pendingResets.set(key, now + CONFIRM_WINDOW_MS);
                await sock.sendMessage(from, { text:
                    `⚠️ *تأكيد تصفير البنك*\nده هيمسح *${count}* حساب (مجموع ${total.toLocaleString()}$) في الجروب ده.\n` +
                    `هتتحفظ نسخة قبل المسح.\nلو متأكد اكتب خلال دقيقة: \`.بنك تصفير تأكيد\`` });
                return;
            }

            if (!pendingResets.has(key)) {
                await sock.sendMessage(from, { text: "⚠️ مفيش طلب تصفير شغال. اكتب `.بنك تصفير` الأول وبعدها التأكيد خلال دقيقة." });
                return;
            }
            pendingResets.delete(key);
            if (!groupBank) {
                await sock.sendMessage(from, { text: "ℹ️ مفيش حسابات بنكية في الجروب ده أصلاً." });
                return;
            }

            let backupFile;
            try {
                backupFile = snapshotGroupBank(from, groupBank);
            } catch (e) {
                auditLog({ action: 'bank-reset', result: 'aborted-backup-failed', group: from, actor: sender });
                await sock.sendMessage(from, { text: "❌ فشل حفظ النسخة الاحتياطية، فالتصفير اتلغى ومفيش حاجة اتمسحت." });
                return;
            }

            delete context.bankData[from];
            context.saveBank();
            auditLog({ action: 'bank-reset', result: 'ok', group: from, actor: sender, accounts: count, total, backup: path.basename(backupFile) });
            await sock.sendMessage(from, { text: `🏦 تم تصفير ${count} حساب بنكي لهذا الجروب.\n💾 النسخة: ${path.basename(backupFile)}` });
            return;
        }
        const userTitle = context.getGroupTitle(sender);
        if (!userTitle) {
            await sock.sendMessage(from, { text: "⚠️ يجب أن يكون لديك لقب مسجل. اكتب `.تسجيل [لقبك]`" });
            return;
        }
        const balance = (context.bankData[from]?.accounts[sender]) || 0;
        await sock.sendMessage(from, { text: `🏦 *بنك النخبة*\n💳 الحساب: *${userTitle}*\n💰 الرصيد: *${balance.toLocaleString()}$*` });
    }
};
