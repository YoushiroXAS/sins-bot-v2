const fs = require('fs');
const path = require('path');
const axios = require('axios');
const logger = require('../utils/logger');

let sharp;
try { sharp = require('sharp'); } catch (e) {}

const activePath = path.join(__dirname, '..', 'data', 'activeWelcome.json');
const dataDir = path.dirname(activePath);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(activePath)) fs.writeFileSync(activePath, JSON.stringify([]));

function readActiveGroups() {
    const value = JSON.parse(fs.readFileSync(activePath, 'utf8'));
    if (!Array.isArray(value) || value.some(id => typeof id !== 'string')) {
        throw new Error('ملف إعدادات الترحيب غير صالح؛ لم يتم تغييره.');
    }
    return value;
}

function writeActiveGroups(groups) {
    const temporary = `${activePath}.${process.pid}.${require('crypto').randomUUID()}.tmp`;
    try {
        fs.writeFileSync(temporary, JSON.stringify(groups, null, 2), { flag: 'wx' });
        fs.renameSync(temporary, activePath);
    } catch (error) {
        try { fs.unlinkSync(temporary); } catch (_) {}
        throw error;
    }
}

function jidPart(jid) {
    return String(jid || '').split('@')[0].split(':')[0];
}

async function canManageWelcome(sock, from, sender, context) {
    if (context.isOwner || context.isDeveloper) return true;
    if (!sender || typeof sock.groupMetadata !== 'function') return false;
    try {
        const metadata = await sock.groupMetadata(from);
        const senderPart = jidPart(sender);
        const participant = (metadata.participants || []).find(p =>
            [p.id, p.jid, p.phoneNumber, p.lid].some(id => id && jidPart(id) === senderPart));
        return participant?.admin === 'admin' || participant?.admin === 'superadmin';
    } catch (_) {
        return false;
    }
}

const welcomed = new Set();
// 🔧 كان boolean (welcomeListenerAdded) بيفضل true للأبد، فبعد أول reconnect الـ socket الجديد
// مكانش بياخد listener. دلوقتي بنفتكر الـ socket نفسه، فكل socket جديد بياخد listener مرة واحدة.
let listeningSock = null;

async function fetchAnimePFP(query) {
    if (!query) return null;
    try {
        const res = await axios.get('https://api.jikan.moe/v4/characters', {
            params: { q: query, limit: 5, order_by: 'favorites', sort: 'desc' },
            timeout: 10000
        });
        const results = res.data?.data || [];
        if (results.length) return results[0].images?.jpg?.image_url;
    } catch (e) {}
    return null;
}

function registerWelcomeListener(sock) {
    // Some command/test contexts may expose a socket without an event emitter.
    // Do not mark it as registered or let this break the command itself.
    if (!sock || !sock.ev || typeof sock.ev.on !== 'function' || listeningSock === sock) return;
    listeningSock = sock;
    sock.ev.on('group-participants.update', async (update) => {
        try {
            if (update.action !== 'add') return;
            const groupId = update.id;
            const activeGrps = JSON.parse(fs.readFileSync(activePath, 'utf8'));
            if (!activeGrps.includes(groupId)) return;
            for (const participant of update.participants) {
                const jid = typeof participant === 'string' ? participant : participant.jid;
                if (!jid) continue;
                const key = `${groupId}:${jid}`;
                if (welcomed.has(key)) continue;
                welcomed.add(key);
                setTimeout(() => welcomed.delete(key), 5 * 60 * 1000);
                const img = await fetchAnimePFP('anime welcome');
                const caption = `🌸 أهلاً وسهلاً بك في المجموعة!\n👤 @${jid.split('@')[0]}`;
                if (img) {
                    await sock.sendMessage(groupId, { image: { url: img }, caption, mentions: [jid] });
                } else {
                    await sock.sendMessage(groupId, { text: caption, mentions: [jid] });
                }
            }
        } catch (err) { logger.error('خطأ في الترحيب التلقائي:', err); }
    });
}

module.exports = {
    command: 'ترحيب',
    init(sock) {
        registerWelcomeListener(sock);
        welcomed.clear();
    },
    async execute(sock, msg, body, isGroup, from, sender, context, args) {
        if (!isGroup) return sock.sendMessage(from, { text: '❌ هذا الأمر يعمل داخل المجموعات فقط.' });
        const sub = args[0] || '';
        if (sub === 'تشغيل') {
            if (!(await canManageWelcome(sock, from, sender, context))) {
                return sock.sendMessage(from, { text: '❌ تفعيل أو إيقاف الترحيب التلقائي متاح لمشرفي المجموعة فقط.' });
            }
            let act = readActiveGroups();
            if (act.includes(from)) return sock.sendMessage(from, { text: '✅ الترحيب التلقائي مفعل مسبقاً.' });
            act.push(from);
            writeActiveGroups(act);
            registerWelcomeListener(sock);
            return sock.sendMessage(from, { text: '✅ تم تفعيل الترحيب التلقائي.' });
        }
        if (sub === 'وقف' || sub === 'إيقاف') {
            if (!(await canManageWelcome(sock, from, sender, context))) {
                return sock.sendMessage(from, { text: '❌ تفعيل أو إيقاف الترحيب التلقائي متاح لمشرفي المجموعة فقط.' });
            }
            let act = readActiveGroups();
            act = act.filter(j => j !== from);
            writeActiveGroups(act);
            return sock.sendMessage(from, { text: '⛔ تم إيقاف الترحيب التلقائي.' });
        }
        let targetJid = msg.message?.extendedTextMessage?.contextInfo?.participant ||
                        msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
        if (!targetJid) return sock.sendMessage(from, { text: '⚠️ استخدم المنشن أو الرد!' });
        const welcomeTitle = args.slice(1).join(' ').trim() || context.getGroupTitle?.(targetJid) || targetJid.split('@')[0];
        const imgUrl = await fetchAnimePFP(welcomeTitle);
        const caption = `🌟 مرحباً ${welcomeTitle}!\n👤 @${targetJid.split('@')[0]}`;
        if (imgUrl) {
            await sock.sendMessage(from, { image: { url: imgUrl }, caption, mentions: [targetJid] });
        } else {
            await sock.sendMessage(from, { text: `⚠️ لا صورة.\n\n${caption}`, mentions: [targetJid] });
        }
    }
};