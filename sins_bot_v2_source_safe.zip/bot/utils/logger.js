/**
 * Logger - Unified Structured Logging (V2)
 * 
 * Replaces the 3 conflicting logging systems:
 * - console.js (ANSI colors only)
 * - logger.js (file-based)  
 * - index.js console overrides
 * 
 * Features:
 * - Structured JSON logs to file
 * - Colored console output
 * - Log levels: debug, info, warn, error, success, game
 * - Automatic log rotation (daily files)
 */
const fs = require('fs');
const path = require('path');

const COLORS = {
    reset: '\x1b[0m',
    red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
    blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m', gray: '\x1b[90m'
};

const LEVELS = {
    DEBUG: { color: COLORS.gray, label: 'DEBUG', console: true },
    INFO: { color: COLORS.green, label: 'INFO', console: true },
    WARN: { color: COLORS.yellow, label: 'WARN', console: true },
    ERROR: { color: COLORS.red, label: 'ERROR', console: true },
    SUCCESS: { color: COLORS.cyan, label: 'SUCCESS', console: true },
    GAME: { color: COLORS.magenta, label: 'GAME', console: true },
};

// DEBUG is the most verbose. SUCCESS and GAME are informational events.
const LEVEL_PRIORITY = { DEBUG: 10, INFO: 20, SUCCESS: 20, GAME: 20, WARN: 30, ERROR: 40 };

// ══════════════════════════════════════════════════════════════════
// إخفاء الأسرار من اللوج (Part 6 §7 / Part 9 M4)
// ══════════════════════════════════════════════════════════════════
// أخطاء HTTP وسياقات اللوج ممكن تحتوي ترويسات Authorization أو cookies أو مفاتيح
// API. أي قيمة تحت مفتاح حساس بتتبدّل، وأي نص فيه Bearer/مفتاح معروف بيتعمّى.
const SENSITIVE_KEY = /authorization|cookie|token|api[-_]?key|secret|passw(or)?d|session|credential/i;
const SECRET_PATTERNS = [
    [/Bearer\s+[A-Za-z0-9._~+\/=-]{8,}/gi, 'Bearer [REDACTED]'],
    [/\b(?:gsk_|sk-or-v1-|sk-ant-|sk-)[A-Za-z0-9_-]{16,}/g, '[REDACTED_KEY]'],
    [/([?&](?:key|token|api_key|apikey|access_token|auth)=)[^&\s"']+/gi, '$1[REDACTED]'],
];
function redactString(text) {
    let out = String(text);
    for (const [re, replacement] of SECRET_PATTERNS) out = out.replace(re, replacement);
    return out;
}
function redactValue(value, depth = 0, seen = new WeakSet()) {
    if (typeof value === 'string') return redactString(value);
    if (value === null || typeof value !== 'object') return value;
    if (depth > 4 || seen.has(value)) return '[...]';
    seen.add(value);
    if (Array.isArray(value)) return value.map(v => redactValue(v, depth + 1, seen));
    const out = {};
    for (const [k, v] of Object.entries(value)) {
        out[k] = SENSITIVE_KEY.test(k) ? '[REDACTED]' : redactValue(v, depth + 1, seen);
    }
    return out;
}

class Logger {
    constructor(options = {}) {
        this.logDir = options.logDir || path.join(__dirname, '..', 'logs');
        const requestedLevel = String(options.level || 'INFO').toUpperCase();
        this.level = Object.prototype.hasOwnProperty.call(LEVEL_PRIORITY, requestedLevel) ? requestedLevel : 'INFO';
        this.enableFile = options.enableFile !== false;
        this.enableConsole = options.enableConsole !== false;
        this._rotationTimer = null;
        
        this._ensureLogDir();
        this._currentFile = this._getLogFile();
        
        // Rotate log file at midnight
        this._scheduleRotation();
    }

    _ensureLogDir() {
        if (!fs.existsSync(this.logDir)) {
            try { fs.mkdirSync(this.logDir, { recursive: true }); } catch(e) {}
        }
    }

    _getLogFile() {
        const date = new Date().toISOString().split('T')[0];
        return path.join(this.logDir, `${date}.log`);
    }

    _scheduleRotation() {
        const now = new Date();
        const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
        const msUntilMidnight = tomorrow - now;
        
        this._rotationTimer = setTimeout(() => {
            this._currentFile = this._getLogFile();
            this._scheduleRotation();
        }, msUntilMidnight);
        if (this._rotationTimer.unref) this._rotationTimer.unref();
    }

    shutdown() {
        if (this._rotationTimer) clearTimeout(this._rotationTimer);
    }

    _format(level, message, context = {}) {
        const timestamp = new Date().toISOString();
        const ctx = Object.keys(context).length ? ` | ${JSON.stringify(context)}` : '';
        return `[${timestamp}] [${level}] ${message}${ctx}`;
    }

    _write(levelKey, message, context = {}) {
        const config = LEVELS[levelKey];
        if (!config) return;
        if (LEVEL_PRIORITY[levelKey] < LEVEL_PRIORITY[this.level]) return;

        const safeMessage = redactString(message);
        let safeContext = redactValue(context);
        if (safeContext === undefined || safeContext === null) safeContext = {};
        else if (typeof safeContext !== 'object') safeContext = { detail: safeContext };
        const formatted = this._format(config.label, safeMessage, safeContext);

        // Console output
        if (this.enableConsole) {
            console.log(`${config.color}${formatted}${COLORS.reset}`);
        }

        // File output
        if (this.enableFile) {
            try {
                fs.appendFile(this._currentFile, formatted + '\n', (err) => {
                    if (err) {
                        // Do not route this through Logger again (would recurse); keep the
                        // diagnostic minimal and never include logged context/secrets.
                        if (this.enableConsole) console.error('[Logger] Failed to append log file:', err.message);
                    }
                });
            } catch (e) {
                if (this.enableConsole) console.error('[Logger] Failed to append log file:', e.message);
            }
        }
    }

    debug(message, context) { this._write('DEBUG', message, context); }
    info(message, context) { this._write('INFO', message, context); }
    warn(message, context) { this._write('WARN', message, context); }
    error(message, error) { 
        const context = error ? { 
            message: error.message || error, 
            stack: (error.stack || '').split('\n').slice(0, 3).join(' | ') 
        } : {};
        this._write('ERROR', message, context); 
    }
    success(message, context) { this._write('SUCCESS', message, context); }
    game(gameType, groupId, event, context) {
        this._write('GAME', `${gameType} | ${groupId} | ${event}`, context);
    }
}

// 🔧 5 بلجنز (ai, quran, welcome, spy_commands, deathnote_commands) بتعمل
// require('../utils/logger') وبتنادي logger.error(...) على الكلاس نفسه، فكانت بترمي
// "logger.error is not a function" جوه الـ catch: المستخدم مبياخدش رسالة الخطأ
// والخطأ الأصلي بيضيع. دلوقتي الكلاس نفسه عنده دوال ثابتة بتحوّل لنسخة الـ
// Container (Logger.setDefault بتتنادى هناك)، فمفيش حاجة تتغير في البلجنز دي.
let defaultInstance = null;
Logger.setDefault = (instance) => { defaultInstance = instance; };
for (const level of ['debug', 'info', 'warn', 'error', 'success', 'game']) {
    Logger[level] = (...args) => {
        if (defaultInstance) return defaultInstance[level](...args);
        (level === 'error' ? console.error : console.log)(`[${level.toUpperCase()}]`, ...args);
    };
}
Logger.redact = redactValue; // للاختبار وللاستخدام من أي ملف تاني

module.exports = Logger;
