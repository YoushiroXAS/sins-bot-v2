/**
 * CrashRecovery - Saves and restores game states
 * Prevents game progress loss on bot restart
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const RECOVERY_FILE = path.join(__dirname, '..', 'data', 'recovery.json');
const MAX_AGE_MS = 30 * 60 * 1000; // 30 minutes
const CLEANUP_INTERVAL = 10 * 60 * 1000; // 10 minutes

class CrashRecovery {
    constructor() {
        this._state = {};
        this._cleanupInterval = null;
        this._load();
        
        // Periodic cleanup
        this._cleanupInterval = setInterval(() => this._cleanup(), CLEANUP_INTERVAL);
        if (this._cleanupInterval.unref) this._cleanupInterval.unref();
    }

    saveGameState(groupId, gameType, data) {
        const previous = this._state[groupId];
        this._state[groupId] = {
            gameType,
            data: JSON.parse(JSON.stringify(data)), // Deep clone
            savedAt: Date.now()
        };
        try { this._flush(); }
        catch (error) {
            if (previous === undefined) delete this._state[groupId];
            else this._state[groupId] = previous;
            throw error;
        }
    }

    restoreGameState(groupId) {
        const state = this._state[groupId];
        if (!state) return null;
        
        if (!Number.isFinite(state.savedAt) || Date.now() - state.savedAt > MAX_AGE_MS) {
            delete this._state[groupId];
            this._flush();
            return null;
        }

        delete this._state[groupId];
        try { this._flush(); }
        catch (error) {
            this._state[groupId] = state;
            throw error;
        }
        return state;
    }

    _flush() {
        const dir = path.dirname(RECOVERY_FILE);
        fs.mkdirSync(dir, { recursive: true });
        const temporary = `${RECOVERY_FILE}.${process.pid}.${crypto.randomUUID()}.tmp`;
        try {
            fs.writeFileSync(temporary, JSON.stringify(this._state, null, 2), { flag: 'wx' });
            fs.renameSync(temporary, RECOVERY_FILE);
        } catch (error) {
            try { fs.unlinkSync(temporary); } catch (_) {}
            console.error('Recovery save failed:', error.message);
            throw error;
        }
    }

    _load() {
        if (!fs.existsSync(RECOVERY_FILE)) return;
        let parsed;
        try {
            parsed = JSON.parse(fs.readFileSync(RECOVERY_FILE, 'utf8'));
            if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
                throw new Error('Recovery file must contain an object');
            }
        } catch (error) {
            const aside = `${RECOVERY_FILE}.corrupt-${Date.now()}-${process.pid}`;
            // إذا لم نقدر على حفظ الملف التالف، أوقف التشغيل بدلًا من مسحه لاحقًا بحالة فارغة.
            fs.copyFileSync(RECOVERY_FILE, aside, fs.constants.COPYFILE_EXCL);
            console.error(`Recovery file is invalid; preserved as ${path.basename(aside)}: ${error.message}`);
            this._state = {};
            return;
        }
        this._state = parsed;
    }

    _cleanup() {
        const now = Date.now();
        let changed = false;
        const removed = {};
        for (const groupId of Object.keys(this._state)) {
            const savedAt = this._state[groupId]?.savedAt;
            if (!Number.isFinite(savedAt) || now - savedAt > MAX_AGE_MS) {
                removed[groupId] = this._state[groupId];
                delete this._state[groupId];
            }
        }
        if (Object.keys(removed).length) {
            try { this._flush(); }
            catch (error) {
                Object.assign(this._state, removed);
                console.error('Recovery cleanup save failed:', error.message);
            }
        }
    }

    shutdown() {
        if (this._cleanupInterval) clearInterval(this._cleanupInterval);
    }
}

module.exports = CrashRecovery;
