/**
 * BackupService - نسخ احتياطي دوري لكل ملفات bot/data/*.json
 *
 * - كل 6 ساعات (ومرة عند التشغيل لو آخر نسخة أقدم من ساعة).
 * - بيحتفظ بآخر 10 نسخ في bot/backups/<التاريخ_الوقت>/.
 * - مبينسخش ملف JSON تالف (عشان النسخ الاحتياطية تفضل سليمة).
 * - dataManager بيستخدم آخر نسخة سليمة تلقائيًا لو ملف اتلف وقت التشغيل.
 */
const fs = require('fs').promises;
const path = require('path');

const BACKUP_NAME = /^\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}$/;
const SIX_HOURS = 6 * 60 * 60 * 1000;
const ONE_HOUR = 60 * 60 * 1000;

class BackupService {
    constructor(options = {}) {
        this.dataDir = options.dataDir || path.join(__dirname, '..', 'data');
        this.backupDir = options.backupDir || path.join(__dirname, '..', 'backups');
        this.intervalMs = options.intervalMs || SIX_HOURS;
        this.keep = options.keep || 10;
        this.logger = options.logger || null;
        this._timer = null;
        this._running = null;
    }

    _log(level, msg) {
        const fn = this.logger?.[level];
        if (typeof fn === 'function') fn.call(this.logger, `[Backup] ${msg}`);
        else console[level === 'error' ? 'error' : 'log'](`[Backup] ${msg}`);
    }

    start() {
        if (this._timer) return;
        this._latestAgeMs().then(age => {
            if (age === null || age > ONE_HOUR) return this.backupNow();
        }).catch(e => this._log('error', `فشل النسخ عند التشغيل: ${e.message}`));
        this._timer = setInterval(() => {
            this.backupNow().catch(e => this._log('error', `فشل النسخ الدوري: ${e.message}`));
        }, this.intervalMs);
        if (this._timer.unref) this._timer.unref();
    }

    backupNow() {
        if (!this._running) {
            this._running = this._doBackup().finally(() => { this._running = null; });
        }
        return this._running;
    }

    async _listBackups() {
        let entries;
        try {
            entries = await fs.readdir(this.backupDir, { withFileTypes: true });
        } catch (error) {
            // غياب المجلد طبيعي عند أول تشغيل؛ أخطاء الصلاحيات/القرص يجب ألا تُخفى.
            if (error.code === 'ENOENT') return [];
            throw error;
        }
        // Dirent.isDirectory() يستبعد الروابط الرمزية؛ لا نعاملها كمجلدات نسخ.
        return entries.filter(e => e.isDirectory() && BACKUP_NAME.test(e.name)).map(e => e.name).sort();
    }

    async _ensureSafeRoots() {
        await fs.mkdir(this.backupDir, { recursive: true });
        const [dataStat, backupStat] = await Promise.all([
            fs.lstat(this.dataDir),
            fs.lstat(this.backupDir),
        ]);
        if (!dataStat.isDirectory() || dataStat.isSymbolicLink()) {
            throw new Error('رفض النسخ الاحتياطي: مجلد البيانات ليس مجلدًا حقيقيًا');
        }
        if (!backupStat.isDirectory() || backupStat.isSymbolicLink()) {
            throw new Error('رفض النسخ الاحتياطي: مجلد النسخ ليس مجلدًا حقيقيًا');
        }
    }

    async _latestAgeMs() {
        const dirs = await this._listBackups();
        if (!dirs.length) return null;
        const st = await fs.stat(path.join(this.backupDir, dirs[dirs.length - 1]));
        return Date.now() - st.mtimeMs;
    }

    async _doBackup() {
        await this._ensureSafeRoots();
        const entries = await fs.readdir(this.dataDir, { withFileTypes: true });
        const files = entries.filter(e => e.isFile() && e.name.endsWith('.json')).map(e => e.name);
        const stamp = new Date().toISOString().replace('T', '_').replace(/[:.]/g, '-').slice(0, 19);
        const target = path.join(this.backupDir, stamp);
        // لا نستخدم recursive هنا حتى لا نكتب فوق نسخة موجودة بنفس الطابع الزمني.
        await fs.mkdir(target);

        let copied = 0, skipped = 0;
        try {
        for (const name of files) {
            let raw;
            try {
                raw = await fs.readFile(path.join(this.dataDir, name), 'utf8');
            } catch (error) {
                // اختفاء ملف أثناء التشغيل يمكن تخطيه؛ أخطاء القرص والصلاحيات توقف النسخ.
                if (error.code === 'ENOENT') {
                    skipped++;
                    this._log('warn', `اتخطّى ${name}: الملف اختفى أثناء النسخ`);
                    continue;
                }
                throw error;
            }
            try {
                JSON.parse(raw); // الملف التالف وحده يتم تخطيه
            } catch (error) {
                skipped++;
                this._log('warn', `اتخطّى ${name}: JSON غير صالح (${error.message})`);
                continue;
            }

            const destination = path.join(target, name);
            const temporary = `${destination}.${process.pid}.${Date.now()}.tmp`;
            try {
                await fs.writeFile(temporary, raw, { flag: 'wx' });
                await fs.rename(temporary, destination);
            } catch (writeError) {
                await fs.unlink(temporary).catch(() => {});
                // فشل كتابة النسخة لا يُعامل كملف تالف، ولا نسمح بحذف النسخ القديمة.
                throw writeError;
            }
            copied++;
        }
        } catch (error) {
            // لا تترك مجلدًا جزئيًا يُحسب كنسخة حديثة عند إعادة التشغيل.
            try { await fs.rm(target, { recursive: true, force: false }); }
            catch (cleanupError) { this._log('error', `تعذر تنظيف النسخة الجزئية ${stamp}: ${cleanupError.message}`); }
            throw error;
        }
        await this._prune();
        this._log('info', `نسخة جديدة ${stamp} (${copied} ملف${skipped ? `، ${skipped} اتخطّى` : ''})`);
        return { target, copied, skipped };
    }

    async _prune() {
        await this._ensureSafeRoots();
        const dirs = await this._listBackups();
        const extra = dirs.slice(0, Math.max(0, dirs.length - this.keep));
        const root = path.resolve(this.backupDir);
        for (const name of extra) {
            // لا نحذف إلا اسمًا مطابقًا ومجلدًا مباشرًا تحت جذر النسخ، ولا نتجاهل أخطاء الحذف.
            if (!BACKUP_NAME.test(name)) continue;
            const target = path.resolve(root, name);
            if (path.dirname(target) !== root) throw new Error('رفض حذف نسخة احتياطية خارج مجلد النسخ');
            let stat;
            try { stat = await fs.lstat(target); }
            catch (error) { if (error.code === 'ENOENT') continue; throw error; }
            if (!stat.isDirectory() || stat.isSymbolicLink()) continue;
            await fs.rm(target, { recursive: true, force: false });
        }
    }

    async shutdown() {
        if (this._timer) clearInterval(this._timer);
        this._timer = null;
        if (this._running) await this._running.catch(() => {});
    }
}

module.exports = BackupService;
