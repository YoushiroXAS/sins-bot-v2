/**
 * Config - Centralized Configuration (V2)
 * All hardcoded values from V1 moved here
 */
module.exports = {
    // Bot identity
    // Keep personal WhatsApp identifiers out of source control. Configure these in .env.
    ownerNumber: (process.env.BOT_OWNER_NUMBER || '').replace(/\D/g, ''),
    ownerLID: (process.env.BOT_OWNER_LID || '').replace(/\D/g, ''),
    defaultPhone: (process.env.BOT_DEFAULT_PHONE || '').replace(/\D/g, ''),
    prefix: '.',
    botName: '𝑺𝑰𝑵𝑺_𝑩𝑶𝑻 2.1',
    version: '2.1.0',
    
    // Timezone
    timezone: 'Africa/Cairo',
    
    // Messages
    messages: {
        ownerOnly: '❌ هذا الأمر مخصص للمالك والمطورين فقط.',
        eliteOnly: '❌ هذا الأمر مخصص للنخبة والمالك والمطورين فقط.',
        error: '❌ حدث خطأ أثناء تنفيذ الأمر.',
        notFound: '❌ الأمر غير موجود.',
        cooldown: '⏳ انتظر {seconds} ثانية.',
    },
    
    // Economy
    economy: {
        DAILY_BONUS: 500,
        WORK_MIN: 100,
        WORK_MAX: 500,
        ROB_COOLDOWN: 60 * 60 * 1000,
        // أقصى مبلغ في عملية تحويل واحدة (0 = بدون حد). كان معرّف ومش متطبق.
        MAX_TRANSFER: 1000000,
        // ضريبة التحويل (0.05 = 5%) بتتخصم من اللي بيوصل للمستلم. كانت 0.05 ومش متطبقة؛ خليتها 0
        // لحد ما تقرر، فغيّرها لـ 0.05 لتفعيلها.
        TAX_RATE: 0,
        INTEREST_RATE: 0.02,
        // أقصى عدد مكافآت رسايل تتصرف للعضو الواحد في الجروب في اليوم (بتوقيت القاهرة).
        // الباقي بيتأجل لليوم اللي بعده بدل ما يضيع.
        MESSAGE_BONUS_MAX_PER_DAY: 2,
    },
    
    // Games
    games: {
        MAX_PLAYERS: 20,
        GAME_TIMEOUT: 30 * 60 * 1000,
        ANSWER_TIMEOUT: 30 * 1000,
        MIN_PLAYERS: 2,
        POINTS_PER_WIN: 10,
    },
    
    // Limits
    limits: {
        MAX_MESSAGE_LENGTH: 4096,
        MAX_MENTIONS: 10,
        MAX_COMMANDS_PER_MINUTE: 30,
        SPAM_TIMEOUT: 10000,
    },
    
    // Rate limiter
    rateLimit: {
        MAX_REQUESTS: 10,
        WINDOW_MS: 10000,
        BLOCK_DURATION: 60000,
    },
    
    // Paths (centralized)
    paths: {
        data: './bot/data',
        session: './bot/session',
        logs: './bot/logs',
        plugins: './bot/plugins',
        libs: './bot/libs',
    },

    // ══════════════════════════════════════════════
    //  إعدادات نظام AI (libs/ai.js)
    // ══════════════════════════════════════════════
    // المفتاحين اختياريين. سيبهم فاضيين هنا ('') وحطهم في ملف .env
    // بدل الكود، عشان ميترفعوش بالغلط على أي مكان عام (GitHub..إلخ).
    // ai.js بيقرأهم أوتوماتيك من process.env كـ fallback لو فاضيين هنا.
    //   .env:
    //     GROQ_API_KEY=...
    //     OPENROUTER_API_KEY=...
    ai: {
        groqApiKey: process.env.GROQ_API_KEY || '',
        openrouterApiKey: process.env.OPENROUTER_API_KEY || '',
        // groqModel: 'openai/gpt-oss-120b',
        // openrouterModel: 'deepseek/deepseek-chat-v3.1:free',
    },
};
